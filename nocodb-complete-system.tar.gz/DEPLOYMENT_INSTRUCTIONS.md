# Team 2 Standalone GIS System - Linode Deployment Instructions

## Prerequisites
- Fresh Ubuntu 22.04/24.04 Linode instance
- Root access to the server
- WinSCP or similar file transfer tool
- The backup file: `team2_standalone_FULL_master_button_working_20250603.tar.gz` (104MB)

## Deployment Steps

### 1. Connect to Your Linode Instance
```bash
ssh root@YOUR_LINODE_IP
```

### 2. Download the Deployment Script
```bash
wget https://raw.githubusercontent.com/YOUR_REPO/linode_team2_deployment.sh
# Or copy the script manually
```

### 3. Make the Script Executable
```bash
chmod +x linode_team2_deployment.sh
```

### 4. Run the Deployment Script
```bash
./linode_team2_deployment.sh
```

### 5. Upload File When Prompted
When the script pauses and asks for file upload:
1. Use WinSCP to connect to your Linode instance
2. Navigate to `/opt/team2-gis/`
3. Upload `team2_standalone_FULL_master_button_working_20250603.tar.gz`
4. Return to terminal and press ENTER to continue

### 6. Access Your Application
After deployment completes:
- Web Interface: `http://YOUR_LINODE_IP`
- Direct Access: `http://YOUR_LINODE_IP:5002`

## What the Script Installs

### System Components
- PostgreSQL 14 with PostGIS extension
- Node.js 20 with NPM
- PM2 process manager
- Nginx reverse proxy
- UFW firewall (configured)

### Application Setup
- Extracts and configures Team 2 standalone system
- Sets up environment variables
- Installs all Node.js dependencies
- Configures database connection
- Sets up PM2 process management
- Configures Nginx reverse proxy

### Database Configuration
- Database: `gisdb`
- User: `gisuser`
- Password: `gispassword123`
- Extensions: PostGIS, PostGIS Topology

### Ports and Access
- Application Port: 5002
- Web Access: Port 80 (via Nginx)
- SSH: Port 22
- PostgreSQL: Port 5432 (local only)

## Post-Deployment Commands

```bash
# Check application status
pm2 status

# View application logs
pm2 logs team2-standalone-gis

# Restart application
pm2 restart team2-standalone-gis

# Check database connection
sudo -u postgres psql -d gisdb -c "SELECT PostGIS_Version();"

# Check Nginx status
systemctl status nginx

# View system resources
htop
```

## Troubleshooting

### Application Not Starting
```bash
pm2 logs team2-standalone-gis
```

### Database Connection Issues
```bash
sudo -u postgres psql -d gisdb
```

### Nginx Issues
```bash
nginx -t
systemctl status nginx
```

### Firewall Issues
```bash
ufw status
```

## Security Recommendations

1. **Change Default Database Password**
```bash
sudo -u postgres psql -c "ALTER USER gisuser PASSWORD 'your_new_password';"
# Update .env file accordingly
```

2. **Set Up SSL Certificate**
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

3. **Configure SSH Key Authentication**
```bash
# Disable password authentication in /etc/ssh/sshd_config
PasswordAuthentication no
```

## File Locations

- Application: `/opt/team2-gis/`
- Environment: `/opt/team2-gis/.env`
- Logs: `/opt/team2-gis/logs/`
- Nginx Config: `/etc/nginx/sites-available/team2-gis`
- PM2 Config: `/opt/team2-gis/ecosystem.config.js`

## Support

If you encounter issues:
1. Check the application logs: `pm2 logs`
2. Verify all services are running: `pm2 status`, `systemctl status nginx postgresql`
3. Check firewall settings: `ufw status`
4. Verify file permissions in `/opt/team2-gis/`

The deployment script creates a complete, production-ready installation of the Team 2 Standalone GIS System with all necessary dependencies and security configurations.