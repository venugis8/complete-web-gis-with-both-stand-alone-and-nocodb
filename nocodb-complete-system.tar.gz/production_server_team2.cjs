const express = require('express');
const path = require('path');
const { Pool } = require('pg');

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://gisuser:gispassword123@localhost:5432/gisdb'
});

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist/public'), {
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
}));

// Super Admin API Routes
app.get('/api/super-admin/bases', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM bases ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/super-admin/bases', async (req, res) => {
  try {
    const { name, subdomain, systemMode, deploymentType, nocodbUrl, nocodbApiKey, nocodbBaseId } = req.body;
    
    const result = await pool.query(`
      INSERT INTO bases (name, subdomain, system_mode, deployment_type, nocodb_url, nocodb_api_key, nocodb_base_id, db_path)
      VALUES ($1, $2, $3, $4, $5, $6, $7, 'default')
      RETURNING *
    `, [name, subdomain, systemMode || 'standalone', deploymentType || 'basic', nocodbUrl, nocodbApiKey, nocodbBaseId]);
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Authentication routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Simple authentication - in production, use proper password hashing
    if (email === 'ssc6@ppmail.com' && password === 'mypassword123') {
      res.json({ 
        success: true, 
        user: { id: 1, email: 'ssc6@ppmail.com', role: 'super_admin' }
      });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Auth error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/public', 'index.html'));
});

// Start server
app.listen(PORT, HOST, () => {
  console.log(`Server running on http://${HOST}:${PORT}`);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('Shutting down server...');
  pool.end();
  process.exit(0);
});