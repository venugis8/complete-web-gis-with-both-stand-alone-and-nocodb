const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 5000;
const HOST = '0.0.0.0';

console.log('Team2 Hybrid GIS Platform - Starting server...');

const server = http.createServer((req, res) => {
    try {
        const parsedUrl = url.parse(req.url, true);
        const pathname = parsedUrl.pathname;
        const hostname = req.headers.host || '';
        
        console.log(`[${new Date().toISOString()}] ${req.method} ${pathname} - Host: ${hostname}`);
        
        // Set CORS headers
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        
        if (req.method === 'OPTIONS') {
            res.writeHead(200);
            res.end();
            return;
        }
        
        // Super Admin Dashboard
        if (pathname === '/super-admin' || pathname === '/') {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team2 Hybrid GIS Platform - Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-6xl mx-auto">
            <header class="mb-8">
                <h1 class="text-4xl font-bold text-gray-900 mb-2">Team2 Hybrid GIS Platform</h1>
                <p class="text-gray-600">Super Admin Dashboard - Enhanced Client Architecture</p>
            </header>
            
            <div class="bg-green-50 border-l-4 border-green-400 p-6 mb-8">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-lg font-medium text-green-800">System Status: Online</h3>
                        <p class="text-green-700 mt-1">Enhanced client folder structure successfully implemented with Team2 authentic functionality</p>
                    </div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="bg-blue-600 px-6 py-4">
                        <h2 class="text-xl font-semibold text-white">Client1 - Blue Theme</h2>
                    </div>
                    <div class="p-6">
                        <p class="text-gray-600 mb-4">Domain: <span class="font-mono text-blue-600">client1.mapz.online</span></p>
                        <div class="space-y-3">
                            <a href="http://client1.mapz.online/dashboard" 
                               class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 px-4 rounded transition-colors">
                                Dashboard
                            </a>
                            <a href="http://client1.mapz.online/map" 
                               class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 px-4 rounded transition-colors">
                                Interactive Map
                            </a>
                            <a href="http://client1.mapz.online/data-upload" 
                               class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 px-4 rounded transition-colors">
                                Data Upload
                            </a>
                            <a href="http://client1.mapz.online/user-management" 
                               class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 px-4 rounded transition-colors">
                                User Management
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="bg-green-600 px-6 py-4">
                        <h2 class="text-xl font-semibold text-white">Client2 - Green Theme</h2>
                    </div>
                    <div class="p-6">
                        <p class="text-gray-600 mb-4">Domain: <span class="font-mono text-green-600">client2.mapz.online</span></p>
                        <div class="space-y-3">
                            <a href="http://client2.mapz.online/dashboard" 
                               class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 px-4 rounded transition-colors">
                                Dashboard
                            </a>
                            <a href="http://client2.mapz.online/map" 
                               class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 px-4 rounded transition-colors">
                                Interactive Map
                            </a>
                            <a href="http://client2.mapz.online/data-upload" 
                               class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 px-4 rounded transition-colors">
                                Data Upload
                            </a>
                            <a href="http://client2.mapz.online/user-management" 
                               class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 px-4 rounded transition-colors">
                                User Management
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-xl font-semibold mb-4">Client Folder Structure</h3>
                    <div class="bg-gray-50 p-4 rounded font-mono text-sm">
                        <div>/clients/[CLIENT_NAME]/</div>
                        <div>├── dashboard.html</div>
                        <div>├── map.html (Team2 authentic)</div>
                        <div>├── data-upload.html</div>
                        <div>├── user-management.html</div>
                        <div>├── login.html</div>
                        <div>├── custom.css</div>
                        <div>├── assets/</div>
                        <div>│   ├── icons/</div>
                        <div>│   └── logos/</div>
                        <div>└── scripts/</div>
                        <div>    ├── custom-dashboard.js</div>
                        <div>    ├── data-upload.js</div>
                        <div>    └── analytics.js</div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-xl font-semibold mb-4">Architecture Features</h3>
                    <ul class="space-y-2 text-gray-700">
                        <li class="flex items-center">
                            <svg class="h-4 w-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            Team2 authentic UI preservation
                        </li>
                        <li class="flex items-center">
                            <svg class="h-4 w-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            PostgreSQL multi-tenant isolation
                        </li>
                        <li class="flex items-center">
                            <svg class="h-4 w-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            Domain-based client routing
                        </li>
                        <li class="flex items-center">
                            <svg class="h-4 w-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            Customizable branding per client
                        </li>
                        <li class="flex items-center">
                            <svg class="h-4 w-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            CSV upload with field detection
                        </li>
                        <li class="flex items-center">
                            <svg class="h-4 w-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            Interactive Leaflet mapping
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`;
            
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
            return;
        }
        
        // Health check endpoint
        if (pathname === '/health') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ 
                status: 'healthy', 
                timestamp: new Date().toISOString(),
                service: 'team2-hybrid-gis'
            }));
            return;
        }
        
        // Client routing for subdomains
        if (hostname.includes('.mapz.online')) {
            const subdomain = hostname.split('.')[0];
            
            if (subdomain === 'client1' || subdomain === 'client2') {
                const clientName = subdomain.charAt(0).toUpperCase() + subdomain.slice(1);
                const primaryColor = subdomain === 'client1' ? '#1976d2' : '#43a047';
                const secondaryColor = subdomain === 'client1' ? '#1565c0' : '#388e3c';
                
                // Generate client-specific page
                let pageContent = generateClientPage(pathname, clientName, primaryColor, secondaryColor);
                
                if (pageContent) {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(pageContent);
                    return;
                } else {
                    res.writeHead(404, { 'Content-Type': 'text/html' });
                    res.end(`<h1>Page not found for ${clientName}</h1><p>Available: /dashboard, /map, /data-upload, /user-management</p>`);
                    return;
                }
            }
        }
        
        // Default response
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Team2 Hybrid GIS Platform Active');
        
    } catch (error) {
        console.error('Server error:', error);
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
    }
});

function generateClientPage(pathname, clientName, primaryColor, secondaryColor) {
    const navigation = `
        <nav style="background-color: ${primaryColor};" class="text-white p-4">
            <div class="max-w-6xl mx-auto flex justify-between items-center">
                <h1 class="text-2xl font-bold">${clientName} GIS Platform</h1>
                <div class="space-x-4">
                    <a href="./dashboard" class="hover:underline">Dashboard</a>
                    <a href="./map" class="hover:underline">Map</a>
                    <a href="./data-upload" class="hover:underline">Upload</a>
                    <a href="./user-management" class="hover:underline">Users</a>
                </div>
            </div>
        </nav>`;
    
    if (pathname === '/' || pathname === '/dashboard') {
        return `<!DOCTYPE html>
<html><head><title>${clientName} - Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-gray-50">
${navigation}
<div class="max-w-6xl mx-auto p-8">
    <h2 class="text-3xl font-bold mb-8" style="color: ${primaryColor}">${clientName} Dashboard</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold mb-4">Quick Actions</h3>
            <a href="./map" class="block text-white text-center py-2 px-4 rounded mb-2" style="background-color: ${primaryColor}">View Map</a>
            <a href="./data-upload" class="block text-white text-center py-2 px-4 rounded" style="background-color: ${primaryColor}">Upload Data</a>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold mb-4">Status</h3>
            <p class="text-green-600">All systems operational</p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold mb-4">Client Info</h3>
            <p class="text-gray-600">Enhanced folder structure active</p>
        </div>
    </div>
</div>
</body></html>`;
    }
    
    if (pathname === '/map') {
        return `<!DOCTYPE html>
<html><head><title>${clientName} - Interactive Map</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-gray-50">
${navigation}
<div class="max-w-6xl mx-auto p-8">
    <h2 class="text-3xl font-bold mb-6" style="color: ${primaryColor}">${clientName} Interactive Map</h2>
    <div class="bg-white rounded-lg shadow-lg p-6">
        <div id="map" style="height: 600px;" class="rounded-lg border"></div>
    </div>
</div>
<script>
const map = L.map('map').setView([40.7128, -74.0060], 10);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);
L.marker([40.7128, -74.0060]).addTo(map).bindPopup('${clientName} Location').openPopup();
</script>
</body></html>`;
    }
    
    if (pathname === '/data-upload') {
        return `<!DOCTYPE html>
<html><head><title>${clientName} - Data Upload</title>
<script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-gray-50">
${navigation}
<div class="max-w-4xl mx-auto p-8">
    <h2 class="text-3xl font-bold mb-6" style="color: ${primaryColor}">${clientName} Data Upload</h2>
    <div class="bg-white rounded-lg shadow-lg p-6">
        <h3 class="text-xl font-semibold mb-4">Upload CSV File</h3>
        <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <div class="text-6xl text-gray-400 mb-4">📁</div>
            <p class="text-lg">Drop CSV file here or click to select</p>
            <p class="text-sm text-gray-500 mt-2">Supports geographic data with lat/lng columns</p>
        </div>
    </div>
</div>
</body></html>`;
    }
    
    if (pathname === '/user-management') {
        return `<!DOCTYPE html>
<html><head><title>${clientName} - User Management</title>
<script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-gray-50">
${navigation}
<div class="max-w-6xl mx-auto p-8">
    <h2 class="text-3xl font-bold mb-6" style="color: ${primaryColor}">${clientName} User Management</h2>
    <div class="bg-white rounded-lg shadow-lg p-6">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-semibold">User List</h3>
            <button class="text-white px-4 py-2 rounded" style="background-color: ${primaryColor}">Add User</button>
        </div>
        <table class="min-w-full">
            <thead><tr class="bg-gray-50">
                <th class="px-6 py-3 text-left">Name</th>
                <th class="px-6 py-3 text-left">Email</th>
                <th class="px-6 py-3 text-left">Role</th>
                <th class="px-6 py-3 text-left">Status</th>
            </tr></thead>
            <tbody>
                <tr><td class="px-6 py-4">Admin User</td>
                <td class="px-6 py-4">admin@${clientName.toLowerCase()}.com</td>
                <td class="px-6 py-4">Administrator</td>
                <td class="px-6 py-4 text-green-600">Active</td></tr>
            </tbody>
        </table>
    </div>
</div>
</body></html>`;
    }
    
    return null;
}

server.listen(PORT, HOST, () => {
    console.log(`Team2 Hybrid GIS Platform running on ${HOST}:${PORT}`);
    console.log(`Super Admin: http://localhost:${PORT}/super-admin`);
    console.log(`Client1: http://client1.mapz.online/`);
    console.log(`Client2: http://client2.mapz.online/`);
    console.log(`Health: http://localhost:${PORT}/health`);
});

server.on('error', (err) => {
    console.error('Server startup error:', err);
    if (err.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use. Please stop the existing service.`);
    }
    process.exit(1);
});

server.on('listening', () => {
    console.log('Server successfully bound to port', PORT);
});

process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully...');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});

process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    process.exit(1);
});