import path from 'path';
import fs from 'fs';
import { Request, Response, NextFunction } from 'express';

interface ClientConfig {
  features: {
    map: boolean;
    tableView: boolean;
    customLayer: boolean;
    userManagement: boolean;
    dataUpload: boolean;
  };
  branding: {
    primaryColor: string;
    secondaryColor?: string;
    logo: string;
    favicon?: string;
    backgroundImage?: string;
  };
  permissions: {
    adminOnly: string[];
    editorAccess: string[];
    viewerAccess: string[];
  };
}

interface ClientRequest extends Request {
  client?: string;
  clientConfig?: ClientConfig;
  clientPath?: string;
}

export default function enhancedHybridMiddleware(req: ClientRequest, res: Response, next: NextFunction) {
  let client = null;
  const host = req.headers.host || '';
  
  // Extract client from subdomain
  if (host && host.includes('.')) {
    const parts = host.split('.');
    if (parts.length > 2) {
      client = parts[0];
    }
  }
  
  // Extract client from URL path if subdomain not available
  if (!client && req.path.startsWith('/client/')) {
    client = req.path.split('/')[2];
  }
  
  req.client = client;
  req.clientPath = client ? `/opt/team2-hybrid/clients/${client}` : null;

  // Load client configuration
  if (client) {
    const configPath = path.join('/opt/team2-hybrid/config', `${client}.json`);
    if (fs.existsSync(configPath)) {
      try {
        req.clientConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      } catch (error) {
        console.error(`Error loading config for client ${client}:`, error);
        req.clientConfig = getDefaultConfig();
      }
    } else {
      req.clientConfig = getDefaultConfig();
    }
  }

  // Handle client-specific file serving
  if (client && req.clientPath) {
    // Serve client-specific HTML pages
    if (req.path.endsWith('.html')) {
      const pageName = path.basename(req.path);
      const clientFilePath = path.join(req.clientPath, pageName);
      
      if (fs.existsSync(clientFilePath)) {
        let html = fs.readFileSync(clientFilePath, 'utf8');
        
        // Replace template variables
        html = processTemplate(html, client, req.clientConfig);
        
        res.setHeader('Content-Type', 'text/html');
        return res.send(html);
      }
    }
    
    // Serve client-specific CSS
    if (req.path.includes(`/clients/${client}/custom.css`)) {
      const cssPath = path.join(req.clientPath, 'custom.css');
      if (fs.existsSync(cssPath)) {
        let css = fs.readFileSync(cssPath, 'utf8');
        
        // Process CSS variables
        css = processCSSTemplate(css, req.clientConfig);
        
        res.setHeader('Content-Type', 'text/css');
        return res.send(css);
      }
    }
    
    // Serve client-specific JavaScript
    if (req.path.includes(`/clients/${client}/scripts/`)) {
      const scriptName = path.basename(req.path);
      const scriptPath = path.join(req.clientPath, 'scripts', scriptName);
      
      if (fs.existsSync(scriptPath)) {
        res.setHeader('Content-Type', 'application/javascript');
        return res.sendFile(scriptPath);
      }
    }
    
    // Serve client-specific assets
    if (req.path.includes(`/clients/${client}/assets/`)) {
      const assetPath = req.path.replace(`/clients/${client}/assets/`, '');
      const fullAssetPath = path.join(req.clientPath, 'assets', assetPath);
      
      if (fs.existsSync(fullAssetPath)) {
        return res.sendFile(fullAssetPath);
      }
    }
    
    // Handle specific route mappings
    if (handleRouteMapping(req, res, client)) {
      return;
    }
  }

  next();
}

function handleRouteMapping(req: ClientRequest, res: Response, client: string): boolean {
  const routeMap: { [key: string]: string } = {
    '/': 'dashboard.html',
    '/dashboard': 'dashboard.html',
    '/login': 'login.html',
    '/map': 'map.html',
    '/data-upload': 'data-upload.html',
    '/users': 'user-management.html',
    '/user-management': 'user-management.html'
  };
  
  const mappedFile = routeMap[req.path];
  if (mappedFile && req.clientPath) {
    const filePath = path.join(req.clientPath, mappedFile);
    
    if (fs.existsSync(filePath)) {
      let html = fs.readFileSync(filePath, 'utf8');
      html = processTemplate(html, client, req.clientConfig);
      
      res.setHeader('Content-Type', 'text/html');
      res.send(html);
      return true;
    }
  }
  
  return false;
}

function processTemplate(html: string, clientName: string, config?: ClientConfig): string {
  // Replace template variables
  html = html.replace(/\{\{CLIENT_NAME\}\}/g, clientName.charAt(0).toUpperCase() + clientName.slice(1));
  html = html.replace(/\{\{USER_NAME\}\}/g, 'Admin User'); // Would come from session
  
  if (config) {
    // Replace branding variables
    html = html.replace(/\{\{PRIMARY_COLOR\}\}/g, config.branding.primaryColor);
    html = html.replace(/\{\{LOGO_PATH\}\}/g, config.branding.logo);
    
    // Inject custom styles
    const customStyles = `
      <style>
        :root {
          --primary-color: ${config.branding.primaryColor};
          --secondary-color: ${config.branding.secondaryColor || '#6b7280'};
        }
      </style>
    `;
    html = html.replace('</head>', customStyles + '</head>');
  }
  
  return html;
}

function processCSSTemplate(css: string, config?: ClientConfig): string {
  if (config) {
    css = css.replace(/var\(--primary-color\)/g, config.branding.primaryColor);
    css = css.replace(/var\(--secondary-color\)/g, config.branding.secondaryColor || '#6b7280');
  }
  
  return css;
}

function getDefaultConfig(): ClientConfig {
  return {
    features: {
      map: true,
      tableView: true,
      customLayer: false,
      userManagement: true,
      dataUpload: true
    },
    branding: {
      primaryColor: '#3b82f6',
      secondaryColor: '#6b7280',
      logo: '/assets/default-logo.png'
    },
    permissions: {
      adminOnly: ['user-management', 'system-settings'],
      editorAccess: ['data-upload', 'map-edit', 'table-edit'],
      viewerAccess: ['dashboard', 'map-view', 'table-view']
    }
  };
}

// Utility function to create client folder structure
export function createClientStructure(clientName: string, config: Partial<ClientConfig> = {}): void {
  const clientPath = `/opt/team2-hybrid/clients/${clientName}`;
  const directories = [
    '',
    'assets',
    'assets/icons',
    'scripts'
  ];
  
  // Create directories
  directories.forEach(dir => {
    const fullPath = path.join(clientPath, dir);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
    }
  });
  
  // Create config file
  const configPath = `/opt/team2-hybrid/config/${clientName}.json`;
  const fullConfig = { ...getDefaultConfig(), ...config };
  fs.writeFileSync(configPath, JSON.stringify(fullConfig, null, 2));
  
  // Copy template files if they don't exist
  const templateFiles = ['dashboard.html', 'login.html', 'map.html', 'data-upload.html', 'user-management.html'];
  const templatesPath = '/opt/team2-hybrid/templates';
  
  templateFiles.forEach(file => {
    const templateFile = path.join(templatesPath, file);
    const clientFile = path.join(clientPath, file);
    
    if (fs.existsSync(templateFile) && !fs.existsSync(clientFile)) {
      fs.copyFileSync(templateFile, clientFile);
    }
  });
  
  // Create custom CSS file
  const customCSSPath = path.join(clientPath, 'custom.css');
  if (!fs.existsSync(customCSSPath)) {
    const cssContent = generateCustomCSS(fullConfig);
    fs.writeFileSync(customCSSPath, cssContent);
  }
  
  // Create basic JavaScript files
  const scriptFiles = [
    { name: 'custom-dashboard.js', content: generateDashboardJS(clientName) },
    { name: 'data-upload.js', content: generateDataUploadJS(clientName) },
    { name: 'analytics.js', content: generateAnalyticsJS(clientName) }
  ];
  
  scriptFiles.forEach(script => {
    const scriptPath = path.join(clientPath, 'scripts', script.name);
    if (!fs.existsSync(scriptPath)) {
      fs.writeFileSync(scriptPath, script.content);
    }
  });
}

function generateCustomCSS(config: ClientConfig): string {
  return `/* Custom CSS for client */
:root {
  --primary-color: ${config.branding.primaryColor};
  --primary-hover: ${adjustColor(config.branding.primaryColor, -20)};
  --secondary-color: ${config.branding.secondaryColor || '#6b7280'};
}

body { 
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

.btn-primary {
  background-color: var(--primary-color);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  transition: background-color 0.2s;
}

.btn-primary:hover {
  background-color: var(--primary-hover);
}

.text-primary {
  color: var(--primary-color);
}

.border-primary {
  border-color: var(--primary-color);
}

.bg-primary {
  background-color: var(--primary-color);
}

/* Custom component styles */
.client-header {
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  color: white;
}

.client-card {
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.2s;
}

.client-card:hover {
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
`;
}

function generateDashboardJS(clientName: string): string {
  return `// Custom dashboard functionality for ${clientName}
console.log('Dashboard loaded for ${clientName}');

class ClientDashboard {
  constructor() {
    this.clientName = '${clientName}';
    this.init();
  }
  
  init() {
    this.loadStats();
    this.setupEventListeners();
  }
  
  async loadStats() {
    try {
      const response = await fetch('/api/dashboard/stats');
      const stats = await response.json();
      this.updateStatsDisplay(stats);
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  }
  
  updateStatsDisplay(stats) {
    const elements = {
      'total-records': stats.totalRecords || 0,
      'total-tables': stats.totalTables || 0,
      'active-users': stats.activeUsers || 0,
      'map-layers': stats.mapLayers || 0
    };
    
    Object.entries(elements).forEach(([id, value]) => {
      const element = document.getElementById(id);
      if (element) element.textContent = value;
    });
  }
  
  setupEventListeners() {
    // Add client-specific event listeners
  }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ClientDashboard();
});
`;
}

function generateDataUploadJS(clientName: string): string {
  return `// Data upload functionality for ${clientName}
console.log('Data upload loaded for ${clientName}');

class ClientDataUpload {
  constructor() {
    this.clientName = '${clientName}';
    this.init();
  }
  
  init() {
    this.setupDropzone();
    this.setupFileHandlers();
  }
  
  setupDropzone() {
    // Dropzone functionality
  }
  
  setupFileHandlers() {
    // File processing handlers
  }
  
  async processUpload(file) {
    // Client-specific upload processing
    console.log(\`Processing upload for \${this.clientName}:\`, file.name);
  }
}

// Initialize upload functionality
document.addEventListener('DOMContentLoaded', () => {
  new ClientDataUpload();
});
`;
}

function generateAnalyticsJS(clientName: string): string {
  return `// Analytics for ${clientName}
console.log('Analytics loaded for ${clientName}');

class ClientAnalytics {
  constructor() {
    this.clientName = '${clientName}';
    this.init();
  }
  
  init() {
    this.trackPageView();
  }
  
  trackPageView() {
    console.log(\`Page view tracked for \${this.clientName}\`);
    // Add analytics provider integration here
  }
  
  trackEvent(action, category, label) {
    console.log(\`Event tracked for \${this.clientName}:\`, { action, category, label });
    // Send to analytics provider
  }
}

// Initialize analytics
const analytics = new ClientAnalytics();

// Export for global use
window.trackEvent = (action, category, label) => {
  analytics.trackEvent(action, category, label);
};
`;
}

function adjustColor(hex: string, percent: number): string {
  // Simple color adjustment function
  const num = parseInt(hex.replace("#", ""), 16);
  const amt = Math.round(2.55 * percent);
  const R = (num >> 16) + amt;
  const G = (num >> 8 & 0x00FF) + amt;
  const B = (num & 0x0000FF) + amt;
  return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
    (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
    (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
}