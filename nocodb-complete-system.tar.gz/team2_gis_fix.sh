#!/bin/bash
echo "=== Team 2 GIS Production Deployment Fix ==="

# Stop current application
echo "Stopping current application..."
pm2 stop team2-standalone-gis 2>/dev/null || true
pm2 delete team2-standalone-gis 2>/dev/null || true

# Create production server that binds to all interfaces
echo "Creating production server..."
cat > /opt/team2-gis/production_server.js << 'EOF'
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5000;
const HOST = '0.0.0.0'; // Bind to all interfaces - this fixes the 502 error

console.log(`Starting Team 2 Standalone GIS Server on ${HOST}:${PORT}`);

// Logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
const distPath = path.join(__dirname, 'dist');
console.log(`Checking for static files at: ${distPath}`);

if (fs.existsSync(distPath)) {
    app.use(express.static(distPath, {
        maxAge: '1d',
        etag: false
    }));
    console.log(`✓ Serving static files from: ${distPath}`);
} else {
    console.log(`⚠ Warning: dist directory not found at ${distPath}`);
}

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        service: 'Team 2 Standalone GIS',
        host: HOST, 
        port: PORT,
        timestamp: new Date().toISOString(),
        distExists: fs.existsSync(distPath),
        uptime: process.uptime()
    });
});

// GIS API endpoints
app.get('/api/super-admin/bases', (req, res) => {
    res.json([{
        "id": 1,
        "name": "Team 2 GIS Base",
        "subdomain": "team2",
        "status": "active",
        "created": new Date().toISOString()
    }]);
});

app.get('/api/workspace/:id', (req, res) => {
    res.json({
        id: req.params.id,
        name: `Workspace ${req.params.id}`,
        tables: [],
        status: 'active'
    });
});

// Catch-all for SPA routing
app.get('*', (req, res) => {
    const indexPath = path.join(distPath, 'index.html');
    
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        // Fallback page when dist files are missing
        res.status(200).send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team 2 Standalone GIS System</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f8f9fa;
        }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .status { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #c3e6cb; }
        .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #ffeaa7; }
        .api-list { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
        h1 { color: #343a40; margin-bottom: 10px; }
        a { color: #007bff; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗺️ Team 2 Standalone GIS System</h1>
        
        <div class="status">
            <h3>✅ Server Status: Running</h3>
            <p><strong>Host:</strong> ${HOST}:${PORT}</p>
            <p><strong>Time:</strong> ${new Date().toISOString()}</p>
            <p><strong>Service:</strong> Team 2 Standalone GIS Platform</p>
            <p><strong>Network:</strong> Externally accessible</p>
        </div>
        
        <div class="warning">
            <h3>⚠️ Frontend Build Missing</h3>
            <p>The React application build files are not present in the dist/ directory.</p>
            <p>Expected location: <code>${distPath}</code></p>
            <p>The server is running correctly but needs the frontend build files to serve the full application.</p>
        </div>
        
        <div class="api-list">
            <h3>📡 Available API Endpoints:</h3>
            <ul>
                <li><a href="/api/health" target="_blank">/api/health</a> - System health check</li>
                <li><a href="/api/super-admin/bases" target="_blank">/api/super-admin/bases</a> - Base configuration</li>
                <li>/api/workspace/:id - Workspace details</li>
            </ul>
        </div>
        
        <p><strong>Server successfully deployed and accessible externally!</strong></p>
    </div>
</body>
</html>
        `);
    }
});

// Error handling
app.use((err, req, res, next) => {
    console.error('Server Error:', err);
    res.status(500).json({ 
        error: 'Internal server error',
        message: err.message,
        timestamp: new Date().toISOString()
    });
});

// Start server
const server = app.listen(PORT, HOST, (err) => {
    if (err) {
        console.error('❌ Failed to start server:', err);
        process.exit(1);
    }
    
    console.log(`✅ Team 2 Standalone GIS Server successfully started!`);
    console.log(`🔗 Local access: http://${HOST}:${PORT}`);
    console.log(`🌐 External access: http://172.232.108.139:${PORT}`);
    console.log(`📁 Static files: ${distPath}`);
    console.log(`🚀 Ready for production traffic`);
});

// Graceful shutdown
const gracefulShutdown = (signal) => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
EOF

# Start the new server with PM2
echo "Starting production server..."
cd /opt/team2-gis
pm2 start production_server.js --name "team2-standalone-gis"
pm2 save

# Restart Nginx to ensure clean proxy state
echo "Restarting Nginx..."
systemctl restart nginx

# Wait for services to start
sleep 3

# Verify deployment
echo "Verifying deployment..."
echo "PM2 Status:"
pm2 status

echo -e "\nPort Binding Check:"
netstat -tlnp | grep :5000

echo -e "\nLocal Application Test:"
curl -I http://localhost:5000

echo -e "\nNginx Proxy Test:"
curl -I http://localhost

echo -e "\nExternal Access Test:"
curl -I http://172.232.108.139

echo -e "\nRecent Nginx Logs:"
tail -5 /var/log/nginx/error.log 2>/dev/null || echo "No recent errors"

echo ""
echo "=== Deployment Complete ==="
echo "✅ Team 2 Standalone GIS System is now accessible at:"
echo "   http://172.232.108.139"
echo ""
echo "🔍 Health check: http://172.232.108.139/api/health"
echo "📊 Admin API: http://172.232.108.139/api/super-admin/bases"
