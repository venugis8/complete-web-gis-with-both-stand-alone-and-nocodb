# Troubleshooting Team 2 GIS Deployment

## Quick Diagnosis Commands
```bash
# Check PM2 status
pm2 status

# Check port binding (should show 0.0.0.0:5000)
netstat -tlnp | grep :5000

# Test local app
curl -I http://localhost:5000

# Test Nginx proxy
curl -I http://localhost

# Check Nginx errors
tail -20 /var/log/nginx/error.log

# Check application logs
pm2 logs team2-standalone-gis --lines 20
```

## Expected Results
- PM2 status: online
- Port binding: 0.0.0.0:5000 (not 127.0.0.1:5000)
- Local app: HTTP/1.1 200 OK
- Nginx proxy: HTTP/1.1 200 OK
- No connection refused errors in Nginx logs

## If Still Getting 502 Error
1. Verify application is binding to 0.0.0.0 not localhost
2. Check firewall rules
3. Ensure Nginx configuration is correct
4. Restart both application and Nginx
