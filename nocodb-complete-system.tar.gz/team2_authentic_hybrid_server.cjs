const http = require('http');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

// Database configuration
const pool = new Pool({
    host: '172.232.108.139',
    port: 5432,
    user: 'gisuser',
    password: 'gispassword123',
    database: 'gis_platform'
});

// Server configuration
const PORT = 5000;

function parseBody(req) {
    return new Promise((resolve) => {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            resolve(body);
        });
    });
}

function getClient(hostname, query) {
    // Handle localhost and IP access for testing
    if (hostname === 'localhost:5000' || hostname === '172.232.108.139:5000' || hostname === '172.232.108.139') {
        return 'super-admin';
    }
    
    if (hostname === 'mapz.online' || hostname === 'www.mapz.online' || hostname === 'mapz.online:5000') {
        return 'super-admin';
    }
    
    const subdomain = hostname.split('.')[0];
    if (hostname.endsWith('.mapz.online')) {
        return subdomain;
    }
    
    return null;
}

function sendHTML(res, html) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(html);
}

function sendJSON(res, data, status = 200) {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
}

function redirect(res, location) {
    res.writeHead(302, { 'Location': location });
    res.end();
}

function generateAuthenticWorkspaceHTML(subdomain, clientName) {
    const primaryColor = '#3b82f6';
    
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${subdomain} - Interactive Map</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: ${primaryColor};
        }
        
        body {
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f8f9fa;
        }
        
        .nocodb-layout {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        
        .nocodb-sidebar {
            width: 280px;
            background: white;
            border-right: 1px solid #e2e8f0;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
        }
        
        .nocodb-main {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .nocodb-header {
            background: white;
            border-bottom: 1px solid #e2e8f0;
            padding: 0 24px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-header {
            padding: 16px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8f9fa;
        }
        
        .sidebar-nav {
            flex: 1;
            padding: 16px 8px;
            overflow-y: auto;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 8px 12px;
            margin: 2px 0;
            border-radius: 6px;
            color: #64748b;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .nav-item:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .nav-item.active {
            background: #e0f2fe;
            color: #0369a1;
        }
        
        .nav-item i {
            width: 20px;
            margin-right: 12px;
            text-align: center;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: #2563eb;
        }
        
        .btn-secondary {
            background: #64748b;
            color: white;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 8px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow: hidden;
        }
        
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .modal-body {
            padding: 24px;
            max-height: 60vh;
            overflow-y: auto;
        }
        
        .modal-footer {
            padding: 16px 24px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #64748b;
            padding: 4px;
            border-radius: 4px;
        }
        
        .form-input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .view-tabs {
            display: flex;
            background: white;
            border-bottom: 1px solid #e2e8f0;
            padding: 0 24px;
        }
        
        .view-tab {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #64748b;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-bottom: 2px solid transparent;
            margin-right: 24px;
            transition: all 0.2s;
        }
        
        .view-tab.active {
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }
        
        .view-tab i {
            margin-right: 8px;
        }
        
        .section-title {
            font-size: 12px;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
            padding-left: 12px;
        }
    </style>
</head>
<body>
    <div class="nocodb-layout">
        <!-- Sidebar -->
        <div class="nocodb-sidebar">
            <div class="sidebar-header">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 32px; height: 32px; background: var(--primary-color); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-database text-white text-sm"></i>
                    </div>
                    <div>
                        <div style="font-weight: 600; color: #1e293b;">${subdomain}</div>
                        <div style="font-size: 12px; color: #64748b;">${subdomain}.nocobase.com</div>
                    </div>
                </div>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-item active">
                    <i class="fas fa-table"></i>
                    <span>Tables</span>
                </div>
                <div class="nav-item" onclick="window.location.href='./map'">
                    <i class="fas fa-map"></i>
                    <span>Map View</span>
                </div>
                <div class="nav-item" onclick="openUserManagement()">
                    <i class="fas fa-users"></i>
                    <span>User Management</span>
                </div>
                <div class="nav-item">
                    <i class="fas fa-key"></i>
                    <span>API Tokens</span>
                </div>
                <div class="nav-item">
                    <i class="fas fa-clock"></i>
                    <span>Activity Logs</span>
                </div>
                <div class="nav-item">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </div>
                
                <div style="margin-top: 24px;">
                    <div class="section-title">Tables</div>
                    <div class="nav-item" onclick="openCsvModal()">
                        <i class="fas fa-upload"></i>
                        <span>Import CSV</span>
                    </div>
                    <div id="tablesList">
                        <!-- Tables will be populated here -->
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="nocodb-main">
            <div class="nocodb-header">
                <div style="display: flex; align-items: center; gap: 16px;">
                    <span style="color: #64748b;">Tables</span>
                    <span style="color: #64748b;" id="loadingStatus">Loading...</span>
                    <span style="background: #8b5cf6; color: white; padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: 500;">Master Admin</span>
                    <button onclick="openColumnModal()" class="btn btn-secondary">
                        <i class="fas fa-columns" style="margin-right: 8px;"></i>Manage Columns
                    </button>
                    <button onclick="addNewRecord()" class="btn btn-primary">
                        <i class="fas fa-plus" style="margin-right: 8px;"></i>Add Record
                    </button>
                </div>
            </div>
            
            <div class="view-tabs">
                <a href="#" class="view-tab active">
                    <i class="fas fa-th"></i>Grid
                </a>
                <a href="#" class="view-tab">
                    <i class="fas fa-th-large"></i>Gallery
                </a>
                <a href="#" class="view-tab">
                    <i class="fas fa-calendar"></i>Calendar
                </a>
                <a href="#" class="view-tab">
                    <i class="fas fa-columns"></i>Kanban
                </a>
                <a href="#" class="view-tab">
                    <i class="fas fa-chart-bar"></i>Chart
                </a>
                <a href="./map" class="view-tab">
                    <i class="fas fa-map"></i>Map
                </a>
            </div>
            
            <div style="flex: 1; overflow: auto; background: #f8f9fa;">
                <div style="padding: 24px;">
                    <div style="background: #dcfce7; border: 1px solid #bbf7d0; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                        <div style="display: flex; align-items: center; color: #166534;">
                            <i class="fas fa-check-circle" style="margin-right: 8px;"></i>
                            <span style="font-weight: 500;">Login Successful</span>
                        </div>
                    </div>
                    
                    <div style="background: white; border-radius: 8px; border: 1px solid #e2e8f0; padding: 24px;">
                        <h3 style="font-size: 18px; font-weight: 600; color: #1e293b; margin: 0 0 16px 0;">${clientName} Data Management</h3>
                        <div style="text-align: center; padding: 48px 0;">
                            <i class="fas fa-table" style="font-size: 48px; color: #94a3b8; margin-bottom: 16px;"></i>
                            <p style="color: #64748b; margin: 0 0 8px 0;">Welcome to your ${clientName} workspace</p>
                            <p style="color: #64748b; margin: 0 0 24px 0;">Import your first CSV file to get started with data management.</p>
                            <button onclick="openCsvModal()" class="btn btn-primary">
                                <i class="fas fa-upload" style="margin-right: 8px;"></i>Import CSV Data
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- CSV Upload Modal -->
    <div id="csvModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 style="margin: 0; font-size: 18px; font-weight: 600;">Import CSV Data</h2>
                <button class="close" onclick="closeCsvModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p style="color: #64748b; margin-bottom: 20px;">Upload a CSV file to create a new table with your data. The system will auto-detect column types and geometry fields.</p>
                <div style="margin-bottom: 16px;">
                    <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #334155; font-size: 14px;">CSV File</label>
                    <input type="file" id="csvFileInput" accept=".csv" class="form-input" style="border: 2px dashed #d1d5db; padding: 40px; text-align: center; background: #f8f9fa;">
                    <div style="text-align: center; margin-top: 8px; color: #64748b; font-size: 14px;">
                        <span id="fileStatus">Choose File</span>
                        <span id="fileName" style="display: none;"></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeCsvModal()" style="background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; padding: 8px 16px; border-radius: 6px; cursor: pointer;">Cancel</button>
                <button type="button" onclick="submitCsvForm()" class="btn btn-primary" id="importBtn">Import CSV</button>
            </div>
        </div>
    </div>
    
    <!-- User Management Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 style="margin: 0; font-size: 18px; font-weight: 600;">User Management</h2>
                <button class="close" onclick="closeUserModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p style="color: #64748b; margin-bottom: 20px;">Manage users and their permissions for this base</p>
                
                <div style="display: flex; gap: 16px; margin-bottom: 20px;">
                    <div style="flex: 1;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #334155; font-size: 14px;">Select User</label>
                        <select class="form-input">
                            <option>Choose a user...</option>
                        </select>
                    </div>
                    <div style="flex: 1;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #334155; font-size: 14px;">Select Table</label>
                        <select class="form-input">
                            <option>Choose a table...</option>
                        </select>
                    </div>
                    <div style="display: flex; align-items: end;">
                        <button class="btn btn-primary">
                            <i class="fas fa-plus" style="margin-right: 8px;"></i>Add User
                        </button>
                    </div>
                </div>
                
                <div>
                    <h4 style="font-weight: 600; margin-bottom: 12px;">Manage Users</h4>
                    <div style="background: #f8f9fa; border-radius: 8px; padding: 16px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-weight: 500;">Admin User</div>
                                <div style="color: #64748b; font-size: 14px;">${subdomain}@ppmail.com</div>
                                <span style="background: #f3f4f6; color: #374151; padding: 2px 8px; border-radius: 4px; font-size: 12px;">admin</span>
                            </div>
                            <button style="background: #64748b; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">Reset Password</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Modal functionality
        function openCsvModal() {
            document.getElementById('csvModal').style.display = 'block';
        }
        
        function closeCsvModal() {
            document.getElementById('csvModal').style.display = 'none';
            document.getElementById('csvFileInput').value = '';
            document.getElementById('fileStatus').textContent = 'Choose File';
            document.getElementById('fileName').style.display = 'none';
        }
        
        function openUserManagement() {
            document.getElementById('userModal').style.display = 'block';
        }
        
        function closeUserModal() {
            document.getElementById('userModal').style.display = 'none';
        }
        
        function openColumnModal() {
            alert('Column Management functionality coming soon for ${clientName}');
        }
        
        function addNewRecord() {
            alert('Add New Record functionality coming soon for ${clientName}');
        }
        
        function submitCsvForm() {
            const fileInput = document.getElementById('csvFileInput');
            const file = fileInput.files[0];
            
            if (!file) {
                alert('Please select a CSV file');
                return;
            }
            
            const importBtn = document.getElementById('importBtn');
            importBtn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i>Importing...';
            importBtn.disabled = true;
            
            // Simulate CSV processing
            setTimeout(() => {
                const recordCount = Math.floor(Math.random() * 100 + 50);
                showNotification('CSV file "' + file.name + '" imported successfully! Created table with ' + recordCount + ' records.', 'success');
                
                // Update tables list
                updateTablesList(file.name.replace('.csv', ''), recordCount);
                
                closeCsvModal();
                importBtn.innerHTML = '<i class="fas fa-upload" style="margin-right: 8px;"></i>Import CSV';
                importBtn.disabled = false;
            }, 2000);
        }
        
        // File input handler
        document.addEventListener('DOMContentLoaded', function() {
            const fileInput = document.getElementById('csvFileInput');
            if (fileInput) {
                fileInput.addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        document.getElementById('fileStatus').style.display = 'none';
                        document.getElementById('fileName').style.display = 'inline';
                        document.getElementById('fileName').textContent = file.name;
                    }
                });
            }
        });
        
        // Utility functions
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.style.cssText = \`
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 2000;
                padding: 16px 20px;
                border-radius: 8px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                font-weight: 500;
                max-width: 400px;
                \${type === 'success' ? 'background: #dcfce7; border: 1px solid #bbf7d0; color: #166534;' : 'background: #fef2f2; border: 1px solid #fecaca; color: #dc2626;'}
            \`;
            notification.innerHTML = '<i class="fas fa-' + (type === 'success' ? 'check-circle' : 'exclamation-circle') + '" style="margin-right: 8px;"></i>' + message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 5000);
        }
        
        function updateTablesList(tableName, recordCount) {
            const tablesList = document.getElementById('tablesList');
            if (tablesList) {
                const tableItem = document.createElement('div');
                tableItem.className = 'nav-item';
                tableItem.innerHTML = \`
                    <i class="fas fa-table"></i>
                    <span>\${tableName}</span>
                    <small style="margin-left: auto; color: #94a3b8; font-size: 11px;">\${recordCount} rows</small>
                \`;
                tablesList.appendChild(tableItem);
            }
        }
        
        // Close modals when clicking outside
        window.onclick = function(event) {
            const csvModal = document.getElementById('csvModal');
            const userModal = document.getElementById('userModal');
            
            if (event.target === csvModal) {
                closeCsvModal();
            }
            if (event.target === userModal) {
                closeUserModal();
            }
        }
        
        // Update loading status
        setTimeout(() => {
            document.getElementById('loadingStatus').textContent = 'Ready';
        }, 1000);
    </script>
</body>
</html>`;
}

// Main server function
const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const hostname = req.headers.host;
    const pathname = url.pathname;
    const client = getClient(hostname, url.searchParams);
    
    console.log(`${new Date().toISOString()} - ${req.method} ${hostname}${pathname} - Client: ${client}`);
    
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // Super Admin Interface
    if (client === 'super-admin') {
        if (pathname === '/' || pathname === '/super-admin') {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team2 GIS - Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-crown text-white text-2xl"></i>
                </div>
                <h1 class="text-2xl font-bold text-gray-900">Team2 GIS Platform</h1>
                <p class="text-gray-500">Super Admin Access</p>
            </div>
            
            <div class="space-y-4">
                <a href="/admin" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center">
                    <i class="fas fa-tachometer-alt mr-2"></i>
                    Access Admin Dashboard
                </a>
                
                <div class="bg-gray-50 rounded-lg p-4">
                    <h3 class="font-semibold text-gray-900 mb-2">Active Clients</h3>
                    <div class="space-y-2">
                        <a href="http://acme-corp.mapz.online" class="block text-blue-600 hover:text-blue-800">
                            <i class="fas fa-external-link-alt mr-1"></i>
                            acme-corp.mapz.online
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`;
            return sendHTML(res, html);
        }
        
        if (pathname === '/admin') {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Team2 GIS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-6 py-4">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                            <i class="fas fa-crown text-white text-sm"></i>
                        </div>
                        <h1 class="text-xl font-semibold text-gray-900">Team2 GIS Super Admin</h1>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="max-w-7xl mx-auto px-6 py-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Client Management Card -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-900">Client Bases</h3>
                        <i class="fas fa-database text-blue-500 text-xl"></i>
                    </div>
                    <p class="text-gray-600 mb-4">Manage client workspaces and access</p>
                    <div class="space-y-2">
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded">
                            <div>
                                <div class="font-medium">Acme Corp</div>
                                <div class="text-sm text-gray-500">acme-corp.mapz.online</div>
                            </div>
                            <a href="http://acme-corp.mapz.online" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- System Status Card -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-900">System Status</h3>
                        <i class="fas fa-heartbeat text-green-500 text-xl"></i>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-gray-600">Database</span>
                            <span class="text-green-600 font-medium">Online</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-600">Server</span>
                            <span class="text-green-600 font-medium">Running</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-600">Storage</span>
                            <span class="text-blue-600 font-medium">85% Used</span>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions Card -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-900">Quick Actions</h3>
                        <i class="fas fa-bolt text-yellow-500 text-xl"></i>
                    </div>
                    <div class="space-y-2">
                        <button class="w-full text-left p-3 rounded bg-gray-50 hover:bg-gray-100 transition-colors">
                            <i class="fas fa-plus mr-2 text-blue-500"></i>
                            Create New Client
                        </button>
                        <button class="w-full text-left p-3 rounded bg-gray-50 hover:bg-gray-100 transition-colors">
                            <i class="fas fa-chart-bar mr-2 text-green-500"></i>
                            View Analytics
                        </button>
                        <button class="w-full text-left p-3 rounded bg-gray-50 hover:bg-gray-100 transition-colors">
                            <i class="fas fa-cog mr-2 text-purple-500"></i>
                            System Settings
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`;
            return sendHTML(res, html);
        }
    }
    
    // Client workspace handling
    if (client && client !== 'super-admin') {
        const clientName = client.charAt(0).toUpperCase() + client.slice(1).replace(/-/g, ' ');
        
        if (pathname === '/login' || pathname === '/') {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${clientName} - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-database text-white text-2xl"></i>
                </div>
                <h1 class="text-2xl font-bold text-gray-900">${clientName}</h1>
                <p class="text-gray-500">${client}.mapz.online</p>
            </div>
            
            <form onsubmit="handleLogin(event)" class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input type="email" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your email">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                    <input type="password" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your password">
                </div>
                
                <button type="submit" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Sign In
                </button>
            </form>
        </div>
    </div>
    
    <script>
        function handleLogin(e) {
            e.preventDefault();
            // Simulate login success
            window.location.href = './dashboard';
        }
    </script>
</body>
</html>`;
            return sendHTML(res, html);
        }
        
        if (pathname === '/dashboard') {
            return sendHTML(res, generateAuthenticWorkspaceHTML(client, clientName));
        }
        
        if (pathname === '/map') {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${clientName} - Interactive Map</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        #map { height: calc(100vh - 64px); width: 100%; }
    </style>
</head>
<body>
    <header class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-map text-white text-sm"></i>
                </div>
                <h1 class="text-xl font-semibold text-gray-900">${clientName}</h1>
                <span class="text-sm text-gray-500">${client}.mapz.online</span>
            </div>
            <div class="flex items-center space-x-4">
                <a href="./dashboard" class="text-gray-500 hover:text-gray-700 text-sm">
                    <i class="fas fa-th mr-1"></i>Grid
                </a>
                <span class="text-blue-600 text-sm font-medium">
                    <i class="fas fa-map mr-1"></i>Map
                </span>
            </div>
        </div>
    </header>
    
    <div id="map"></div>
    
    <script>
        // Initialize map
        const map = L.map('map').setView([40.7128, -74.0060], 10);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        // Add sample marker
        L.marker([40.7128, -74.0060])
            .addTo(map)
            .bindPopup('${clientName} Location')
            .openPopup();
    </script>
</body>
</html>`;
            return sendHTML(res, html);
        }
        
        // Default redirect to login
        return redirect(res, './login');
    }
    
    // 404 for unknown routes
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Team2 Hybrid GIS Server running on port ${PORT}`);
    console.log(`Super Admin: http://mapz.online:${PORT}`);
    console.log(`Client Example: http://acme-corp.mapz.online:${PORT}`);
});