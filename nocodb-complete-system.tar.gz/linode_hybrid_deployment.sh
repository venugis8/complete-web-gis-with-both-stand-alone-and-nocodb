#!/bin/bash

# Hybrid GIS Platform Deployment Script for Linode
# Deploys single-server architecture with client isolation

set -e

echo "=== Starting Hybrid GIS Platform Deployment ==="

# Configuration
DEPLOY_DIR="/opt/hybrid-gis-platform"
BACKUP_DIR="/opt/backups"
DB_HOST="localhost"
DB_PORT="5432"
DB_USER="gisuser"
DB_PASS="gispassword123"
DB_NAME="hybrid_gis"

# Create directories
mkdir -p $DEPLOY_DIR
mkdir -p $BACKUP_DIR
mkdir -p $DEPLOY_DIR/shared/{assets,templates}
mkdir -p $DEPLOY_DIR/clients
mkdir -p $DEPLOY_DIR/logs

cd $DEPLOY_DIR

echo "Creating unified hybrid server..."

# Create main hybrid server
cat > server.js << 'EOF'
const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const csv = require('csv-parser');

const app = express();
const PORT = process.env.PORT || 5000;

// Database configuration
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  user: process.env.DB_USER || 'gisuser',
  password: process.env.DB_PASS || 'gispassword123',
  database: process.env.DB_NAME || 'hybrid_gis',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(session({
  secret: 'hybrid-gis-secret-key-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// Client context middleware
app.use((req, res, next) => {
  const hostname = req.get('host') || '';
  let subdomain = '';
  
  // Extract subdomain from hostname
  if (hostname.includes('.mapz.in')) {
    subdomain = hostname.split('.')[0];
  } else if (req.query.client) {
    subdomain = req.query.client;
  } else if (hostname.includes('localhost') || hostname.includes('172.232.108.139')) {
    subdomain = req.query.client || 'demo';
  }
  
  // Load client configuration
  const clientConfig = loadClientConfig(subdomain);
  req.client = {
    subdomain: subdomain || 'demo',
    config: clientConfig,
    isAdmin: subdomain === 'admin' || req.path.startsWith('/super-admin')
  };
  
  next();
});

// File upload configuration
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 50 * 1024 * 1024 }
});

// Utility functions
function loadClientConfig(subdomain) {
  const configPath = path.join(__dirname, 'clients', subdomain, 'config.json');
  
  if (fs.existsSync(configPath)) {
    try {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    } catch (error) {
      console.error(`Error loading config for ${subdomain}:`, error.message);
    }
  }
  
  // Default configuration
  return {
    name: subdomain,
    features: {
      mapFeatures: {
        enabled: true,
        advancedMeasurement: true,
        customLayers: true,
        drawingTools: true
      },
      dataFeatures: {
        csvUpload: true,
        customReports: true,
        dataExport: ["csv", "excel"]
      },
      userManagement: {
        enabled: true,
        fieldLevelPermissions: true,
        roleBased: true
      }
    },
    branding: {
      title: `${subdomain} GIS Platform`,
      primaryColor: "#2563eb",
      logo: "/assets/logo.png"
    }
  };
}

function getClientTableName(subdomain, tableName) {
  return `client_${subdomain}_${tableName}`;
}

async function hashPassword(password) {
  return await bcrypt.hash(password, 10);
}

async function verifyPassword(password, hash) {
  return await bcrypt.compare(password, hash);
}

function serveTemplate(templateName, subdomain, customData = {}) {
  // Check for client-specific template
  const clientTemplatePath = path.join(__dirname, 'clients', subdomain, `${templateName}.html`);
  const sharedTemplatePath = path.join(__dirname, 'shared', 'templates', `${templateName}.html`);
  
  let templatePath = sharedTemplatePath;
  if (fs.existsSync(clientTemplatePath)) {
    templatePath = clientTemplatePath;
  }
  
  if (!fs.existsSync(templatePath)) {
    return generateDefaultTemplate(templateName, subdomain, customData);
  }
  
  let template = fs.readFileSync(templatePath, 'utf8');
  
  // Apply client configuration and custom data
  const clientConfig = loadClientConfig(subdomain);
  const templateData = { ...clientConfig, ...customData, subdomain };
  
  // Replace template variables
  template = template.replace(/\{\{([^}]+)\}\}/g, (match, key) => {
    const keys = key.split('.');
    let value = templateData;
    for (const k of keys) {
      value = value?.[k];
    }
    return value || '';
  });
  
  return template;
}

function generateDefaultTemplate(templateName, subdomain, data) {
  const config = loadClientConfig(subdomain);
  
  if (templateName === 'login') {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${config.branding.title} - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root { --primary-color: ${config.branding.primaryColor}; }
        .btn-primary { background-color: var(--primary-color); }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full space-y-8">
        <div>
            <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                ${config.branding.title}
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">Sign in to your account</p>
        </div>
        <form class="mt-8 space-y-6" action="/api/auth/login" method="POST">
            <input type="hidden" name="client" value="${subdomain}">
            <div class="rounded-md shadow-sm -space-y-px">
                <div>
                    <input id="email" name="email" type="email" required 
                           class="relative block w-full px-3 py-2 border border-gray-300 rounded-t-md placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                           placeholder="Email address">
                </div>
                <div>
                    <input id="password" name="password" type="password" required
                           class="relative block w-full px-3 py-2 border border-gray-300 rounded-b-md placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                           placeholder="Password">
                </div>
            </div>
            <div>
                <button type="submit" class="btn-primary relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Sign in
                </button>
            </div>
        </form>
    </div>
</body>
</html>`;
  }
  
  if (templateName === 'workspace') {
    return generateWorkspaceTemplate(subdomain, config, data);
  }
  
  return '<h1>Template not found</h1>';
}

function generateWorkspaceTemplate(subdomain, config, data) {
  const features = config.features || {};
  const user = data.user || {};
  
  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${config.branding.title} - Workspace</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .sidebar { width: 300px; min-height: 100vh; }
        .main-content { margin-left: 300px; }
        .map-container { height: calc(100vh - 60px); }
        .csv-upload-area { border: 2px dashed #ccc; padding: 20px; text-align: center; margin: 10px 0; }
        .csv-upload-area:hover { border-color: #007cba; }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b px-6 py-3 flex justify-between items-center fixed w-full top-0 z-50">
        <h1 class="text-xl font-semibold">${config.branding.title}</h1>
        <div class="flex items-center space-x-4">
            <span class="text-sm text-gray-600">Welcome, ${user.name || 'User'}</span>
            <button onclick="logout()" class="text-sm text-red-600 hover:text-red-800">Logout</button>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="sidebar bg-white shadow-lg fixed left-0 top-14 overflow-y-auto">
        <div class="p-4">
            <!-- CSV Upload Section -->
            ${features.dataFeatures?.csvUpload ? `
            <div class="mb-6">
                <h3 class="text-lg font-medium mb-3">Data Upload</h3>
                <div class="csv-upload-area" id="csv-drop-area">
                    <div class="mb-3">
                        <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        <p class="mt-2 text-sm text-gray-600">Drop CSV file here or</p>
                        <input type="file" id="csv-file-input" accept=".csv" class="hidden">
                        <button onclick="document.getElementById('csv-file-input').click()" class="mt-2 bg-blue-500 text-white px-4 py-2 rounded text-sm hover:bg-blue-600">Choose File</button>
                    </div>
                </div>
                <div id="upload-progress" class="hidden">
                    <div class="bg-gray-200 rounded-full h-2">
                        <div class="bg-blue-600 h-2 rounded-full" style="width: 0%" id="progress-bar"></div>
                    </div>
                    <p class="text-sm text-gray-600 mt-1" id="progress-text">Uploading...</p>
                </div>
            </div>
            ` : ''}
            
            <!-- Data Tables -->
            <div class="mb-6">
                <h3 class="text-lg font-medium mb-3">Data Tables</h3>
                <div id="tables-list" class="space-y-2">
                    <div class="text-sm text-gray-500">Loading tables...</div>
                </div>
            </div>
            
            <!-- Map Controls -->
            ${features.mapFeatures?.enabled ? `
            <div class="mb-6">
                <h3 class="text-lg font-medium mb-3">Map Controls</h3>
                <div class="space-y-2">
                    <button onclick="fitMapToData()" class="w-full bg-green-500 text-white px-3 py-2 rounded text-sm hover:bg-green-600">Zoom to Data</button>
                    <button onclick="toggleMeasurement()" class="w-full bg-purple-500 text-white px-3 py-2 rounded text-sm hover:bg-purple-600">Measurement Tool</button>
                    <button onclick="exportData()" class="w-full bg-orange-500 text-white px-3 py-2 rounded text-sm hover:bg-orange-600">Export Data</button>
                </div>
            </div>
            ` : ''}
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content pt-14">
        <div class="map-container" id="map"></div>
    </div>
    
    <!-- Modals and Overlays -->
    <div id="field-mapping-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-96 overflow-y-auto">
            <h3 class="text-lg font-semibold mb-4">Configure Field Types</h3>
            <div id="field-mapping-content"></div>
            <div class="flex justify-end space-x-3 mt-6">
                <button onclick="closeFieldMapping()" class="px-4 py-2 text-gray-600 border rounded hover:bg-gray-50">Cancel</button>
                <button onclick="confirmFieldMapping()" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Confirm Upload</button>
            </div>
        </div>
    </div>
    
    <script>
        // Global variables
        let map;
        let currentLayer;
        let csvData = null;
        let fieldMapping = {};
        const API_BASE = '/api';
        const CLIENT_ID = '${subdomain}';
        
        // Initialize application
        document.addEventListener('DOMContentLoaded', function() {
            initializeMap();
            loadTables();
            setupCSVUpload();
        });
        
        // Map initialization
        function initializeMap() {
            map = L.map('map').setView([40.7128, -74.0060], 10);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);
        }
        
        // CSV Upload functionality
        function setupCSVUpload() {
            const fileInput = document.getElementById('csv-file-input');
            const dropArea = document.getElementById('csv-drop-area');
            
            if (!fileInput || !dropArea) return;
            
            fileInput.addEventListener('change', handleFileSelect);
            
            dropArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropArea.style.borderColor = '#007cba';
            });
            
            dropArea.addEventListener('dragleave', (e) => {
                e.preventDefault();
                dropArea.style.borderColor = '#ccc';
            });
            
            dropArea.addEventListener('drop', (e) => {
                e.preventDefault();
                dropArea.style.borderColor = '#ccc';
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    processCSVFile(files[0]);
                }
            });
        }
        
        function handleFileSelect(event) {
            const file = event.target.files[0];
            if (file) {
                processCSVFile(file);
            }
        }
        
        function processCSVFile(file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const csvText = e.target.result;
                parseCSVData(csvText, file.name);
            };
            reader.readAsText(file);
        }
        
        function parseCSVData(csvText, filename) {
            const lines = csvText.split('\\n');
            if (lines.length < 2) {
                alert('CSV file must have at least a header row and one data row');
                return;
            }
            
            const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
            const sampleRow = lines[1].split(',').map(c => c.trim().replace(/"/g, ''));
            
            csvData = {
                filename: filename.replace('.csv', ''),
                headers: headers,
                sample: sampleRow,
                fullData: csvText
            };
            
            showFieldMappingModal();
        }
        
        function showFieldMappingModal() {
            const modal = document.getElementById('field-mapping-modal');
            const content = document.getElementById('field-mapping-content');
            
            let html = '<div class="space-y-4">';
            html += '<p class="text-sm text-gray-600 mb-4">Configure field types for your data:</p>';
            
            csvData.headers.forEach((header, index) => {
                const sample = csvData.sample[index] || '';
                const detectedType = detectFieldType(sample);
                
                html += \`
                    <div class="border rounded p-3">
                        <div class="flex justify-between items-center mb-2">
                            <strong>\${header}</strong>
                            <span class="text-sm text-gray-500">Sample: \${sample}</span>
                        </div>
                        <select class="w-full border rounded px-2 py-1" data-field="\${header}">
                            <option value="text" \${detectedType === 'text' ? 'selected' : ''}>Text</option>
                            <option value="number" \${detectedType === 'number' ? 'selected' : ''}>Number</option>
                            <option value="date" \${detectedType === 'date' ? 'selected' : ''}>Date</option>
                            <option value="geometry" \${detectedType === 'geometry' ? 'selected' : ''}>Geometry</option>
                            <option value="ignore">Ignore</option>
                        </select>
                    </div>
                \`;
            });
            
            html += '</div>';
            content.innerHTML = html;
            modal.classList.remove('hidden');
        }
        
        function detectFieldType(sample) {
            if (!sample) return 'text';
            
            // Check for geometry patterns
            if (sample.includes('POLYGON') || sample.includes('POINT') || sample.includes('LINESTRING')) {
                return 'geometry';
            }
            
            // Check for numbers
            if (!isNaN(sample) && !isNaN(parseFloat(sample))) {
                return 'number';
            }
            
            // Check for dates
            if (Date.parse(sample)) {
                return 'date';
            }
            
            return 'text';
        }
        
        function closeFieldMapping() {
            document.getElementById('field-mapping-modal').classList.add('hidden');
            csvData = null;
        }
        
        function confirmFieldMapping() {
            const selects = document.querySelectorAll('#field-mapping-content select');
            fieldMapping = {};
            
            selects.forEach(select => {
                const field = select.dataset.field;
                const type = select.value;
                if (type !== 'ignore') {
                    fieldMapping[field] = type;
                }
            });
            
            uploadCSVData();
        }
        
        async function uploadCSVData() {
            try {
                showProgress(0, 'Preparing upload...');
                
                const response = await fetch(\`\${API_BASE}/upload-csv\`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        client: CLIENT_ID,
                        filename: csvData.filename,
                        csvData: csvData.fullData,
                        fieldMapping: fieldMapping
                    })
                });
                
                if (!response.ok) {
                    throw new Error(\`Upload failed: \${response.statusText}\`);
                }
                
                showProgress(100, 'Upload complete!');
                setTimeout(() => {
                    hideProgress();
                    closeFieldMapping();
                    loadTables();
                    alert('CSV data uploaded successfully!');
                }, 1000);
                
            } catch (error) {
                hideProgress();
                alert('Upload failed: ' + error.message);
                console.error('Upload error:', error);
            }
        }
        
        function showProgress(percent, text) {
            const progressDiv = document.getElementById('upload-progress');
            const progressBar = document.getElementById('progress-bar');
            const progressText = document.getElementById('progress-text');
            
            progressDiv.classList.remove('hidden');
            progressBar.style.width = percent + '%';
            progressText.textContent = text;
        }
        
        function hideProgress() {
            document.getElementById('upload-progress').classList.add('hidden');
        }
        
        // Load and display tables
        async function loadTables() {
            try {
                const response = await fetch(\`\${API_BASE}/tables?client=\${CLIENT_ID}\`);
                const tables = await response.json();
                
                const tablesList = document.getElementById('tables-list');
                if (tables.length === 0) {
                    tablesList.innerHTML = '<div class="text-sm text-gray-500">No tables found</div>';
                    return;
                }
                
                tablesList.innerHTML = tables.map(table => \`
                    <div class="p-2 border rounded cursor-pointer hover:bg-gray-50" onclick="loadTableData('\${table.table_name}')">
                        <div class="font-medium text-sm">\${table.display_name || table.table_name}</div>
                        <div class="text-xs text-gray-500">\${table.has_geometry ? 'Has geometry' : 'No geometry'}</div>
                    </div>
                \`).join('');
                
            } catch (error) {
                console.error('Error loading tables:', error);
            }
        }
        
        // Load table data and display on map
        async function loadTableData(tableName) {
            try {
                const response = await fetch(\`\${API_BASE}/table-data/\${tableName}?client=\${CLIENT_ID}\`);
                const data = await response.json();
                
                if (currentLayer) {
                    map.removeLayer(currentLayer);
                }
                
                if (data.length === 0) {
                    alert('No data found in table');
                    return;
                }
                
                // Find geometry column
                const sample = data[0];
                let geometryColumn = null;
                
                for (const [key, value] of Object.entries(sample)) {
                    if (typeof value === 'string' && (value.includes('POLYGON') || value.includes('POINT') || value.includes('LINESTRING'))) {
                        geometryColumn = key;
                        break;
                    }
                }
                
                if (geometryColumn) {
                    displayGeometryData(data, geometryColumn);
                } else {
                    alert('No geometry data found in table');
                }
                
            } catch (error) {
                console.error('Error loading table data:', error);
                alert('Error loading table data');
            }
        }
        
        function displayGeometryData(data, geometryColumn) {
            const features = data.map(row => {
                try {
                    const wkt = row[geometryColumn];
                    const geometry = parseWKT(wkt);
                    
                    return {
                        type: 'Feature',
                        geometry: geometry,
                        properties: row
                    };
                } catch (error) {
                    console.error('Error parsing geometry:', error);
                    return null;
                }
            }).filter(f => f !== null);
            
            if (features.length === 0) {
                alert('No valid geometry found');
                return;
            }
            
            currentLayer = L.geoJSON(features, {
                onEachFeature: function(feature, layer) {
                    const props = feature.properties;
                    let popupContent = '<div class="p-2">';
                    
                    for (const [key, value] of Object.entries(props)) {
                        if (key !== geometryColumn) {
                            popupContent += \`<div><strong>\${key}:</strong> \${value}</div>\`;
                        }
                    }
                    
                    popupContent += '</div>';
                    layer.bindPopup(popupContent);
                }
            }).addTo(map);
            
            map.fitBounds(currentLayer.getBounds());
        }
        
        function parseWKT(wkt) {
            // Simple WKT parser for basic geometries
            if (wkt.startsWith('POINT')) {
                const coords = wkt.match(/POINT\s*\(\s*([^)]+)\)/)[1].split(/\s+/);
                return {
                    type: 'Point',
                    coordinates: [parseFloat(coords[0]), parseFloat(coords[1])]
                };
            } else if (wkt.startsWith('POLYGON')) {
                const coordsStr = wkt.match(/POLYGON\s*\(\s*\(([^)]+)\)/)[1];
                const coords = coordsStr.split(',').map(coord => {
                    const [x, y] = coord.trim().split(/\s+/);
                    return [parseFloat(x), parseFloat(y)];
                });
                return {
                    type: 'Polygon',
                    coordinates: [coords]
                };
            } else if (wkt.startsWith('MULTIPOLYGON')) {
                // Basic MULTIPOLYGON parsing
                const matches = wkt.match(/MULTIPOLYGON\s*\(\s*(.+)\s*\)/);
                if (matches) {
                    // This is a simplified parser - would need more robust parsing for complex cases
                    const polygonStrings = matches[1].split(/\)\s*,\s*\(/);
                    const coordinates = polygonStrings.map(polyStr => {
                        const coordsStr = polyStr.replace(/[()]/g, '');
                        const coords = coordsStr.split(',').map(coord => {
                            const [x, y] = coord.trim().split(/\s+/);
                            return [parseFloat(x), parseFloat(y)];
                        });
                        return [coords];
                    });
                    return {
                        type: 'MultiPolygon',
                        coordinates: coordinates
                    };
                }
            }
            
            throw new Error('Unsupported geometry type');
        }
        
        // Map control functions
        function fitMapToData() {
            if (currentLayer) {
                map.fitBounds(currentLayer.getBounds());
            }
        }
        
        function toggleMeasurement() {
            alert('Measurement tool - feature in development');
        }
        
        function exportData() {
            alert('Export data - feature in development');
        }
        
        function logout() {
            window.location.href = '/api/auth/logout?client=' + CLIENT_ID;
        }
    </script>
</body>
</html>`;
}

// Routes

// Authentication routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password, client } = req.body;
    const subdomain = client || req.client.subdomain;
    
    const userTable = getClientTableName(subdomain, 'users');
    
    const result = await pool.query(
      `SELECT * FROM ${userTable} WHERE email = $1`,
      [email]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const user = result.rows[0];
    const isValid = await verifyPassword(password, user.password_hash);
    
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    req.session.userId = user.id;
    req.session.client = subdomain;
    
    res.redirect(`/workspace?client=${subdomain}`);
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.get('/api/auth/logout', (req, res) => {
  const client = req.query.client || req.client.subdomain;
  req.session.destroy();
  res.redirect(`/login?client=${client}`);
});

// Client workspace routes
app.get('/login', (req, res) => {
  const client = req.query.client || req.client.subdomain;
  res.send(serveTemplate('login', client));
});

app.get('/workspace', async (req, res) => {
  const client = req.query.client || req.client.subdomain;
  
  if (!req.session.userId) {
    return res.redirect(`/login?client=${client}`);
  }
  
  try {
    const userTable = getClientTableName(client, 'users');
    const result = await pool.query(
      `SELECT * FROM ${userTable} WHERE id = $1`,
      [req.session.userId]
    );
    
    if (result.rows.length === 0) {
      return res.redirect(`/login?client=${client}`);
    }
    
    const user = result.rows[0];
    res.send(serveTemplate('workspace', client, { user }));
    
  } catch (error) {
    console.error('Workspace error:', error);
    res.redirect(`/login?client=${client}`);
  }
});

// API routes
app.get('/api/tables', async (req, res) => {
  try {
    const client = req.query.client || req.client.subdomain;
    const tablesTable = getClientTableName(client, 'tables');
    
    const result = await pool.query(`SELECT * FROM ${tablesTable} ORDER BY display_name`);
    res.json(result.rows);
    
  } catch (error) {
    console.error('Error fetching tables:', error);
    res.status(500).json({ error: 'Failed to fetch tables' });
  }
});

app.get('/api/table-data/:tableName', async (req, res) => {
  try {
    const client = req.query.client || req.client.subdomain;
    const { tableName } = req.params;
    const fullTableName = getClientTableName(client, tableName);
    
    const result = await pool.query(`SELECT * FROM ${fullTableName} LIMIT 1000`);
    res.json(result.rows);
    
  } catch (error) {
    console.error('Error fetching table data:', error);
    res.status(500).json({ error: 'Failed to fetch table data' });
  }
});

app.post('/api/upload-csv', async (req, res) => {
  try {
    const { client, filename, csvData, fieldMapping } = req.body;
    const subdomain = client || req.client.subdomain;
    
    // Parse CSV data
    const lines = csvData.split('\n').filter(line => line.trim());
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const dataRows = lines.slice(1).map(line => 
      line.split(',').map(cell => cell.trim().replace(/"/g, ''))
    );
    
    // Create table
    const tableName = filename.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const fullTableName = getClientTableName(subdomain, tableName);
    
    // Build CREATE TABLE statement
    let createSQL = `CREATE TABLE IF NOT EXISTS ${fullTableName} (id SERIAL PRIMARY KEY`;
    let hasGeometry = false;
    
    Object.entries(fieldMapping).forEach(([field, type]) => {
      const columnName = field.toLowerCase().replace(/[^a-z0-9]/g, '_');
      
      switch (type) {
        case 'geometry':
          createSQL += `, ${columnName} TEXT`;
          hasGeometry = true;
          break;
        case 'number':
          createSQL += `, ${columnName} NUMERIC`;
          break;
        case 'date':
          createSQL += `, ${columnName} DATE`;
          break;
        default:
          createSQL += `, ${columnName} TEXT`;
      }
    });
    
    createSQL += ')';
    
    await pool.query(createSQL);
    
    // Insert data
    const mappedHeaders = Object.keys(fieldMapping).map(h => 
      h.toLowerCase().replace(/[^a-z0-9]/g, '_')
    );
    
    const insertSQL = `INSERT INTO ${fullTableName} (${mappedHeaders.join(', ')}) VALUES (${
      mappedHeaders.map((_, i) => `$${i + 1}`).join(', ')
    })`;
    
    for (const row of dataRows) {
      const values = Object.keys(fieldMapping).map(header => {
        const index = headers.indexOf(header);
        return index >= 0 ? row[index] : null;
      });
      
      await pool.query(insertSQL, values);
    }
    
    // Register table
    const tablesTable = getClientTableName(subdomain, 'tables');
    await pool.query(
      `INSERT INTO ${tablesTable} (table_name, display_name, has_geometry, geometry_column, schema) VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (table_name) DO UPDATE SET 
       display_name = EXCLUDED.display_name,
       has_geometry = EXCLUDED.has_geometry,
       geometry_column = EXCLUDED.geometry_column,
       schema = EXCLUDED.schema`,
      [
        tableName,
        filename,
        hasGeometry,
        hasGeometry ? Object.keys(fieldMapping).find(k => fieldMapping[k] === 'geometry') : null,
        JSON.stringify(fieldMapping)
      ]
    );
    
    res.json({ success: true, tableName, recordCount: dataRows.length });
    
  } catch (error) {
    console.error('CSV upload error:', error);
    res.status(500).json({ error: 'Upload failed: ' + error.message });
  }
});

// Super admin routes
app.get('/super-admin', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hybrid GIS Platform - Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8">Hybrid GIS Platform - Super Admin</h1>
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Create New Client -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Create New Client</h2>
                <form id="create-client-form" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Client Name</label>
                        <input type="text" name="name" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Subdomain</label>
                        <input type="text" name="subdomain" required class="w-full border rounded px-3 py-2" placeholder="client1">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Admin Email</label>
                        <input type="email" name="email" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Admin Password</label>
                        <input type="password" name="password" required class="w-full border rounded px-3 py-2">
                    </div>
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">
                        Create Client
                    </button>
                </form>
            </div>
            
            <!-- Existing Clients -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Existing Clients</h2>
                <div id="clients-list" class="space-y-3">
                    <div class="text-gray-500">Loading...</div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('create-client-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            try {
                const response = await fetch('/api/super-admin/create-client', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Client created successfully!');
                    e.target.reset();
                    loadClients();
                } else {
                    alert('Error: ' + result.error);
                }
            } catch (error) {
                alert('Error creating client: ' + error.message);
            }
        });
        
        async function loadClients() {
            try {
                const response = await fetch('/api/super-admin/clients');
                const clients = await response.json();
                
                const clientsList = document.getElementById('clients-list');
                
                if (clients.length === 0) {
                    clientsList.innerHTML = '<div class="text-gray-500">No clients created yet</div>';
                    return;
                }
                
                clientsList.innerHTML = clients.map(client => \`
                    <div class="border rounded p-3">
                        <div class="flex justify-between items-center">
                            <div>
                                <h3 class="font-medium">\${client.name}</h3>
                                <p class="text-sm text-gray-600">Subdomain: \${client.subdomain}</p>
                            </div>
                            <a href="/login?client=\${client.subdomain}" 
                               class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">
                                Access
                            </a>
                        </div>
                    </div>
                \`).join('');
                
            } catch (error) {
                console.error('Error loading clients:', error);
            }
        }
        
        loadClients();
    </script>
</body>
</html>
  `);
});

app.post('/api/super-admin/create-client', async (req, res) => {
  try {
    const { name, subdomain, email, password } = req.body;
    
    // Create client directory and config
    const clientDir = path.join(__dirname, 'clients', subdomain);
    fs.mkdirSync(clientDir, { recursive: true });
    
    const clientConfig = {
      name: name,
      subdomain: subdomain,
      features: {
        mapFeatures: {
          enabled: true,
          advancedMeasurement: true,
          customLayers: true,
          drawingTools: true
        },
        dataFeatures: {
          csvUpload: true,
          customReports: true,
          dataExport: ["csv", "excel"]
        },
        userManagement: {
          enabled: true,
          fieldLevelPermissions: true,
          roleBased: true
        }
      },
      branding: {
        title: `${name} GIS Platform`,
        primaryColor: "#2563eb"
      }
    };
    
    fs.writeFileSync(
      path.join(clientDir, 'config.json'),
      JSON.stringify(clientConfig, null, 2)
    );
    
    // Create client database tables
    const userTable = getClientTableName(subdomain, 'users');
    const tablesTable = getClientTableName(subdomain, 'tables');
    const permissionsTable = getClientTableName(subdomain, 'field_permissions');
    const logsTable = getClientTableName(subdomain, 'activity_logs');
    
    await pool.query(\`
      CREATE TABLE IF NOT EXISTS \${userTable} (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT true
      )
    \`);
    
    await pool.query(\`
      CREATE TABLE IF NOT EXISTS \${tablesTable} (
        id SERIAL PRIMARY KEY,
        table_name VARCHAR(255) UNIQUE NOT NULL,
        display_name VARCHAR(255) NOT NULL,
        has_geometry BOOLEAN DEFAULT false,
        geometry_column VARCHAR(255),
        schema JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    \`);
    
    await pool.query(\`
      CREATE TABLE IF NOT EXISTS \${permissionsTable} (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES \${userTable}(id),
        table_name VARCHAR(255) NOT NULL,
        field_name VARCHAR(255) NOT NULL,
        permission VARCHAR(20) DEFAULT 'view'
      )
    \`);
    
    await pool.query(\`
      CREATE TABLE IF NOT EXISTS \${logsTable} (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES \${userTable}(id),
        action VARCHAR(100) NOT NULL,
        table_name VARCHAR(255),
        changes JSONB,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    \`);
    
    // Create admin user
    const hashedPassword = await hashPassword(password);
    await pool.query(
      \`INSERT INTO \${userTable} (email, password_hash, name, role) VALUES ($1, $2, $3, $4)\`,
      [email, hashedPassword, name + ' Admin', 'admin']
    );
    
    res.json({ success: true });
    
  } catch (error) {
    console.error('Error creating client:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/super-admin/clients', async (req, res) => {
  try {
    const clientsDir = path.join(__dirname, 'clients');
    
    if (!fs.existsSync(clientsDir)) {
      return res.json([]);
    }
    
    const clients = fs.readdirSync(clientsDir)
      .filter(item => fs.statSync(path.join(clientsDir, item)).isDirectory())
      .map(subdomain => {
        try {
          const configPath = path.join(clientsDir, subdomain, 'config.json');
          const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
          return {
            subdomain,
            name: config.name,
            loginUrl: \`/login?client=\${subdomain}\`
          };
        } catch (error) {
          return {
            subdomain,
            name: subdomain,
            loginUrl: \`/login?client=\${subdomain}\`
          };
        }
      });
    
    res.json(clients);
    
  } catch (error) {
    console.error('Error fetching clients:', error);
    res.status(500).json({ error: 'Failed to fetch clients' });
  }
});

// Default route
app.get('/', (req, res) => {
  res.redirect('/super-admin');
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(\`Hybrid GIS Platform running on port \${PORT}\`);
  console.log(\`Super Admin: http://localhost:\${PORT}/super-admin\`);
  console.log(\`Client access: http://localhost:\${PORT}/login?client=CLIENT_NAME\`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await pool.end();
  process.exit(0);
});
EOF

echo "Creating package.json..."
cat > package.json << 'EOF'
{
  "name": "hybrid-gis-platform",
  "version": "1.0.0",
  "description": "Hybrid GIS Platform with Client Isolation",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "node server.js",
    "pm2-start": "pm2 start ecosystem.config.js",
    "pm2-stop": "pm2 stop hybrid-gis",
    "pm2-restart": "pm2 restart hybrid-gis",
    "pm2-logs": "pm2 logs hybrid-gis"
  },
  "dependencies": {
    "express": "^4.18.2",
    "pg": "^8.11.3",
    "bcrypt": "^5.1.1",
    "express-session": "^1.17.3",
    "multer": "^1.4.5-lts.1",
    "csv-parser": "^3.0.0"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF

echo "Creating PM2 ecosystem config..."
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'hybrid-gis',
    script: 'server.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_HOST: '$DB_HOST',
      DB_PORT: '$DB_PORT',
      DB_USER: '$DB_USER',
      DB_PASS: '$DB_PASS',
      DB_NAME: '$DB_NAME'
    },
    error_file: 'logs/error.log',
    out_file: 'logs/out.log',
    log_file: 'logs/combined.log',
    time: true,
    max_memory_restart: '1G',
    watch: false,
    ignore_watch: ['node_modules', 'logs', 'uploads'],
    restart_delay: 5000
  }]
};
EOF

echo "Creating nginx configuration..."
cat > nginx.conf << 'EOF'
server {
    listen 80;
    server_name mapz.in *.mapz.in;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Client size limit for file uploads
    client_max_body_size 50M;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
    }
    
    # Static file caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    
    # Security - block access to sensitive files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    location ~ /(config|logs|uploads) {
        deny all;
        access_log off;
        log_not_found off;
    }
}

# SSL redirect (when SSL is configured)
# server {
#     listen 443 ssl http2;
#     server_name mapz.in *.mapz.in;
#     
#     ssl_certificate /path/to/certificate.crt;
#     ssl_certificate_key /path/to/private.key;
#     ssl_protocols TLSv1.2 TLSv1.3;
#     ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384;
#     
#     # Same proxy configuration as above
#     location / {
#         proxy_pass http://127.0.0.1:5000;
#         # ... rest of proxy config
#     }
# }
EOF

echo "Installing Node.js dependencies..."
npm install

echo "Creating database and tables..."
PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "CREATE DATABASE $DB_NAME;" 2>/dev/null || echo "Database already exists"

echo "Starting hybrid platform..."
pm2 start ecosystem.config.js

echo "=== Hybrid GIS Platform Deployment Complete ==="
echo ""
echo "🚀 Platform Status:"
echo "   - Server running on port 5000"
echo "   - PM2 process: hybrid-gis"
echo "   - Database: $DB_NAME on $DB_HOST:$DB_PORT"
echo ""
echo "🌐 Access URLs:"
echo "   - Super Admin: http://mapz.in/super-admin"
echo "   - Client Login: http://CLIENT.mapz.in/login"
echo "   - Direct Access: http://mapz.in/login?client=CLIENT_NAME"
echo ""
echo "📁 Directory Structure:"
echo "   - Deploy Dir: $DEPLOY_DIR"
echo "   - Client Configs: $DEPLOY_DIR/clients/"
echo "   - Logs: $DEPLOY_DIR/logs/"
echo ""
echo "🔧 Management Commands:"
echo "   - pm2 status"
echo "   - pm2 logs hybrid-gis"
echo "   - pm2 restart hybrid-gis"
echo ""
echo "Next steps:"
echo "1. Configure nginx with the provided nginx.conf"
echo "2. Set up DNS for *.mapz.in to point to this server"
echo "3. Create your first client via Super Admin interface"