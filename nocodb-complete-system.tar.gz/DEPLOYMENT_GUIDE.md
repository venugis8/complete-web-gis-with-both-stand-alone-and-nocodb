# GIS SaaS Platform - Complete Deployment Guide

## Overview

This guide covers deploying the multi-tenant GIS SaaS platform to Linode with three independent environments running on separate ports.

## Quick Start Commands

### One-Command Deployment
```bash
# Deploy complete system to new Linode instance
curl -fsSL https://raw.githubusercontent.com/your-repo/deploy.sh | bash
```

### Manual Deployment Steps
```bash
# 1. Server Setup
apt update && apt upgrade -y
apt install -y nodejs npm postgresql postgresql-contrib nginx

# 2. Application Deployment
git clone https://github.com/your-repo/gis-saas-platform.git
cd gis-saas-platform
npm install
npm run build

# 3. Database Setup
sudo -u postgres psql -c "CREATE DATABASE gisdb;"
sudo -u postgres psql -c "CREATE USER gisuser WITH PASSWORD 'gispassword123';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE gisdb TO gisuser;"

# 4. Start Services
pm2 start ecosystem.config.js
systemctl enable nginx && systemctl start nginx
```

## Environment Configuration

### Three-Port Architecture

#### Production System (Port 5000)
- **Purpose**: Complete multi-tenant SaaS platform
- **URL**: `http://your-server:5000`
- **Features**: Full authentication, multi-tenant isolation, NocoDB integration
- **Process**: `pm2 start complete_production_server.cjs --name team2-gis`

#### Team 1 Development (Port 5001)
- **Purpose**: NocoDB integration development
- **URL**: `http://your-server:5001`
- **Features**: Development environment with NocoDB testing
- **Process**: Reserved for Team 1 development

#### Team 2 Development (Port 5002)
- **Purpose**: Standalone system development
- **URL**: `http://your-server:5002`
- **Features**: Independent development environment
- **Process**: Reserved for Team 2 development

## Server Requirements

### Minimum Specifications
- **CPU**: 2 cores
- **RAM**: 4GB
- **Storage**: 20GB SSD
- **OS**: Ubuntu 20.04+ or CentOS 8+
- **Network**: Public IP with ports 80, 443, 5000-5002 open

### Recommended Specifications
- **CPU**: 4 cores
- **RAM**: 8GB+
- **Storage**: 50GB+ NVMe SSD
- **OS**: Ubuntu 22.04 LTS
- **Network**: 1Gbps connection

## Step-by-Step Deployment

### 1. Server Preparation

#### Initial Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y curl wget git unzip

# Create application user
sudo useradd -m -s /bin/bash gisapp
sudo usermod -aG sudo gisapp
```

#### Node.js Installation
```bash
# Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version  # Should show v20.x.x
npm --version   # Should show 10.x.x
```

#### PM2 Installation
```bash
# Install PM2 globally
sudo npm install -g pm2

# Setup PM2 startup
pm2 startup
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u gisapp --hp /home/gisapp
```

### 2. Database Setup

#### PostgreSQL Installation
```bash
# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### Database Configuration
```bash
# Switch to postgres user and create database
sudo -u postgres psql << EOF
CREATE DATABASE gisdb;
CREATE USER gisuser WITH PASSWORD 'gispassword123';
GRANT ALL PRIVILEGES ON DATABASE gisdb TO gisuser;
ALTER USER gisuser CREATEDB;
\q
EOF

# Enable PostGIS extension
sudo -u postgres psql -d gisdb -c "CREATE EXTENSION IF NOT EXISTS postgis;"
```

#### External Access Configuration
```bash
# Edit PostgreSQL configuration
sudo nano /etc/postgresql/14/main/postgresql.conf
# Add: listen_addresses = '*'

# Edit access control
sudo nano /etc/postgresql/14/main/pg_hba.conf
# Add: host all all 0.0.0.0/0 md5

# Restart PostgreSQL
sudo systemctl restart postgresql
```

### 3. Application Deployment

#### Source Code Setup
```bash
# Clone repository
git clone https://github.com/your-repo/gis-saas-platform.git /opt/team2-gis
cd /opt/team2-gis

# Set ownership
sudo chown -R gisapp:gisapp /opt/team2-gis
```

#### Dependencies Installation
```bash
# Install Node.js dependencies
npm install --production

# Install additional system dependencies
sudo apt install -y build-essential python3-dev
```

#### Environment Configuration
```bash
# Create environment file
cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://gisuser:gispassword123@localhost:5432/gisdb
PORT=5000
HOST=0.0.0.0
EOF
```

### 4. Database Schema Setup

#### Initialize Database
```bash
# Run database migrations
node -e "
const { Pool } = require('pg');
const fs = require('fs');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://gisuser:gispassword123@localhost:5432/gisdb'
});

async function initDatabase() {
  const client = await pool.connect();
  try {
    // Create bases table
    await client.query(\`
      CREATE TABLE IF NOT EXISTS bases (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        subdomain VARCHAR(100) UNIQUE NOT NULL,
        system_mode VARCHAR(50) DEFAULT 'standalone',
        deployment_type VARCHAR(50) DEFAULT 'basic',
        nocodb_url TEXT,
        nocodb_api_key TEXT,
        nocodb_base_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    \`);

    // Create base_users table
    await client.query(\`
      CREATE TABLE IF NOT EXISTS base_users (
        id SERIAL PRIMARY KEY,
        base_id INTEGER REFERENCES bases(id) ON DELETE CASCADE,
        username VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(255),
        role VARCHAR(50) DEFAULT 'user',
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(base_id, email)
      )
    \`);

    // Create remaining tables (sites, sessions, etc.)
    // ... (complete schema creation)

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
  } finally {
    client.release();
  }
}

initDatabase();
"
```

### 5. Nginx Configuration

#### Install and Configure Nginx
```bash
# Install Nginx
sudo apt install -y nginx

# Remove default configuration
sudo rm /etc/nginx/sites-enabled/default

# Create application configuration
sudo tee /etc/nginx/sites-available/team2-gis << EOF
server {
    listen 80;
    server_name team2.172.232.108.139.nip.io _;
    
    # Production system (port 5000)
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # Team 1 development (port 5001)
    location /team1/ {
        proxy_pass http://localhost:5001/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Team 2 development (port 5002)
    location /team2/ {
        proxy_pass http://localhost:5002/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/team2-gis /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. Process Management

#### PM2 Configuration
```bash
# Create PM2 ecosystem file
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [
    {
      name: 'team2-gis',
      script: 'complete_production_server.cjs',
      cwd: '/opt/team2-gis',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 5000,
        HOST: '0.0.0.0',
        DATABASE_URL: 'postgresql://gisuser:gispassword123@localhost:5432/gisdb'
      }
    }
  ]
};
EOF
```

#### Start Application
```bash
# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Check status
pm2 status
pm2 logs team2-gis
```

## Testing Deployment

### Health Checks
```bash
# Test database connection
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT version();"

# Test application
curl -f http://localhost:5000/health || echo "Application not responding"

# Test authentication
curl -X POST http://localhost:5000/api/base/sln/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@sln.com", "password": "admin123"}'
```

### Create Test Base
```bash
# Create test base via API
curl -X POST http://localhost:5000/api/super-admin/bases \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Company",
    "subdomain": "testco",
    "adminEmail": "admin@testco.com",
    "adminPassword": "admin123"
  }'
```

## Standalone Deployment Script

### Automated Deployment
```bash
#!/bin/bash
# deploy-standalone.sh - Deploy GIS system to new Linode instance

set -e

# Configuration
SERVER_IP="your-server-ip"
SSH_KEY_PATH="~/.ssh/id_rsa"
DOMAIN_NAME="your-domain.com"

echo "🚀 Starting deployment to $SERVER_IP"

# 1. Server preparation
ssh -i $SSH_KEY_PATH root@$SERVER_IP << 'ENDSSH'
# Update system
apt update && apt upgrade -y

# Install dependencies
apt install -y nodejs npm postgresql postgresql-contrib nginx git

# Create user
useradd -m -s /bin/bash gisapp
usermod -aG sudo gisapp

# Install PM2
npm install -g pm2
ENDSSH

# 2. Deploy application
scp -i $SSH_KEY_PATH -r ./dist root@$SERVER_IP:/opt/team2-gis/
scp -i $SSH_KEY_PATH ./complete_production_server.cjs root@$SERVER_IP:/opt/team2-gis/
scp -i $SSH_KEY_PATH ./package.json root@$SERVER_IP:/opt/team2-gis/

# 3. Setup services
ssh -i $SSH_KEY_PATH root@$SERVER_IP << 'ENDSSH'
# Database setup
sudo -u postgres psql -c "CREATE DATABASE gisdb;"
sudo -u postgres psql -c "CREATE USER gisuser WITH PASSWORD 'gispassword123';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE gisdb TO gisuser;"

# Install dependencies
cd /opt/team2-gis
npm install --production

# Start application
pm2 start complete_production_server.cjs --name team2-gis
pm2 startup
pm2 save

# Configure Nginx
# ... (nginx configuration)

systemctl restart nginx
ENDSSH

echo "✅ Deployment complete! Access your application at http://$SERVER_IP"
```

## Monitoring and Maintenance

### Application Monitoring
```bash
# PM2 monitoring
pm2 monit

# View logs
pm2 logs team2-gis --lines 100

# Restart application
pm2 restart team2-gis

# View process status
pm2 status
```

### Database Monitoring
```bash
# Check database connections
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity WHERE datname = 'gisdb';"

# Check database size
sudo -u postgres psql -c "SELECT pg_size_pretty(pg_database_size('gisdb'));"

# Backup database
pg_dump -U gisuser -h localhost gisdb > backup_$(date +%Y%m%d_%H%M%S).sql
```

### System Monitoring
```bash
# Check disk space
df -h

# Check memory usage
free -h

# Check CPU usage
top

# Check network connections
netstat -tulpn | grep :5000
```

## Troubleshooting

### Common Issues

#### Application Won't Start
```bash
# Check PM2 logs
pm2 logs team2-gis

# Check Node.js version
node --version

# Check port availability
netstat -tulpn | grep :5000
```

#### Database Connection Issues
```bash
# Test database connection
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT 1;"

# Check PostgreSQL status
systemctl status postgresql

# Check database configuration
sudo -u postgres psql -c "SHOW listen_addresses;"
```

#### Nginx Issues
```bash
# Test Nginx configuration
sudo nginx -t

# Check Nginx logs
sudo tail -f /var/log/nginx/error.log

# Restart Nginx
sudo systemctl restart nginx
```

## Security Considerations

### Firewall Configuration
```bash
# Configure UFW firewall
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 5000:5002/tcp
```

### SSL Certificate (Optional)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

This deployment guide provides comprehensive instructions for setting up the GIS SaaS platform on any Linux server with complete multi-tenant functionality and production-ready configuration.