# GIS SaaS Platform - Architecture Overview

## System Architecture

### High-Level Architecture
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Production    │    │   Team 1 Dev    │    │   Team 2 Dev    │
│   Port 5000     │    │   Port 5001     │    │   Port 5002     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────────────┐
                    │   PostgreSQL Database   │
                    │   Multi-Tenant Schema   │
                    └─────────────────────────┘
```

### Core Components

#### 1. Frontend Architecture
- **Technology**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state, React hooks for local state
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **Map Integration**: Leaflet.js for interactive geospatial visualization
- **Build Tool**: Vite for fast development and optimized builds

#### 2. Backend Architecture
- **Technology**: Node.js with Express.js
- **Database**: PostgreSQL with PostGIS extension for spatial data
- **ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Session-based with multi-tenant isolation
- **Process Management**: PM2 for production deployment
- **API Design**: RESTful endpoints with base-specific routing

#### 3. Database Schema (Multi-Tenant)

##### Core Tables
```sql
-- Base tenant isolation
bases (id, name, subdomain, system_mode, deployment_type, nocodb_url, nocodb_api_key, nocodb_base_id, created_at)

-- User management per base
base_users (id, base_id, username, email, password, name, role, is_active, created_at)

-- Permission system
field_permissions (id, base_id, table_name, field_name, permission_type, user_id, role, created_at)

-- API access control
api_tokens (id, base_id, token, name, permissions, is_active, expires_at, created_at)

-- Magic link deployment
magic_links (id, base_id, token, admin_email, expires_at, is_used, created_at)

-- Site data management
sites (id, base_id, name, location, coordinates, properties, created_at, updated_at)

-- User sessions
user_sessions (id, base_id, user_id, session_token, expires_at, created_at)
```

### Multi-Tenant Isolation Strategy

#### Data Isolation
- **Base ID Filtering**: All queries filtered by `base_id` to ensure complete tenant isolation
- **Session Management**: Base-specific session tokens with format `{subdomain}_{user_id}_{timestamp}`
- **API Routing**: Base-aware endpoints `/api/base/{subdomain}/...`

#### Security Model
- **Authentication**: Email/password with bcrypt hashing (simplified for testing)
- **Authorization**: Role-based access control (admin, user, viewer)
- **Session Management**: Server-side session validation with expiration
- **Cross-Tenant Protection**: Middleware ensures users can only access their base data

### Deployment Architecture

#### Three-Environment Setup
1. **Production System (Port 5000)**
   - Complete multi-tenant SaaS platform
   - Full feature set with authentication
   - PostgreSQL backend with PostGIS

2. **Team 1 Development (Port 5001)**
   - NocoDB integration testing
   - Multi-tenant development environment
   - Shared database with production

3. **Team 2 Development (Port 5002)**
   - Standalone system development
   - Independent testing environment
   - Isolated development workflow

#### Infrastructure Components
- **Server**: Linode VPS (172.232.108.139)
- **Web Server**: Nginx reverse proxy
- **Process Manager**: PM2 for application lifecycle
- **Database**: PostgreSQL 14+ with PostGIS extension
- **Monitoring**: PM2 process monitoring and logging

### Integration Points

#### NocoDB Integration
- **API Connection**: RESTful API integration with NocoDB instances
- **Authentication**: API token-based authentication
- **Data Sync**: Bidirectional data synchronization
- **Schema Management**: Dynamic table and field discovery

#### External Services
- **Maps**: OpenStreetMap tiles via Leaflet
- **Fonts**: Google Fonts integration
- **Icons**: Lucide React and Font Awesome
- **CDN**: Static asset delivery optimization

### Scalability Considerations

#### Horizontal Scaling
- **Database**: PostgreSQL read replicas for query scaling
- **Application**: Multiple Node.js instances behind load balancer
- **Static Assets**: CDN distribution for frontend assets

#### Performance Optimization
- **Database Indexing**: Optimized indexes on base_id and frequently queried fields
- **Connection Pooling**: PostgreSQL connection pool management
- **Caching**: Application-level caching for frequently accessed data
- **Asset Optimization**: Minified and compressed frontend assets

### Security Architecture

#### Data Protection
- **Encryption**: HTTPS/TLS for all communications
- **Database**: Connection encryption and access controls
- **Session Security**: Secure session token generation and validation
- **Input Validation**: Comprehensive input sanitization and validation

#### Access Control
- **Multi-Tenant Isolation**: Complete data separation between tenants
- **Role-Based Permissions**: Granular permission system
- **API Security**: Token-based API access with expiration
- **Audit Logging**: Comprehensive activity logging for compliance

### Monitoring and Maintenance

#### Application Monitoring
- **Process Health**: PM2 process monitoring and auto-restart
- **Performance Metrics**: Response time and throughput monitoring
- **Error Tracking**: Comprehensive error logging and alerting
- **Database Health**: PostgreSQL performance and connection monitoring

#### Backup and Recovery
- **Database Backups**: Automated PostgreSQL backups
- **Application State**: Configuration and deployment state backup
- **Disaster Recovery**: Multi-point recovery procedures
- **Data Integrity**: Regular data validation and consistency checks

## Technology Stack Summary

### Frontend Stack
- React 18 + TypeScript
- Vite build system
- Tailwind CSS + shadcn/ui
- Leaflet.js for maps
- TanStack Query for data fetching
- Wouter for routing

### Backend Stack
- Node.js + Express.js
- PostgreSQL + PostGIS
- Drizzle ORM
- PM2 process management
- Nginx reverse proxy

### Development Tools
- TypeScript for type safety
- ESLint + Prettier for code quality
- Git for version control
- PM2 for production deployment

This architecture provides a robust, scalable foundation for the multi-tenant GIS SaaS platform with clear separation of concerns and comprehensive security measures.