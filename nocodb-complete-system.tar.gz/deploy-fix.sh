#!/bin/bash

# Create the corrected server file
cat > production-server.mjs << 'EOF'
const express = require('express');
const path = require('path');
const React = require('react');
const ReactDOMServer = require('react-dom/server');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static('client-dist'));

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// In-memory storage
const storage = {
  bases: [
    {
      id: 1,
      name: 'Acme Corp Base',
      subdomain: 'acme-corp',
      userCount: 24,
      tableCount: 8,
      systemMode: 'standalone',
      deploymentType: 'standard',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      magicLink: 'https://acme-corp.mapz.in/login',
      adminEmail: 'admin@acme-corp.com'
    },
    {
      id: 2,
      name: 'SSC5',
      subdomain: 'ssc5',
      userCount: 12,
      tableCount: 4,
      systemMode: 'standalone',
      deploymentType: 'standard',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      magicLink: 'https://ssc5.mapz.in/login',
      adminEmail: 'admin@ssc5demo.com'
    },
    {
      id: 4,
      name: 'SSC6',
      subdomain: 'ssc6',
      userCount: 8,
      tableCount: 3,
      systemMode: 'nocodb',
      deploymentType: 'hybrid',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      magicLink: 'https://ssc6.mapz.in/login',
      adminEmail: 'admin@ssc6.com'
    }
  ]
};

// API Routes
app.get('/api/super-admin/bases', (req, res) => {
  console.log('GET /api/super-admin/bases');
  res.json(storage.bases);
});

app.post('/api/super-admin/bases', (req, res) => {
  console.log('POST /api/super-admin/bases - received:', req.body);
  
  // FIXED: Proper subdomain-based magic link generation
  const generateMagicLink = (subdomain) => {
    return `https://${subdomain}.mapz.in/login`;
  };
  
  const newBase = {
    id: Math.max(...storage.bases.map(b => b.id), 0) + 1,
    name: req.body.name || req.body.clientName,
    subdomain: req.body.subdomain,
    systemMode: req.body.deploymentType === 'nocodb' ? 'nocodb' : 'standalone',
    deploymentType: req.body.deploymentType === 'nocodb' ? 'hybrid' : 'standard',
    status: 'active',
    userCount: 0,
    tableCount: 0,
    adminEmail: req.body.adminEmail,
    magicLink: generateMagicLink(req.body.subdomain), // FIXED: Now uses subdomain parameter
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  storage.bases.push(newBase);
  console.log('Created new base with magic link:', newBase.magicLink);
  
  res.json(newBase);
});

app.delete('/api/super-admin/bases/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`DELETE /api/super-admin/bases/${id}`);
  
  const index = storage.bases.findIndex(base => base.id === id);
  if (index !== -1) {
    const deletedBase = storage.bases.splice(index, 1)[0];
    console.log('Deleted base:', deletedBase);
    res.json(deletedBase);
  } else {
    res.status(404).json({ error: 'Base not found' });
  }
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client-dist', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Super Admin available at http://localhost:${PORT}`);
  console.log(`✅ Magic links now generate as: https://subdomain.mapz.in/login`);
});
EOF

echo "✅ Created corrected server file: production-server.mjs"
echo "📝 Key changes:"
echo "   - Magic link generation: https://subdomain.mapz.in/login format"
echo "   - Fixed function parameter passing"
echo "   - Updated existing demo links"
EOF

chmod +x deploy-fix.sh