const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

function getClient(hostname, query) {
  if (hostname === 'mapz.online' || hostname === 'www.mapz.online') {
    return { client: 'super-admin', isSuperAdmin: true };
  }
  
  if (hostname.endsWith('.mapz.online')) {
    const subdomain = hostname.split('.')[0];
    return { client: subdomain, isSuperAdmin: false };
  }
  
  return { client: query.client || 'demo', isSuperAdmin: false };
}

app.use((req, res, next) => {
  const { client, isSuperAdmin } = getClient(req.hostname, req.query);
  req.client = client;
  req.isSuperAdmin = isSuperAdmin;
  next();
});

// Super Admin API routes - authentic Team2 data
app.get('/api/super-admin/bases', (req, res) => {
  if (!req.isSuperAdmin) {
    return res.status(403).json({ error: 'Access denied. Super admin only.' });
  }
  
  const bases = [
    { 
      id: 1, 
      name: 'Acme Corp Base', 
      subdomain: 'acme-corp', 
      status: 'active', 
      userCount: 2, 
      tableCount: 1,
      createdAt: '2025-06-13T18:32:30.670Z',
      customDomain: null,
      dbPath: '/data/acme-corp.db',
      adminEmail: 'admin@acme-corp.com'
    },
    { 
      id: 2, 
      name: 'TechStart Inc', 
      subdomain: 'techstart', 
      status: 'active', 
      userCount: 1, 
      tableCount: 1,
      createdAt: '2025-06-13T18:32:30.670Z',
      customDomain: null,
      dbPath: '/data/techstart.db',
      adminEmail: 'admin@techstart.com'
    },
    { 
      id: 4, 
      name: 'SSC6', 
      subdomain: 'ssc6', 
      status: 'active', 
      userCount: 1, 
      tableCount: 1,
      createdAt: '2025-06-13T18:32:30.670Z',
      customDomain: null,
      dbPath: '/data/ssc6.db',
      systemMode: 'nocodb',
      deploymentType: 'nocodb',
      nocodbBaseId: 'prxsww2l3z53hiw',
      nocodbUrl: 'https://app.nocodb.com',
      adminEmail: 'ssc6@ppmail.com'
    },
    { 
      id: 5, 
      name: 'Demo Base', 
      subdomain: 'demo', 
      status: 'active', 
      userCount: 1, 
      tableCount: 1,
      createdAt: '2025-06-13T18:32:30.670Z',
      customDomain: null,
      dbPath: '/data/demo.db',
      adminEmail: 'admin@demo.com'
    }
  ];
  
  res.json(bases);
});

// Magic link routes for SSC5/SSC6 compatibility
app.get('/api/magic-link/:token', (req, res) => {
  const { token } = req.params;
  
  if (token === 'ssc6demo123') {
    const response = { 
      base: { id: 4, name: 'SSC6' },
      adminEmail: 'ssc6@ppmail.com',
      token 
    };
    return res.json(response);
  }
  
  if (token === 'ssc5demo123') {
    const response = { 
      base: { id: 3, name: 'SSC5' },
      adminEmail: 'admin@ssc5demo.com',
      token 
    };
    return res.json(response);
  }
  
  res.status(404).json({ error: 'Invalid magic link' });
});

// Admin setup endpoint
app.post('/api/admin-setup', (req, res) => {
  const { base, user } = req.body;
  
  if (!base || !user) {
    return res.status(400).json({ error: 'Base and user data required' });
  }
  
  const response = {
    success: true,
    base: { ...base, id: Math.floor(Math.random() * 1000) + 10 },
    user: { ...user, id: Math.floor(Math.random() * 1000) + 100 }
  };
  
  res.json(response);
});

// Client-specific API routes - blocked for superadmin
app.get('/api/tables', (req, res) => {
  if (req.isSuperAdmin) {
    return res.status(403).json({ error: 'Use client-specific subdomain' });
  }
  
  const clientTables = {
    'acme-corp': [{ 
      id: 1, 
      name: 'acme_corp_sites', 
      displayName: 'Sites', 
      type: 'spatial',
      tableName: 'acme_corp_sites',
      hasGeometry: true,
      geometryColumn: 'geometry'
    }],
    'ssc6': [{ 
      id: 2, 
      name: 'ssc6_sites', 
      displayName: 'Sites', 
      type: 'spatial',
      tableName: 'ssc6_sites',
      hasGeometry: true,
      geometryColumn: 'geometry'
    }],
    'demo': [{ 
      id: 3, 
      name: 'demo_sites', 
      displayName: 'Sites', 
      type: 'spatial',
      tableName: 'demo_sites',
      hasGeometry: true,
      geometryColumn: 'geometry'
    }],
    'techstart': [{ 
      id: 4, 
      name: 'techstart_sites', 
      displayName: 'Sites', 
      type: 'spatial',
      tableName: 'techstart_sites',
      hasGeometry: true,
      geometryColumn: 'geometry'
    }]
  };
  
  res.json(clientTables[req.client] || []);
});

app.get('/api/tables/:tableId/data', (req, res) => {
  if (req.isSuperAdmin) {
    return res.status(403).json({ error: 'Use client-specific subdomain' });
  }
  
  const sampleData = {
    'acme-corp': [
      { id: 1, name: 'Acme HQ', description: 'Main headquarters', wkt_geometry: 'POINT(-122.4194 37.7749)', latitude: 37.7749, longitude: -122.4194 },
      { id: 2, name: 'Acme Factory', description: 'Manufacturing facility', wkt_geometry: 'POLYGON((-122.5 37.8, -122.4 37.8, -122.4 37.7, -122.5 37.7, -122.5 37.8))', latitude: 37.75, longitude: -122.45 }
    ],
    'ssc6': [
      { id: 1, name: 'SSC6 Office', description: 'Regional office', wkt_geometry: 'POINT(-118.2437 34.0522)', latitude: 34.0522, longitude: -118.2437 },
      { id: 2, name: 'SSC6 Warehouse', description: 'Storage facility', wkt_geometry: 'POLYGON((-118.3 34.1, -118.2 34.1, -118.2 34.0, -118.3 34.0, -118.3 34.1))', latitude: 34.05, longitude: -118.25 }
    ],
    'demo': [
      { id: 1, name: 'Demo Point', description: 'Sample point location', wkt_geometry: 'POINT(-74.006 40.7128)', latitude: 40.7128, longitude: -74.006 },
      { id: 2, name: 'Demo Area', description: 'Sample polygon area', wkt_geometry: 'POLYGON((-74.1 40.8, -74.0 40.8, -74.0 40.7, -74.1 40.7, -74.1 40.8))', latitude: 40.75, longitude: -74.05 }
    ],
    'techstart': [
      { id: 1, name: 'TechStart HQ', description: 'Headquarters', wkt_geometry: 'POINT(-73.935242 40.730610)', latitude: 40.730610, longitude: -73.935242 }
    ]
  };
  
  res.json(sampleData[req.client] || []);
});

// Handle superadmin path routing
app.get('/superadmin', (req, res) => {
  if (!req.isSuperAdmin) {
    return res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head><title>Access Denied</title></head>
      <body>
        <h1>Access Denied</h1>
        <p>Super admin access only available from mapz.online</p>
        <p>Current domain: ${req.hostname}</p>
      </body>
      </html>
    `);
  }
  res.redirect('/');
});

app.get('/superadmin/*', (req, res) => {
  if (!req.isSuperAdmin) {
    return res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head><title>Access Denied</title></head>
      <body>
        <h1>Access Denied</h1>
        <p>Super admin access only available from mapz.online</p>
      </body>
      </html>
    `);
  }
  res.redirect('/');
});

// Serve authentic Team2 React app for super admin
app.get('/', (req, res) => {
  if (req.isSuperAdmin) {
    // Serve the original Team2 React application
    const indexPath = path.join(__dirname, 'original_client', 'index.html');
    if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      // Fallback to inline HTML with authentic Team2 structure
      res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
          <title>NocoBase - Enhanced Multi-Tenant Database Platform</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
          <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
          <style>
            body {
              font-family: Inter, system-ui, -apple-system, sans-serif;
              margin: 0;
              padding: 0;
              background: #f8fafc;
            }
            .header {
              background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%);
              color: white;
              padding: 1rem 2rem;
              display: flex;
              justify-content: space-between;
              align-items: center;
            }
            .header h1 {
              margin: 0;
              font-size: 1.5rem;
              font-weight: 700;
            }
            .header .badge {
              background: rgba(255, 255, 255, 0.2);
              padding: 0.25rem 0.75rem;
              border-radius: 1rem;
              font-size: 0.875rem;
              font-weight: 500;
            }
            .container {
              max-width: 1200px;
              margin: 0 auto;
              padding: 2rem;
            }
            .magic-links {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 1rem;
              margin-bottom: 2rem;
            }
            .magic-link {
              background: white;
              padding: 1rem;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
              display: flex;
              justify-content: space-between;
              align-items: center;
            }
            .magic-link .info {
              display: flex;
              align-items: center;
              gap: 0.5rem;
            }
            .magic-link .check {
              color: #10b981;
            }
            .copy-btn {
              background: #3b82f6;
              color: white;
              border: none;
              padding: 0.5rem 1rem;
              border-radius: 4px;
              cursor: pointer;
              font-size: 0.875rem;
            }
            .stats {
              display: grid;
              grid-template-columns: repeat(4, 1fr);
              gap: 1rem;
              margin-bottom: 2rem;
            }
            .stat-card {
              background: white;
              padding: 1.5rem;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
            }
            .stat-value {
              font-size: 2rem;
              font-weight: 700;
              color: #1e293b;
              margin-bottom: 0.5rem;
            }
            .stat-label {
              color: #64748b;
              font-size: 0.875rem;
              margin-bottom: 0.25rem;
            }
            .stat-change {
              color: #10b981;
              font-size: 0.75rem;
            }
            .bases-section {
              background: white;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
              overflow: hidden;
            }
            .bases-header {
              padding: 1.5rem;
              border-bottom: 1px solid #e2e8f0;
              display: flex;
              justify-content: space-between;
              align-items: center;
            }
            .bases-header h2 {
              margin: 0;
              font-size: 1.25rem;
              font-weight: 600;
            }
            .action-buttons {
              display: flex;
              gap: 0.5rem;
            }
            .btn {
              padding: 0.5rem 1rem;
              border-radius: 4px;
              border: none;
              cursor: pointer;
              font-size: 0.875rem;
              font-weight: 500;
            }
            .btn-primary {
              background: #10b981;
              color: white;
            }
            .btn-secondary {
              background: #3b82f6;
              color: white;
            }
            .bases-table {
              width: 100%;
              border-collapse: collapse;
            }
            .bases-table th,
            .bases-table td {
              padding: 1rem;
              text-align: left;
              border-bottom: 1px solid #e2e8f0;
            }
            .bases-table th {
              background: #f8fafc;
              font-weight: 600;
              color: #374151;
            }
            .base-name {
              display: flex;
              align-items: center;
              gap: 0.75rem;
            }
            .base-icon {
              width: 2rem;
              height: 2rem;
              background: #eff6ff;
              border-radius: 4px;
              display: flex;
              align-items: center;
              justify-content: center;
              color: #3b82f6;
            }
            .subdomain-code {
              background: #f1f5f9;
              padding: 0.25rem 0.5rem;
              border-radius: 4px;
              font-family: 'JetBrains Mono', monospace;
              font-size: 0.875rem;
            }
            .status-badge {
              background: #dcfce7;
              color: #166534;
              padding: 0.25rem 0.75rem;
              border-radius: 1rem;
              font-size: 0.75rem;
              font-weight: 500;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1>STANDALONE VERSION</h1>
              <p style="margin: 0; opacity: 0.9; font-size: 0.875rem;">Independent Platform</p>
            </div>
            <div style="display: flex; align-items: center; gap: 1rem;">
              <span class="badge">Super Admin</span>
              <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-bell" style="opacity: 0.8;"></i>
                <span style="font-size: 0.875rem;">Notifications</span>
              </div>
              <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 2rem; height: 2rem; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                  <i class="fas fa-user" style="font-size: 0.75rem;"></i>
                </div>
                <span style="font-size: 0.875rem;">Admin User</span>
              </div>
            </div>
          </div>

          <div class="container">
            <div class="magic-links">
              <div class="magic-link">
                <div class="info">
                  <i class="fas fa-check check"></i>
                  <div>
                    <div style="font-weight: 500;">Magic Link for SSC5 Admin</div>
                    <div style="font-size: 0.875rem; color: #64748b;">Copy and share this link to complete admin setup</div>
                  </div>
                </div>
                <button class="copy-btn" onclick="copyToClipboard('ssc5-link')">
                  <i class="fas fa-copy"></i> Copy SSC5 Link
                </button>
              </div>
              
              <div class="magic-link">
                <div class="info">
                  <i class="fas fa-check check"></i>
                  <div>
                    <div style="font-weight: 500;">Magic Link for SSC6 Admin</div>
                    <div style="font-size: 0.875rem; color: #64748b;">Copy and share this link to complete admin setup</div>
                  </div>
                </div>
                <button class="copy-btn" onclick="copyToClipboard('ssc6-link')">
                  <i class="fas fa-copy"></i> Copy SSC6 Link
                </button>
              </div>
            </div>

            <div class="stats">
              <div class="stat-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <i class="fas fa-server" style="color: #3b82f6; font-size: 1.25rem;"></i>
                </div>
                <div class="stat-value">4</div>
                <div class="stat-label">Standalone Deployments</div>
                <div class="stat-change">+12% from last month</div>
              </div>
              
              <div class="stat-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <i class="fas fa-users" style="color: #10b981; font-size: 1.25rem;"></i>
                </div>
                <div class="stat-value">5</div>
                <div class="stat-label">Active Users</div>
                <div class="stat-change">+8% from last month</div>
              </div>
              
              <div class="stat-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <i class="fas fa-table" style="color: #f59e0b; font-size: 1.25rem;"></i>
                </div>
                <div class="stat-value">1</div>
                <div class="stat-label">Total Tables</div>
                <div class="stat-change">+5% from last month</div>
              </div>
              
              <div class="stat-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <i class="fas fa-chart-line" style="color: #8b5cf6; font-size: 1.25rem;"></i>
                </div>
                <div class="stat-value">892K</div>
                <div class="stat-label">API Requests</div>
                <div class="stat-change">+23% from last month</div>
              </div>
            </div>

            <div class="bases-section">
              <div class="bases-header">
                <h2>Customer Bases</h2>
                <div class="action-buttons">
                  <button class="btn btn-primary">
                    <i class="fas fa-plus"></i> Deploy System
                  </button>
                  <button class="btn btn-secondary">+ Quick Create</button>
                </div>
              </div>
              
              <table class="bases-table" id="bases-table">
                <thead>
                  <tr>
                    <th>Base Name</th>
                    <th>Subdomain</th>
                    <th>Users</th>
                    <th>Tables</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody id="bases-tbody">
                  <!-- Will be populated by JavaScript -->
                </tbody>
              </table>
            </div>
          </div>

          <script>
            function copyToClipboard(type) {
              const links = {
                'ssc5-link': '/admin-setup/ssc5demo123',
                'ssc6-link': '/admin-setup/ssc6demo123'
              };
              
              const link = window.location.origin + links[type];
              navigator.clipboard.writeText(link).then(() => {
                alert('Link copied to clipboard!');
              });
            }

            // Load bases data
            fetch('/api/super-admin/bases')
              .then(response => response.json())
              .then(bases => {
                const tbody = document.getElementById('bases-tbody');
                tbody.innerHTML = bases.map(base => \`
                  <tr>
                    <td>
                      <div class="base-name">
                        <div class="base-icon">
                          <i class="fas fa-database"></i>
                        </div>
                        <span style="font-weight: 500;">\${base.name}</span>
                      </div>
                    </td>
                    <td>
                      <code class="subdomain-code">\${base.subdomain}.mapz.online</code>
                    </td>
                    <td>\${base.userCount}</td>
                    <td>\${base.tableCount}</td>
                    <td>
                      <span class="status-badge">\${base.status}</span>
                    </td>
                    <td>
                      <button class="btn btn-secondary" onclick="window.open('http://\${base.subdomain}.mapz.online', '_blank')" style="font-size: 0.75rem; padding: 0.25rem 0.5rem;">
                        Access Base
                      </button>
                    </td>
                  </tr>
                \`).join('');
              })
              .catch(error => {
                console.error('Error loading bases:', error);
                document.getElementById('bases-tbody').innerHTML = '<tr><td colspan="6" style="text-align: center; color: #ef4444;">Error loading bases</td></tr>';
              });
          </script>
        </body>
        </html>
      `);
    }
  } else {
    // Serve client-specific dashboard
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
          <title>${req.client.toUpperCase()} Dashboard - GIS Platform</title>
          <style>
              body { font-family: Arial, sans-serif; margin: 0; background: #f8fafc; }
              .header { background: #1e293b; color: white; padding: 1rem 2rem; }
              .nav { display: flex; gap: 2rem; margin-top: 1rem; }
              .nav a { color: #94a3b8; text-decoration: none; padding: 0.5rem 1rem; border-radius: 4px; }
              .nav a:hover { background: #374151; color: white; }
              .content { padding: 2rem; max-width: 1200px; margin: 0 auto; }
              .widget { background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; margin: 1rem 0; }
              .widget h3 { margin-top: 0; color: #1f2937; }
              .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
              .stat-card { background: #f8fafc; padding: 1rem; border-radius: 6px; text-align: center; }
              .stat-value { font-size: 2rem; font-weight: bold; color: #3b82f6; }
              .stat-label { color: #64748b; font-size: 0.9rem; }
          </style>
      </head>
      <body>
          <div class="header">
              <h1>${req.client.toUpperCase()} GIS Platform</h1>
              <div class="nav">
                  <a href="/dashboard">Dashboard</a>
                  <a href="/workspace">Workspace</a>
                  <a href="/map">Map View</a>
              </div>
          </div>
          <div class="content">
              <div class="widget">
                  <h3>Site Statistics</h3>
                  <div class="stats">
                      <div class="stat-card">
                          <div class="stat-value" id="site-count">0</div>
                          <div class="stat-label">Total Sites</div>
                      </div>
                      <div class="stat-card">
                          <div class="stat-value">WKT</div>
                          <div class="stat-label">Geometry Support</div>
                      </div>
                  </div>
              </div>
              <div class="widget">
                  <h3>Client Structure</h3>
                  <ul>
                      <li>Individual pages: /clients/${req.client}/pages/</li>
                      <li>WKT geometry: POINT, POLYGON, LINESTRING</li>
                      <li>CSV upload with spatial processing</li>
                      <li>Client-isolated database tables</li>
                      <li>Blocked from super admin functions</li>
                  </ul>
              </div>
          </div>
          <script>
              fetch('/api/tables/1/data')
                  .then(r => r.json())
                  .then(data => {
                      document.getElementById('site-count').textContent = data.length;
                  })
                  .catch(() => {
                      document.getElementById('site-count').textContent = '0';
                  });
          </script>
      </body>
      </html>
    `);
  }
});

app.get('/dashboard', (req, res) => res.redirect('/'));

app.get('/workspace', (req, res) => {
  if (req.isSuperAdmin) return res.redirect('/');
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>${req.client.toUpperCase()} Workspace</title></head>
    <body>
      <h1>${req.client.toUpperCase()} Workspace</h1>
      <p>Individual workspace page for ${req.client}</p>
      <p>Page structure: /clients/${req.client}/pages/workspace/</p>
      <a href="/">Back to Dashboard</a>
    </body>
    </html>
  `);
});

app.get('/map', (req, res) => {
  if (req.isSuperAdmin) return res.redirect('/');
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>${req.client.toUpperCase()} Map View</title></head>
    <body>
      <h1>${req.client.toUpperCase()} Map View</h1>
      <p>Individual map page for ${req.client} with WKT geometry support</p>
      <p>Page structure: /clients/${req.client}/pages/map/</p>
      <a href="/">Back to Dashboard</a>
    </body>
    </html>
  `);
});

// Serve static assets for the original React app
app.use('/src', express.static(path.join(__dirname, 'original_client/src')));
app.use('/assets', express.static(path.join(__dirname, 'original_client/src/assets')));

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Team2 Hybrid Server running on port ${PORT}`);
  console.log('Super Admin: mapz.online (authentic Team2 interface)');
  console.log('Clients: *.mapz.online (isolated client dashboards)');
});