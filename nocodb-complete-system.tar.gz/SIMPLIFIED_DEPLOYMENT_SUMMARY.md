# Simplified GIS Client Architecture - Complete Deployment

## System Overview

The simplified architecture transforms the complex multi-tenant system into individual client deployments, providing you with direct PostgreSQL control while maintaining full functionality.

## Active Deployments

### 1. Original Complex System (Preserved)
- **Port**: 5000
- **URL**: http://172.232.108.139:5000
- **Status**: Fully operational TypeScript/React application
- **Backup**: Complete snapshot saved in `/opt/backups/`

### 2. Acme Corp Client (Simplified)
- **Port**: 5001
- **URL**: http://172.232.108.139:5001
- **Features**: Interactive map, user management, permissions, data export
- **Location**: `/opt/simplified-clients/client-acme/`
- **API**: Working with 3 sample locations in New York area

### 3. SLN Client (Simplified)
- **Port**: 5002
- **URL**: http://172.232.108.139:5002
- **Features**: Location tracking, research data, field operations
- **Location**: `/opt/simplified-clients/client-sln/`
- **API**: Working with 3 sample locations in California area

## Database Access & Control

### Master PostgreSQL Access
```bash
# Connect to database
PGPASSWORD=PostgresAdmin2024! psql -h 172.232.108.139 -U postgres -d gisdb

# View all tables
\dt

# Check existing data
SELECT * FROM sites;
SELECT * FROM users;
SELECT * FROM bases;
```

### Client-Specific Data Management
```sql
-- Acme data operations
SELECT * FROM sites WHERE name ILIKE '%acme%';
INSERT INTO sites (name, location, coordinates, properties) 
VALUES ('New Acme Location', 'Boston, MA', 
        ST_SetSRID(ST_MakePoint(-71.0589, 42.3601), 4326),
        '{"client": "acme", "status": "active"}');

-- SLN data operations  
SELECT * FROM sites WHERE name ILIKE '%sln%';
INSERT INTO sites (name, location, coordinates, properties)
VALUES ('New SLN Location', 'San Diego, CA',
        ST_SetSRID(ST_MakePoint(-117.1611, 32.7157), 4326),
        '{"client": "sln", "status": "active"}');
```

## Simplified Benefits for Non-Technical Management

### 1. Easy Understanding
- Each client has its own simple HTML files
- No complex React components or TypeScript compilation
- Direct database queries without ORM complexity
- Individual processes that can be managed separately

### 2. Direct Control
- Full PostgreSQL administrative access
- Run any SQL query directly on the database
- Individual client deployments on separate ports
- Simple file-based configuration

### 3. Independent Operations
- Update Acme client without affecting SLN
- Each client can be stopped/started independently
- Separate backup and restore procedures
- No shared dependencies between clients

### 4. Maintenance Simplicity
```bash
# Check all services
pm2 list

# Restart individual client
pm2 restart acme-gis-client
pm2 restart sln-gis-client

# View logs for specific client
pm2 logs acme-gis-client
pm2 logs sln-gis-client

# Stop/start clients
pm2 stop acme-gis-client
pm2 start acme-gis-client
```

## Client Features Maintained

### Each Client Includes:
- **Interactive Map**: Full Leaflet.js mapping with marker support
- **User Management**: Complete user administration interface
- **Permissions System**: Role-based access control configuration
- **Data Management**: CSV import/export functionality
- **Responsive Design**: Modern UI with Tailwind CSS
- **Real-time Updates**: Dynamic data loading and visualization

### Customization Per Client:
- **Acme Corp**: Blue theme, New York focus, office/warehouse/distribution sites
- **SLN**: Purple gradient theme, California focus, research/field/office locations
- **Branding**: Client-specific colors, logos, and terminology
- **Data Fields**: Customizable properties and data structures

## Adding New Clients

### Step-by-Step Process:
1. **Copy Template**: `cp -r client-acme client-newclient`
2. **Update Branding**: Modify HTML files with client colors/name
3. **Configure Data**: Update API endpoints and sample data
4. **Set Port**: Change port number in server.js
5. **Deploy**: `pm2 start server.js --name 'newclient-gis'`

### Port Allocation:
- 5000: Original complex system
- 5001: Acme Corp
- 5002: SLN
- 5003+: Available for new clients

## Database Integration

### Current Schema Usage:
- **sites**: Stores all location/site data with PostGIS coordinates
- **users**: User authentication and role management
- **bases**: Tenant/client configuration (from original system)
- **user_sessions**: Session management

### Client Data Separation:
- Filter by name patterns: `WHERE name ILIKE '%acme%'`
- Use properties field: `WHERE properties->>'client' = 'acme'`
- Email-based filtering: `WHERE email LIKE '%@acme.com'`

## Production Considerations

### Backup Strategy:
```bash
# Full database backup
pg_dump -U postgres -h localhost gisdb > full_backup.sql

# Client-specific backup
pg_dump -U postgres -h localhost gisdb \
  --table=sites --where="properties->>'client'='acme'" > acme_data.sql

# Application files backup
tar -czf acme_client_backup.tar.gz /opt/simplified-clients/client-acme/
```

### Performance Monitoring:
```bash
# Resource usage
pm2 monit

# Individual client status
pm2 show acme-gis-client
pm2 show sln-gis-client

# Database connections
PGPASSWORD=PostgresAdmin2024! psql -h localhost -U postgres -d gisdb -c "SELECT * FROM pg_stat_activity;"
```

### Security Notes:
- Each client runs on different port with isolated processes
- Database access controlled through PostgreSQL user permissions
- CORS enabled for API access from client applications
- Session-based authentication can be added per client

## Migration Path

### From Complex to Simplified:
1. **Data Migration**: Copy existing site data to new client-specific format
2. **User Migration**: Transfer user accounts to appropriate clients
3. **Configuration**: Set up client-specific settings and permissions
4. **Testing**: Verify all functionality works in simplified environment
5. **Cutover**: Switch clients to simplified deployment when ready

### Rollback Option:
- Original complex system remains fully operational on port 5000
- Complete backup snapshot available for restoration
- Can run both systems simultaneously during transition

This simplified architecture provides the same GIS functionality with direct database control and easy management for non-technical users.