#!/bin/bash

# Complete Team 2 Standalone GIS Deployment Fix
# This script creates all necessary files for fixing the 502 Bad Gateway issue

echo "Creating deployment fix package..."

# Create the production server that binds to all interfaces
cat > production_server.js << 'EOF'
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = '0.0.0.0'; // CRITICAL: Bind to all interfaces

console.log(`Starting Team 2 Standalone GIS Server on ${HOST}:${PORT}`);

// Request logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

app.use(express.json());

// Serve static files
const distPath = path.join(__dirname, 'dist');
if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));
    console.log(`Serving static files from: ${distPath}`);
}

// API endpoints
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        service: 'Team 2 Standalone GIS',
        host: HOST, 
        port: PORT,
        timestamp: new Date().toISOString()
    });
});

app.get('/api/super-admin/bases', (req, res) => {
    res.json([{
        "id": 1,
        "name": "Team 2 GIS Base",
        "subdomain": "team2",
        "status": "active"
    }]);
});

// Serve React app
app.get('*', (req, res) => {
    const indexPath = path.join(distPath, 'index.html');
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        res.status(200).send(`
            <h1>Team 2 Standalone GIS System</h1>
            <p>Server running on ${HOST}:${PORT}</p>
            <p>Status: Active</p>
            <p>Time: ${new Date().toISOString()}</p>
        `);
    }
});

app.listen(PORT, HOST, () => {
    console.log(`✅ Server running on http://${HOST}:${PORT}`);
    console.log(`🌐 Externally accessible`);
});
EOF

# Create PM2 ecosystem file for proper process management
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'team2-standalone-gis',
    script: 'production_server.js',
    cwd: '/opt/team2-gis',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0'
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/team2-gis-error.log',
    out_file: '/var/log/team2-gis-out.log',
    log_file: '/var/log/team2-gis.log'
  }]
};
EOF

# Create deployment commands
cat > deploy_commands.sh << 'EOF'
#!/bin/bash
echo "Deploying Team 2 Standalone GIS Fix..."

# Stop current process
pm2 stop team2-standalone-gis 2>/dev/null || true
pm2 delete team2-standalone-gis 2>/dev/null || true

# Copy files to deployment directory
cp production_server.js /opt/team2-gis/
cp ecosystem.config.js /opt/team2-gis/

# Start with PM2
cd /opt/team2-gis
pm2 start ecosystem.config.js
pm2 save

# Restart Nginx
systemctl restart nginx

# Verify deployment
echo "Checking application status..."
pm2 status
echo "Checking port binding..."
netstat -tlnp | grep :5000
echo "Testing local connection..."
curl -I http://localhost:5000
echo "Testing external access..."
curl -I http://localhost

echo "Deployment complete. Application should be accessible at http://172.232.108.139"
EOF

chmod +x deploy_commands.sh

# Create troubleshooting guide
cat > troubleshooting.md << 'EOF'
# Troubleshooting Team 2 GIS Deployment

## Quick Diagnosis Commands
```bash
# Check PM2 status
pm2 status

# Check port binding (should show 0.0.0.0:5000)
netstat -tlnp | grep :5000

# Test local app
curl -I http://localhost:5000

# Test Nginx proxy
curl -I http://localhost

# Check Nginx errors
tail -20 /var/log/nginx/error.log

# Check application logs
pm2 logs team2-standalone-gis --lines 20
```

## Expected Results
- PM2 status: online
- Port binding: 0.0.0.0:5000 (not 127.0.0.1:5000)
- Local app: HTTP/1.1 200 OK
- Nginx proxy: HTTP/1.1 200 OK
- No connection refused errors in Nginx logs

## If Still Getting 502 Error
1. Verify application is binding to 0.0.0.0 not localhost
2. Check firewall rules
3. Ensure Nginx configuration is correct
4. Restart both application and Nginx
EOF

echo "Deployment fix package created successfully!"
echo ""
echo "Files created:"
echo "- production_server.js (binds to all interfaces)"
echo "- ecosystem.config.js (PM2 configuration)"
echo "- deploy_commands.sh (deployment script)"
echo "- troubleshooting.md (diagnostic guide)"
echo ""
echo "Next steps:"
echo "1. Copy these files to your server at 172.232.108.139"
echo "2. Run: bash deploy_commands.sh"
echo "3. Access your application at http://172.232.108.139"