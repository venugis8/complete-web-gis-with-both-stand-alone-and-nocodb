#!/bin/bash

echo "Starting complete deployment of exact Replit code to Linode..."

# Create deployment script for Linode server
sshpass -p 'Geo@asset15!' ssh -o StrictHostKeyChecking=no root@172.235.5.20 << 'EOF'

cd /root/saas-webgis-app

echo "Installing dependencies..."
npm install --production=false

echo "Creating PM2 ecosystem configuration..."
cat > ecosystem.config.js << 'ECOSYSTEM_END'
module.exports = {
  apps: [{
    name: 'saas-webgis',
    script: './server/index.ts',
    interpreter: 'npx',
    interpreter_args: 'tsx',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      DATABASE_URL: 'postgresql://webgis_user:webgis_password@localhost/webgis_db'
    },
    watch: false,
    max_memory_restart: '1G',
    instances: 1,
    exec_mode: 'fork',
    log_file: './logs/combined.log',
    out_file: './logs/out.log',
    error_file: './logs/error.log'
  }]
};
ECOSYSTEM_END

echo "Creating logs directory..."
mkdir -p logs

echo "Building application..."
npm run build

echo "Setting up database schema..."
npm run db:push

echo "Starting application with PM2..."
pm2 start ecosystem.config.js

echo "Checking application status..."
pm2 status

echo "Testing application endpoint..."
sleep 5
curl -s http://localhost:3000/api/super-admin/bases | head -100

echo "Deployment completed successfully!"

EOF

echo "Deployment script executed. Your exact Replit code is now running on Linode."