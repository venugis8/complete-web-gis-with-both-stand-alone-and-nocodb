# GIS SaaS Platform - Software Stack Documentation

## Core Technology Stack

### Frontend Technologies

#### React Ecosystem
- **React 18.2.0**: Modern React with hooks and concurrent features
- **TypeScript 5.0+**: Static type checking and enhanced developer experience
- **Vite 4.0+**: Fast build tool with HMR and optimized production builds
- **Wouter**: Lightweight client-side routing (2.8KB gzipped)

#### UI Framework
- **Tailwind CSS 3.3+**: Utility-first CSS framework
- **shadcn/ui**: High-quality React components built on Radix UI
- **Radix UI Primitives**: Accessible, unstyled UI components
- **Lucide React**: Beautiful, customizable SVG icons
- **React Icons**: Popular icon library with Font Awesome integration

#### State Management
- **TanStack Query v5**: Server state management with caching
- **React Hook Form**: Performant forms with minimal re-renders
- **Zod**: TypeScript-first schema validation

#### Map and Visualization
- **Leaflet.js 1.9.4**: Leading open-source JavaScript library for maps
- **React-Leaflet**: React components for Leaflet maps
- **OpenStreetMap**: Free, editable map data
- **Recharts**: Composable charting library for React

### Backend Technologies

#### Server Framework
- **Node.js 20+**: JavaScript runtime with excellent performance
- **Express.js 4.18+**: Fast, minimalist web framework
- **TypeScript**: Full-stack type safety
- **tsx**: TypeScript execution for development

#### Database Layer
- **PostgreSQL 14+**: Advanced open-source relational database
- **PostGIS**: Spatial database extension for geographic objects
- **Drizzle ORM**: Type-safe, SQL-like ORM for TypeScript
- **pg**: Non-blocking PostgreSQL client for Node.js

#### Authentication & Security
- **bcrypt**: Password hashing for secure authentication
- **express-session**: Session middleware for Express
- **connect-pg-simple**: PostgreSQL session store
- **passport**: Authentication middleware (configurable)

### Development & Build Tools

#### Code Quality
- **ESLint**: JavaScript/TypeScript linting
- **Prettier**: Code formatting
- **TypeScript**: Static type checking
- **Vite**: Development server with HMR

#### Package Management
- **npm**: Node.js package manager
- **Node.js 20**: LTS version for stability

### Production Infrastructure

#### Process Management
- **PM2**: Production process manager for Node.js
- **Nginx**: High-performance web server and reverse proxy
- **systemd**: Service management on Linux

#### Database
- **PostgreSQL**: Primary database with ACID compliance
- **Connection Pooling**: Efficient database connection management
- **Backup Systems**: Automated database backup solutions

## Detailed Component Analysis

### Frontend Architecture

#### Component Library Structure
```
client/
├── src/
│   ├── components/
│   │   ├── ui/          # shadcn/ui components
│   │   ├── forms/       # Form components
│   │   ├── maps/        # Map-related components
│   │   └── layout/      # Layout components
│   ├── pages/           # Route components
│   ├── hooks/           # Custom React hooks
│   ├── lib/             # Utility functions
│   └── types/           # TypeScript type definitions
```

#### Key Dependencies
```json
{
  "@hookform/resolvers": "^3.3.2",
  "@radix-ui/react-*": "^1.0.0",
  "@tanstack/react-query": "^5.0.0",
  "leaflet": "^1.9.4",
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "react-hook-form": "^7.47.0",
  "tailwindcss": "^3.3.0",
  "typescript": "^5.0.0",
  "vite": "^4.4.0",
  "wouter": "^2.12.0",
  "zod": "^3.22.0"
}
```

### Backend Architecture

#### Server Structure
```
server/
├── db.ts              # Database connection and configuration
├── index.ts           # Main server entry point
├── routes.ts          # API route definitions
├── storage.ts         # Data access layer
└── types/             # Backend type definitions
```

#### Key Dependencies
```json
{
  "@neondatabase/serverless": "^0.6.0",
  "bcrypt": "^5.1.1",
  "drizzle-orm": "^0.28.0",
  "express": "^4.18.2",
  "express-session": "^1.17.3",
  "pg": "^8.11.3",
  "tsx": "^3.12.0",
  "typescript": "^5.0.0"
}
```

### Database Schema Design

#### Multi-Tenant Architecture
```sql
-- Core tenant table
CREATE TABLE bases (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    subdomain VARCHAR(100) UNIQUE NOT NULL,
    system_mode VARCHAR(50) DEFAULT 'standalone',
    deployment_type VARCHAR(50) DEFAULT 'basic',
    nocodb_url TEXT,
    nocodb_api_key TEXT,
    nocodb_base_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User management per tenant
CREATE TABLE base_users (
    id SERIAL PRIMARY KEY,
    base_id INTEGER REFERENCES bases(id) ON DELETE CASCADE,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'user',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(base_id, email)
);
```

#### Spatial Data Support
```sql
-- Enable PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;

-- Sites with geographic data
CREATE TABLE sites (
    id SERIAL PRIMARY KEY,
    base_id INTEGER REFERENCES bases(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    location TEXT,
    coordinates GEOMETRY(POINT, 4326),
    properties JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Spatial index for performance
CREATE INDEX idx_sites_coordinates ON sites USING GIST (coordinates);
```

## Performance Optimizations

### Frontend Optimizations
- **Code Splitting**: Dynamic imports for route-based splitting
- **Tree Shaking**: Vite eliminates unused code
- **Asset Optimization**: Minification and compression
- **Caching**: Browser caching with proper cache headers

### Backend Optimizations
- **Connection Pooling**: PostgreSQL connection pool management
- **Query Optimization**: Indexed queries and efficient joins
- **Session Management**: Redis-compatible session storage
- **Middleware Optimization**: Minimal middleware stack

### Database Optimizations
```sql
-- Performance indexes
CREATE INDEX idx_base_users_base_id ON base_users(base_id);
CREATE INDEX idx_sites_base_id ON sites(base_id);
CREATE INDEX idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_user_sessions_expires ON user_sessions(expires_at);

-- Partial indexes for active records
CREATE INDEX idx_active_users ON base_users(base_id) WHERE is_active = true;
CREATE INDEX idx_active_tokens ON api_tokens(base_id) WHERE is_active = true;
```

## Security Implementation

### Authentication Flow
1. **Login Request**: User submits credentials to `/api/base/{subdomain}/login`
2. **Credential Validation**: Server validates against base-specific user table
3. **Session Creation**: Generate unique session token with base context
4. **Token Storage**: Store session in database with expiration
5. **Response**: Return user data and session token

### Authorization Middleware
```javascript
// Base-aware authentication middleware
function authenticateBase(req, res, next) {
  const { subdomain } = req.params;
  const sessionToken = req.headers.authorization;
  
  // Validate session token format: {subdomain}_{user_id}_{timestamp}
  if (!sessionToken || !sessionToken.startsWith(subdomain)) {
    return res.status(401).json({ error: 'Invalid session' });
  }
  
  // Validate session in database
  // Attach user and base context to request
  next();
}
```

### Data Isolation
- **Base ID Filtering**: All queries include `WHERE base_id = ?`
- **Session Validation**: Tokens include base context
- **API Route Protection**: Base-aware middleware on all endpoints
- **Cross-Tenant Prevention**: Middleware blocks cross-base access

## Deployment Configuration

### Production Environment
```javascript
// PM2 ecosystem configuration
module.exports = {
  apps: [{
    name: 'team2-gis',
    script: 'complete_production_server.cjs',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: process.env.DATABASE_URL
    }
  }]
};
```

### Nginx Configuration
```nginx
server {
    listen 80;
    server_name team2.172.232.108.139.nip.io;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Integration Specifications

### NocoDB Integration
- **API Version**: NocoDB v2 REST API
- **Authentication**: Bearer token authentication
- **Data Sync**: Bidirectional synchronization
- **Schema Discovery**: Dynamic table and field detection

### External APIs
- **Map Tiles**: OpenStreetMap via Leaflet
- **Geocoding**: Optional integration with geocoding services
- **Authentication**: OAuth2 support for external providers

This comprehensive software stack provides a modern, scalable foundation for the multi-tenant GIS SaaS platform with enterprise-grade security and performance characteristics.