# NocoDB GIS Platform - Pure Integration

This repository contains the exact codebase from **mapz.in:5001** - a pure NocoDB integration system that directly connects to NocoDB base `prxsww2l3z53hiw` at `https://app.nocodb.com`.

## 🌟 Live Deployment

- **Production URL**: http://mapz.online
- **System Type**: Pure NocoDB Integration
- **Original Source**: mapz.in:5001 equivalent

## 📊 API Endpoints

- **Tables**: `/api/v1/nocodb-tables` - Fetches authentic NocoDB table data
- **Admin**: `/api/super-admin/bases` - Shows SSC6 NocoDB base configuration  
- **Health**: `/health` - System status and GitHub source reference

## 🏗️ Architecture

This is a minimal Node.js server that:
- Connects directly to NocoDB API at `app.nocodb.com`
- Uses base ID `prxsww2l3z53hiw` 
- Returns 4 real tables: sites, points_csv, Table-1, field_permissions
- Provides pure NocoDB functionality without standalone features

## 🚀 Deployment

### Automatic Deployment to Linode
```bash
./deploy-to-linode.sh
```

### Manual Deployment
```bash
# Copy file to server
scp nocodb-server.cjs root@172.232.108.139:/opt/nocodb-gis/nocodb-5001.cjs

# Start with PM2
ssh root@172.232.108.139 "cd /opt/nocodb-gis && pm2 start nocodb-5001.cjs --name nocodb-5001"
```

## 🔧 Configuration

The system uses these NocoDB credentials:
- **Base ID**: `prxsww2l3z53hiw`
- **API URL**: `https://app.nocodb.com`  
- **API Key**: `WvgZorcSfG5-kS5z1yDZnNXsRNejxQBSOETUeBvo`

## 📝 System Comparison

| Feature | mapz.in:5001 (Pure NocoDB) | mapz.in:5002 (Standalone) |
|---------|---------------------------|---------------------------|
| Data Source | NocoDB API | Local Database |
| Tables | 4 NocoDB tables | Custom tables |
| Authentication | NocoDB-based | Local auth |
| Deployment | Single file | Full stack |

## 🎯 Purpose

This repository preserves the exact functionality of the pure NocoDB system from mapz.in:5001, enabling:
- Single source of truth in GitHub
- Automatic deployment workflows
- Version control for NocoDB integrations
- Clean separation from standalone systems

## 🔄 Development Workflow

1. **GitHub** → Single source repository
2. **Replit** → Development and testing
3. **Linode** → Production deployment at mapz.online

---

**Original System**: mapz.in:5001  
**Current Deployment**: mapz.online  
**Repository**: GitHub source control ready