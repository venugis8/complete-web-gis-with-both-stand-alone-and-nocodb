import NocoDBUserManagement from '@/components/nocodb-user-management';

export default function UserManagementPage() {
  return <NocoDBUserManagement />;
}