import MapView from '@/components/map-view';

export default function MapViewPage() {
  return <MapView />;
}