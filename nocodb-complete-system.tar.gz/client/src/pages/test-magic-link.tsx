import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function TestMagicLink() {
  const { toast } = useToast();
  const [testToken, setTestToken] = useState('test123demo456');
  
  const testLink = `/admin-setup/${testToken}`;
  const fullLink = window.location.origin + testLink;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(fullLink);
      toast({
        title: "Copied!",
        description: "Test magic link copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const openTestLink = () => {
    window.open(testLink, '_blank');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Magic Link Testing</CardTitle>
          <CardDescription>
            Test the magic link authentication system for client admin onboarding
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="token">Test Magic Link Token</Label>
            <div className="flex gap-2 mt-1">
              <Input
                id="token"
                value={testToken}
                onChange={(e) => setTestToken(e.target.value)}
                placeholder="Enter test token"
              />
              <Button onClick={() => setTestToken('test' + Date.now())}>
                Generate New
              </Button>
            </div>
          </div>

          <div>
            <Label>Generated Magic Link</Label>
            <div className="flex gap-2 mt-1">
              <Input 
                value={fullLink} 
                readOnly 
                className="flex-1"
              />
              <Button onClick={copyToClipboard} variant="outline">
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
              <Button onClick={openTestLink} variant="outline">
                <ExternalLink className="h-4 w-4 mr-1" />
                Test
              </Button>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-semibold text-blue-800 mb-2">How to Test:</h3>
            <ol className="text-sm text-blue-700 space-y-1">
              <li>1. Click "Test" to open the admin setup page</li>
              <li>2. Enter admin details (name and password)</li>
              <li>3. Complete the setup to see the authentication flow</li>
              <li>4. The system will create an admin account and redirect to workspace</li>
            </ol>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <h3 className="font-semibold text-green-800 mb-2">Production Flow:</h3>
            <p className="text-sm text-green-700">
              In production, when you create a new base deployment, the system automatically generates 
              a unique magic link and displays it for you to share with the client admin. The link 
              expires in 24 hours and can only be used once for secure onboarding.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}