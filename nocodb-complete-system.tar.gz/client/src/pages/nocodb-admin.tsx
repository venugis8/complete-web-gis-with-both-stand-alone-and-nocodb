import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Database, Users, Table2 } from "lucide-react";

interface Base {
  id: number;
  name: string;
  subdomain: string;
  status: string;
  userCount: number;
  tableCount: number;
  createdAt: string;
  systemMode?: string;
  deploymentType?: string;
  nocodbBaseId?: string;
  nocodbUrl?: string;
  nocodbApiKey?: string;
}

interface NocodbTable {
  id: string;
  tableName: string;
  displayName: string;
  baseId: number;
  hasGeometry: boolean;
  geometryColumn: string | null;
  schema: { columns: any[] };
  createdAt: string;
  updatedAt: string;
}

export default function NocodbAdminPage() {
  const { data: bases, isLoading: basesLoading } = useQuery<Base[]>({
    queryKey: ["/api/super-admin/bases"],
  });

  const { data: tables, isLoading: tablesLoading } = useQuery<NocodbTable[]>({
    queryKey: ["/api/v1/nocodb-tables"],
  });

  const base = bases?.[0];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Database className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-gray-900">NocoDB GIS Platform</h1>
            </div>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              Pure NocoDB
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="outline">
              mapz.in:5001 equivalent
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        
        {/* System Status */}
        <div className="mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {basesLoading ? "..." : base?.tableCount || 0}
                  </div>
                  <div className="text-sm text-gray-600">NocoDB Tables</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {basesLoading ? "..." : base?.userCount || 0}
                  </div>
                  <div className="text-sm text-gray-600">Active Users</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">Online</div>
                  <div className="text-sm text-gray-600">System Status</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* NocoDB Base Info */}
        {base && (
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle>NocoDB Base Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Base Name</label>
                    <div className="mt-1 text-sm text-gray-900">{base.name}</div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Subdomain</label>
                    <div className="mt-1 text-sm text-gray-900">{base.subdomain}</div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">NocoDB Base ID</label>
                    <div className="mt-1 text-sm text-gray-900 font-mono">{base.nocodbBaseId}</div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Status</label>
                    <div className="mt-1">
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        {base.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open(base.nocodbUrl, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open NocoDB Dashboard
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Tables List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Table2 className="w-5 h-5" />
              Available Tables
            </CardTitle>
          </CardHeader>
          <CardContent>
            {tablesLoading ? (
              <div className="text-center py-8">
                <div className="text-gray-500">Loading tables...</div>
              </div>
            ) : tables && tables.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tables.map((table) => (
                  <Card key={table.id} className="border-2 hover:border-blue-300 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{table.displayName}</h3>
                        <Badge variant="outline" className="text-xs">
                          {table.tableName}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>ID: {table.id}</div>
                        <div>Columns: {table.schema?.columns?.length || 0}</div>
                        <div>Geometry: {table.hasGeometry ? 'Yes' : 'No'}</div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="text-gray-500">No tables found</div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}