interface User {
  id: number;
  email: string;
  name: string;
  role: string;
}

interface Base {
  id: number;
  name: string;
  subdomain: string;
}

const AUTH_TOKEN_KEY = 'nocobase_auth_token';
const CURRENT_USER_KEY = 'nocobase_current_user';
const CURRENT_BASE_KEY = 'nocobase_current_base';

export function setAuthToken(token: string) {
  localStorage.setItem(AUTH_TOKEN_KEY, token);
}

export function getAuthToken(): string | null {
  return localStorage.getItem(AUTH_TOKEN_KEY);
}

export function removeAuthToken() {
  localStorage.removeItem(AUTH_TOKEN_KEY);
}

export function setCurrentUser(user: User) {
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
}

export function getCurrentUser(): User | null {
  const userStr = localStorage.getItem(CURRENT_USER_KEY);
  return userStr ? JSON.parse(userStr) : null;
}

export function removeCurrentUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

export function setCurrentBase(base: Base) {
  localStorage.setItem(CURRENT_BASE_KEY, JSON.stringify(base));
}

export function getCurrentBase(): Base | null {
  const baseStr = localStorage.getItem(CURRENT_BASE_KEY);
  return baseStr ? JSON.parse(baseStr) : null;
}

export function removeCurrentBase() {
  localStorage.removeItem(CURRENT_BASE_KEY);
}

export function isAuthenticated(): boolean {
  const token = getAuthToken();
  const user = getCurrentUser();
  const base = getCurrentBase();
  return !!(token && user && base);
}

export function logout() {
  removeAuthToken();
  removeCurrentUser();
  removeCurrentBase();
}
