import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Copy, ExternalLink, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface MagicLinkDisplayProps {
  magicLink: string;
  adminEmail: string;
  baseName: string;
}

export default function MagicLinkDisplay({ magicLink, adminEmail, baseName }: MagicLinkDisplayProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const fullLink = window.location.origin + magicLink;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(fullLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Copied!",
        description: "Magic link copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const openLink = () => {
    window.open(fullLink, '_blank');
  };

  return (
    <Card className="mt-4 border-green-200 bg-green-50">
      <CardHeader>
        <CardTitle className="text-green-800 flex items-center">
          <CheckCircle className="h-5 w-5 mr-2" />
          Admin Setup Link Generated
        </CardTitle>
        <CardDescription>
          Share this link with <strong>{adminEmail}</strong> to complete the setup for <strong>{baseName}</strong>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-2">
          <Input 
            value={fullLink} 
            readOnly 
            className="flex-1 text-sm"
          />
          <Button 
            onClick={copyToClipboard}
            variant="outline"
            size="sm"
            className="whitespace-nowrap"
          >
            {copied ? (
              <CheckCircle className="h-4 w-4 mr-1 text-green-600" />
            ) : (
              <Copy className="h-4 w-4 mr-1" />
            )}
            {copied ? 'Copied!' : 'Copy'}
          </Button>
          <Button 
            onClick={openLink}
            variant="outline"
            size="sm"
          >
            <ExternalLink className="h-4 w-4 mr-1" />
            Test
          </Button>
        </div>
        <p className="text-sm text-gray-600">
          This link expires in 24 hours and can only be used once to set up the admin account.
        </p>
      </CardContent>
    </Card>
  );
}