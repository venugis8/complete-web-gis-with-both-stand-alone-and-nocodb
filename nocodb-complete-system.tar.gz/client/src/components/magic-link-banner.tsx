import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Copy, ExternalLink, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function MagicLinkBanner() {
  const { toast } = useToast();
  const magicLink = `${window.location.origin}/admin-setup/ssc5demo123`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(magicLink);
      toast({
        title: "Magic link copied!",
        description: "Share this with your SSC5 client admin",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const testLink = () => {
    window.open('/admin-setup/ssc5demo123', '_blank');
  };

  return (
    <Card className="mb-6 border-green-200 bg-green-50">
      <CardHeader className="pb-3">
        <CardTitle className="text-green-800 flex items-center">
          <CheckCircle className="h-5 w-5 mr-2" />
          SSC5 Magic Link Ready
        </CardTitle>
        <CardDescription>
          Copy this admin setup link for your SSC5 client
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2">
          <Input 
            value={magicLink}
            readOnly 
            className="flex-1 text-sm"
          />
          <Button onClick={copyLink} variant="outline">
            <Copy className="h-4 w-4 mr-1" />
            Copy
          </Button>
          <Button onClick={testLink} variant="outline">
            <ExternalLink className="h-4 w-4 mr-1" />
            Test
          </Button>
        </div>
        <p className="text-xs text-green-600 mt-2">
          This link expires in 24 hours and can only be used once to set up the admin account.
        </p>
      </CardContent>
    </Card>
  );
}