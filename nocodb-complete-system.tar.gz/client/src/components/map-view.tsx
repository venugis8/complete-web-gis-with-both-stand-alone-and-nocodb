import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

declare global {
  interface Window {
    L: any;
    wellknown?: any;
  }
}

interface MapViewProps {
  data: any[];
  isLoading: boolean;
}

export default function MapView({ data, isLoading }: MapViewProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const layerGroupRef = useRef<any>(null);
  const [isMapInitialized, setIsMapInitialized] = useState(false);

  useEffect(() => {
    if (!mapContainerRef.current || isLoading) return;

    const initializeMap = async () => {
      try {
        // Load Leaflet CSS and JS if not already loaded
        if (!window.L) {
          // Add CSS
          const cssLink = document.createElement('link');
          cssLink.rel = 'stylesheet';
          cssLink.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          document.head.appendChild(cssLink);

          // Add additional CSS to ensure map displays properly
          const additionalCSS = document.createElement('style');
          additionalCSS.textContent = `
            .leaflet-container {
              height: 100% !important;
              width: 100% !important;
              background: #aad3df;
            }
            .leaflet-tile {
              filter: none !important;
            }
          `;
          document.head.appendChild(additionalCSS);

          // Add JS
          const script = document.createElement('script');
          script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          document.head.appendChild(script);

          await new Promise((resolve) => {
            script.onload = resolve;
          });
        }

        // Load wellknown library for WKT parsing
        if (!window.wellknown) {
          const wellknownScript = document.createElement('script');
          wellknownScript.src = 'https://unpkg.com/wellknown/wellknown.js';
          document.head.appendChild(wellknownScript);

          await new Promise((resolve) => {
            wellknownScript.onload = resolve;
          });
        }

        // Only initialize once
        if (!mapInstanceRef.current && mapContainerRef.current) {
          // Ensure container has proper dimensions
          const container = mapContainerRef.current;
          container.style.height = '100%';
          container.style.width = '100%';
          
          // Create map
          mapInstanceRef.current = window.L.map(container, {
            center: [12.97, 77.59], // Bangalore coordinates
            zoom: 10,
            preferCanvas: false,
            attributionControl: true
          });

          // Add OpenStreetMap tiles
          const osmLayer = window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18,
            attribution: '© OpenStreetMap contributors'
          });
          osmLayer.addTo(mapInstanceRef.current);

          // Create layer group for features
          layerGroupRef.current = window.L.layerGroup();
          layerGroupRef.current.addTo(mapInstanceRef.current);
          
          // Force immediate size calculation
          setTimeout(() => {
            mapInstanceRef.current.invalidateSize(true);
          }, 10);
          
          setIsMapInitialized(true);
          console.log('Map initialized successfully');
        }
      } catch (error) {
        console.error('Error initializing map:', error);
      }
    };

    initializeMap();
  }, [isLoading]);

  useEffect(() => {
    if (!isMapInitialized || !data || !layerGroupRef.current) return;

    // Clear existing layers
    layerGroupRef.current.clearLayers();
    
    // Setup filter controls
    setupFilterControls();
    
    let featuresAdded = 0;
    const bounds: [number, number][] = [];

    // Add features for each record with geometry data
    data.forEach((record, index) => {
      console.log('Processing record:', record); // Debug log
      
      const geometryColumns = Object.keys(record).filter(key => 
        key.toLowerCase().includes('geometry') || 
        key.toLowerCase().includes('location') ||
        key.toLowerCase().includes('coord') ||
        key.toLowerCase().includes('point')
      );

      console.log('Found geometry columns:', geometryColumns); // Debug log

      geometryColumns.forEach(geometryCol => {
        const geomData = record[geometryCol];
        console.log(`Geometry data for ${geometryCol}:`, geomData); // Debug log
        
        if (geomData) {
          try {
            // Check if it's WKT format (POLYGON/MULTIPOLYGON)
            if (typeof geomData === 'string' && (geomData.trim().toUpperCase().startsWith('POLYGON') || geomData.trim().toUpperCase().startsWith('MULTIPOLYGON'))) {
              console.log('Parsing as WKT polygon:', geomData);
              const geoJson = parseWKTToGeoJSON(geomData);
              console.log('Parsed GeoJSON:', geoJson);
              
              if (geoJson) {
                const layer = window.L.geoJSON(geoJson, {
                  style: {
                    color: '#3388ff',
                    weight: 2,
                    fillOpacity: 0.3,
                    fillColor: getFeatureColor(record, index)
                  },
                  onEachFeature: (feature: any, layer: any) => {
                    const popupContent = createAdvancedPopupContent(record, geometryCol, index);
                    layer.bindPopup(popupContent);
                    layer.record = record;
                    
                    layer.on('mouseover', function(e: any) {
                      e.target.setStyle({ weight: 3, fillOpacity: 0.7 });
                    });
                    
                    layer.on('mouseout', function(e: any) {
                      e.target.setStyle({ weight: 2, fillOpacity: 0.3 });
                    });
                  }
                });
                
                layer.addTo(layerGroupRef.current);
                bounds.push(...getBoundsFromGeoJSON(geoJson));
                featuresAdded++;
                console.log('Added polygon to map');
              }
            } else {
              // Try to parse as coordinate pair
              console.log('Parsing as coordinates:', geomData);
              const coords = parseCoordinates(geomData);
              console.log('Parsed coordinates:', coords);
              
              if (coords && coords.length === 2) {
                const [lat, lng] = coords;
                
                const marker = window.L.circleMarker([lat, lng], {
                  radius: 10,
                  fillColor: getFeatureColor(record, index),
                  color: '#ffffff',
                  weight: 2,
                  opacity: 1,
                  fillOpacity: 0.8
                });
                
                const popupContent = createAdvancedPopupContent(record, geometryCol, index);
                marker.bindPopup(popupContent);
                marker.record = record;
                
                marker.addTo(layerGroupRef.current);
                bounds.push([lat, lng]);
                featuresAdded++;
                console.log('Added marker to map at:', [lat, lng]);
              }
            }
          } catch (error) {
            console.error('Error processing geometry for record:', record, error);
          }
        }
      });
    });

    // Fit map to show all features
    if (bounds.length > 0 && mapInstanceRef.current) {
      const group = new window.L.featureGroup(layerGroupRef.current.getLayers());
      if (group.getBounds().isValid()) {
        mapInstanceRef.current.fitBounds(group.getBounds().pad(0.1));
      }
    }

    console.log(`Added ${featuresAdded} features to map from ${data.length} records`);
    console.log('Map instance:', mapInstanceRef.current);
    console.log('Layer group:', layerGroupRef.current);
    console.log('Sample record keys:', data.length > 0 ? Object.keys(data[0]) : 'No data');
    
    // Force map invalidation to ensure tiles load
    setTimeout(() => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
        console.log('Map size invalidated');
      }
    }, 100);
  }, [data, isMapInitialized]);

  // Helper functions
  const parseWKTToGeoJSON = (wkt: string): any => {
    try {
      // Use wellknown library if available
      if (window.wellknown) {
        return {
          type: 'Feature',
          geometry: window.wellknown.parse(wkt),
          properties: {}
        };
      }
      
      // Manual parsing for MULTIPOLYGON
      if (wkt.toUpperCase().includes('MULTIPOLYGON')) {
        // Extract coordinate groups from MULTIPOLYGON (((coords)), ((coords)))
        const multiMatch = wkt.match(/MULTIPOLYGON\s*\(\s*(.+)\s*\)/i);
        if (multiMatch) {
          // Split by )), (( to get individual polygons
          const polygonStrings = multiMatch[1].split(/\)\s*,\s*\(/);
          const coordinates = polygonStrings.map(polyStr => {
            // Clean up the string and extract coordinates
            const cleanStr = polyStr.replace(/^\(+|\)+$/g, '');
            const coordPairs = cleanStr.split(',').map(pair => {
              const coords = pair.trim().split(/\s+/).map(Number);
              return [coords[0], coords[1]]; // [lng, lat]
            });
            return [coordPairs]; // Wrap in array for polygon holes
          });
          
          return {
            type: 'Feature',
            geometry: {
              type: 'MultiPolygon',
              coordinates: coordinates
            },
            properties: {}
          };
        }
      }
      
      // Basic polygon parsing fallback
      if (wkt.toUpperCase().includes('POLYGON')) {
        const coordMatch = wkt.match(/POLYGON\s*\(\s*\(([^)]+)\)\s*\)/i);
        if (coordMatch) {
          const coordPairs = coordMatch[1].split(',').map(pair => {
            const coords = pair.trim().split(/\s+/).map(Number);
            return [coords[0], coords[1]]; // [lng, lat]
          });
          
          return {
            type: 'Feature',
            geometry: {
              type: 'Polygon',
              coordinates: [coordPairs]
            },
            properties: {}
          };
        }
      }
    } catch (error) {
      console.warn('Error parsing WKT:', wkt, error);
    }
    return null;
  };

  const getBoundsFromGeoJSON = (geoJson: any): [number, number][] => {
    const bounds: [number, number][] = [];
    if (geoJson.geometry && geoJson.geometry.coordinates) {
      const coords = geoJson.geometry.coordinates;
      
      if (geoJson.geometry.type === 'Polygon') {
        coords[0].forEach(([lng, lat]: [number, number]) => bounds.push([lat, lng]));
      } else if (geoJson.geometry.type === 'MultiPolygon') {
        coords.forEach((polygon: any) => {
          polygon[0].forEach(([lng, lat]: [number, number]) => bounds.push([lat, lng]));
        });
      }
    }
    return bounds;
  };

  const getFeatureColor = (record: any, index: number): string => {
    const colors = ['#3388ff', '#ff6b6b', '#4ecdc4', '#45b7d1', '#f39c12', '#e74c3c', '#9b59b6', '#2ecc71'];
    
    // Try to color by category/type field
    const categoryFields = ['category', 'type', 'status', 'classification'];
    for (const field of categoryFields) {
      if (record[field]) {
        const hash = record[field].toString().split('').reduce((a: number, b: string) => {
          a = ((a << 5) - a) + b.charCodeAt(0);
          return a & a;
        }, 0);
        return colors[Math.abs(hash) % colors.length];
      }
    }
    
    return colors[index % colors.length];
  };

  const createAdvancedPopupContent = (record: any, geometryCol: string, index: number): string => {
    const fields = Object.keys(record)
      .filter(key => key !== 'id' && key !== geometryCol)
      .slice(0, 8)
      .map(key => {
        const value = record[key];
        return `
          <div style="margin-bottom: 8px;">
            <div style="font-weight: 500; color: #7f8c8d; font-size: 12px;">${key}:</div>
            <div style="padding: 4px 8px; background: #f8f9fa; border-radius: 4px; margin-top: 2px;">${value || 'N/A'}</div>
          </div>
        `;
      })
      .join('');

    return `
      <div style="max-width: 300px; font-family: Arial, sans-serif;">
        <h4 style="margin: 0 0 12px 0; color: #2563eb; font-size: 16px; font-weight: 600;">
          ${record.name || record.title || `Site ${record.id || index + 1}`}
        </h4>
        ${fields}
      </div>
    `;
  };

  const parseCoordinates = (coordString: any): [number, number] | null => {
    if (!coordString) return null;
    
    const str = String(coordString).trim();
    
    try {
      if (str.includes('POINT')) {
        const match = str.match(/POINT\s*\(\s*([^)]+)\s*\)/i);
        if (match) {
          const coords = match[1].split(/\s+/).map(Number);
          if (coords.length >= 2) {
            return [coords[1], coords[0]]; // [lat, lng]
          }
        }
      } else if (str.includes(',')) {
        const parts = str.split(',').map(s => parseFloat(s.trim()));
        if (parts.length >= 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          if (Math.abs(parts[0]) <= 90) {
            return [parts[0], parts[1]]; // [lat, lng]
          } else {
            return [parts[1], parts[0]]; // [lat, lng]
          }
        }
      } else if (str.includes(' ')) {
        const parts = str.split(/\s+/).map(s => parseFloat(s.trim()));
        if (parts.length >= 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          if (Math.abs(parts[0]) <= 90) {
            return [parts[0], parts[1]];
          } else {
            return [parts[1], parts[0]];
          }
        }
      }
    } catch (error) {
      console.warn('Error parsing coordinates:', coordString, error);
    }
    
    return null;
  };

  const setupFilterControls = () => {
    if (data.length === 0) return;
    
    setTimeout(() => {
      const filterField = document.getElementById('filterField') as HTMLSelectElement;
      const labelField = document.getElementById('labelField') as HTMLSelectElement;
      const colorField = document.getElementById('colorField') as HTMLSelectElement;
      
      if (filterField && labelField && colorField) {
        const fields = Object.keys(data[0]).filter(key => key !== 'id');
        
        [filterField, labelField, colorField].forEach(select => {
          select.innerHTML = select === filterField ? '<option value="">Select field...</option>' : '<option value="">Default</option>';
          fields.forEach(field => {
            const option = document.createElement('option');
            option.value = field;
            option.textContent = field;
            select.appendChild(option);
          });
        });
      }
    }, 100);
  };

  const applyFilter = () => {
    const filterField = (document.getElementById('filterField') as HTMLSelectElement)?.value;
    const filterValue = (document.getElementById('filterValue') as HTMLInputElement)?.value;
    
    if (!filterField || !filterValue) return;
    
    layerGroupRef.current?.eachLayer((layer: any) => {
      const record = layer.record || {};
      const fieldValue = record[filterField];
      if (fieldValue && fieldValue.toString().toLowerCase().includes(filterValue.toLowerCase())) {
        layer.setStyle({ opacity: 1, fillOpacity: 0.6 });
      } else {
        layer.setStyle({ opacity: 0.3, fillOpacity: 0.1 });
      }
    });
  };

  const clearFilter = () => {
    layerGroupRef.current?.eachLayer((layer: any) => {
      layer.setStyle({ opacity: 1, fillOpacity: 0.3 });
    });
    
    const filterValue = document.getElementById('filterValue') as HTMLInputElement;
    if (filterValue) filterValue.value = '';
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="h-full flex items-center justify-center">
          <div className="text-center">
            <Skeleton className="w-16 h-16 rounded-full mx-auto mb-4" />
            <Skeleton className="h-4 w-32 mx-auto" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 relative">
      {/* Map Container */}
      <div 
        ref={mapContainerRef} 
        className="w-full h-full"
        style={{ 
          minHeight: '600px',
          background: '#aad3df',
          position: 'relative'
        }}
      ></div>
      
      {/* Map Controls Overlay */}
      <div className="absolute top-4 right-4 z-10 space-y-3">
        {/* Filter Controls */}
        <Card className="w-80">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Filter Features</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <div>
              <label className="block text-xs font-medium mb-1">Field:</label>
              <select id="filterField" className="w-full text-xs p-1 border rounded">
                <option value="">Select field...</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Value:</label>
              <input 
                type="text" 
                id="filterValue" 
                placeholder="Enter filter value"
                className="w-full text-xs p-1 border rounded"
              />
            </div>
            <div className="flex space-x-2">
              <Button size="sm" className="text-xs" onClick={applyFilter}>Apply</Button>
              <Button size="sm" variant="outline" className="text-xs" onClick={clearFilter}>Clear</Button>
            </div>
          </CardContent>
        </Card>

        {/* Layer Control */}
        <Card className="w-80">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Layers</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              <label className="flex items-center">
                <input type="checkbox" defaultChecked className="rounded border-gray-300 mr-2" />
                <span className="text-sm text-gray-700">Sites</span>
                <span className="ml-auto text-xs text-gray-500">{data.length}</span>
              </label>
            </div>
          </CardContent>
        </Card>

        {/* Map Controls */}
        <Card className="w-80">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Map Controls</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <div>
              <label className="block text-xs font-medium mb-1">Base Map:</label>
              <select id="baseMapSelector" className="w-full text-xs p-1 border rounded">
                <option value="osm">OpenStreetMap</option>
                <option value="custom">Custom Tiles</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Label Field:</label>
              <select id="labelField" className="w-full text-xs p-1 border rounded">
                <option value="">No labels</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Color by Field:</label>
              <select id="colorField" className="w-full text-xs p-1 border rounded">
                <option value="">Default color</option>
              </select>
            </div>
          </CardContent>
        </Card>
        
        {/* Legend */}
        <Card className="w-80">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Legend</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div id="legendContent" className="space-y-2 text-xs">
              <div>Dynamic legend based on data categorization</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map Toolbar */}
      <div className="absolute bottom-4 left-4 z-10">
        <Card>
          <CardContent className="p-2 flex space-x-2">
            <Button variant="ghost" size="sm" title="Zoom to fit">
              <i className="fas fa-expand-arrows-alt"></i>
            </Button>
            <Button variant="ghost" size="sm" title="Add location">
              <i className="fas fa-map-pin"></i>
            </Button>
            <Button variant="ghost" size="sm" title="Draw polygon">
              <i className="fas fa-draw-polygon"></i>
            </Button>
            <Button variant="ghost" size="sm" title="Measure distance">
              <i className="fas fa-ruler"></i>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* No Data State */}
      {data.length === 0 && !isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-50/80">
          <Card className="w-96">
            <CardContent className="p-8 text-center">
              <i className="fas fa-map text-4xl text-gray-400 mb-4"></i>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Location Data</h3>
              <p className="text-gray-500">
                Add records with geometry data to see them on the map.
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Debug info */}
      {data.length > 0 && (
        <div className="absolute bottom-4 right-4 z-10">
          <Card className="opacity-75">
            <CardContent className="p-2 text-xs">
              <div>Records: {data.length}</div>
              <div>Geometry columns: {data.length > 0 ? Object.keys(data[0]).filter(key => 
                key.toLowerCase().includes('geometry') || 
                key.toLowerCase().includes('location') ||
                key.toLowerCase().includes('coord')
              ).join(', ') : 'none'}</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}