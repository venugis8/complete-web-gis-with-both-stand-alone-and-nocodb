import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plus, User, Shield, KeyRound } from "lucide-react";

interface NocoDBUser {
  id: string;
  email: string;
  firstname?: string;
  lastname?: string;
  roles: string;
  created_at: string;
  updated_at: string;
}

interface NocoDBUserManagementProps {
  isOpen: boolean;
  onClose: () => void;
  baseConfig: {
    nocodbUrl: string;
    nocodbApiKey: string;
    nocodbBaseId: string;
    nocodbAdminEmail: string;
    nocodbAdminPassword: string;
  };
}

export default function NocoDBUserManagement({ isOpen, onClose, baseConfig }: NocoDBUserManagementProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserFirstName, setNewUserFirstName] = useState("");
  const [newUserLastName, setNewUserLastName] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserRole, setNewUserRole] = useState("viewer");
  const [resetPasswordUserId, setResetPasswordUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch users from our local database (same as standalone system)
  const { data: users, isLoading: usersLoading } = useQuery<any[]>({
    queryKey: ["/api/base/users"],
    enabled: isOpen,
  });

  // Create new user mutation (same as standalone system)
  const createUserMutation = useMutation({
    mutationFn: async (userData: { email: string; name: string; password: string; role: string }) => {
      const username = userData.email.split('@')[0];
      const response = await fetch("/api/base/users", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          username,
          email: userData.email,
          name: userData.name,
          role: userData.role,
          password: userData.password
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to create user");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/base/users"] });
      setShowAddForm(false);
      setNewUserEmail("");
      setNewUserFirstName("");
      setNewUserLastName("");
      setNewUserPassword("");
      setNewUserRole("viewer");
      toast({ title: "User created successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error creating user", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  // Reset password mutation (same as standalone system)
  const resetPasswordMutation = useMutation({
    mutationFn: async (data: { userId: string; newPassword: string }) => {
      const response = await fetch(`/api/base/users/${data.userId}/reset-password`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          newPassword: data.newPassword
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to reset password");
      }

      return response.json();
    },
    onSuccess: () => {
      setResetPasswordUserId(null);
      setNewPassword("");
      toast({ title: "Password reset successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error resetting password", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const handleCreateUser = () => {
    if (!newUserEmail || !newUserFirstName || !newUserPassword) {
      toast({
        title: "Missing required fields",
        description: "Please fill in email, first name, and password",
        variant: "destructive" 
      });
      return;
    }

    const fullName = `${newUserFirstName.trim()} ${newUserLastName.trim()}`.trim();
    
    createUserMutation.mutate({
      email: newUserEmail.trim(),
      name: fullName,
      password: newUserPassword,
      role: newUserRole
    });
  };

  if (!baseConfig.nocodbApiKey) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>NocoDB User Management</DialogTitle>
          </DialogHeader>
          <div className="p-6 text-center">
            <p className="text-gray-600">NocoDB API key is required to manage users.</p>
            <p className="text-sm text-gray-500 mt-2">Please configure NocoDB settings first.</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            NocoDB User Management
          </DialogTitle>
          <DialogDescription>
            Manage users and their access to your NocoDB base
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 overflow-y-auto flex-1">
          {/* Add User Button */}
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Users</h3>
            <Button
              onClick={() => setShowAddForm(!showAddForm)}
              variant="outline"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add User
            </Button>
          </div>

          {/* Add User Form */}
          {showAddForm && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Add New NocoDB User</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    placeholder="Enter first name"
                    value={newUserFirstName}
                    onChange={(e) => setNewUserFirstName(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    placeholder="Enter last name"
                    value={newUserLastName}
                    onChange={(e) => setNewUserLastName(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter email address"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="role">Role</Label>
                  <Select value={newUserRole} onValueChange={setNewUserRole}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="owner">Owner</SelectItem>
                      <SelectItem value="creator">Creator</SelectItem>
                      <SelectItem value="editor">Editor</SelectItem>
                      <SelectItem value="viewer">Viewer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter password for new user"
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                  />
                </div>
                <div className="md:col-span-2 flex gap-2">
                  <Button 
                    onClick={handleCreateUser}
                    disabled={!newUserFirstName || !newUserEmail || !newUserPassword || createUserMutation.isPending}
                  >
                    {createUserMutation.isPending ? "Creating..." : "Create User"}
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => setShowAddForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* User List */}
          {usersLoading ? (
            <div className="text-center py-8">
              <p>Loading users...</p>
            </div>
          ) : users && users.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Manage Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {users.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">
                          {user.name}
                        </div>
                        <div className="text-sm text-gray-600">{user.email}</div>
                        <Badge variant="secondary" className="text-xs mt-1">
                          {user.role}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        {resetPasswordUserId === user.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="password"
                              placeholder="New password"
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                              className="w-32"
                            />
                            <Button
                              size="sm"
                              onClick={() => resetPasswordMutation.mutate({ userId: user.id, newPassword })}
                              disabled={!newPassword || resetPasswordMutation.isPending}
                            >
                              {resetPasswordMutation.isPending ? "..." : "Save"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setResetPasswordUserId(null);
                                setNewPassword("");
                              }}
                            >
                              Cancel
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setResetPasswordUserId(user.id)}
                          >
                            <KeyRound className="h-3 w-3 mr-1" />
                            Reset Password
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-8">
              <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No users found</p>
              <p className="text-sm text-gray-500">Add users to get started</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}