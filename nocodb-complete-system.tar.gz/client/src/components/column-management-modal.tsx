import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Plus, Edit } from "lucide-react";

type ColumnType = 'text' | 'number' | 'decimal' | 'longtext' | 'attachment' | 'image' | 'date' | 'select';

interface Column {
  name: string;
  type: ColumnType;
  required?: boolean;
  defaultValue?: string;
  selectOptions?: string[];
}

interface ColumnManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  tableId: number;
  tableName: string;
  currentColumns: Column[];
}

const columnTypeLabels: Record<ColumnType, string> = {
  text: "Text",
  number: "Number", 
  decimal: "Decimal",
  longtext: "Long Text",
  attachment: "Attachment",
  image: "Image",
  date: "Date",
  select: "Select One"
};

export default function ColumnManagementModal({ 
  isOpen, 
  onClose, 
  tableId, 
  tableName,
  currentColumns 
}: ColumnManagementModalProps) {
  const [columns, setColumns] = useState<Column[]>(currentColumns);
  const [newColumn, setNewColumn] = useState<Column>({
    name: "",
    type: "text",
    required: false,
    selectOptions: []
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateColumnsMutation = useMutation({
    mutationFn: async (updatedColumns: Column[]) => {
      return apiRequest({
        url: `/api/base/tables/${tableId}/columns`,
        method: "PATCH",
        body: { columns: updatedColumns },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/base/tables"] });
      queryClient.invalidateQueries({ queryKey: [`/api/base/tables/${tableId}/records`] });
      onClose();
      toast({
        title: "Columns Updated",
        description: `Successfully updated columns for ${tableName}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update columns",
        variant: "destructive",
      });
    },
  });

  const addColumn = () => {
    if (!newColumn.name.trim()) {
      toast({
        title: "Column Name Required",
        description: "Please enter a column name",
        variant: "destructive",
      });
      return;
    }

    if (columns.some(col => col.name === newColumn.name)) {
      toast({
        title: "Duplicate Column",
        description: "A column with this name already exists",
        variant: "destructive",
      });
      return;
    }

    setColumns([...columns, { ...newColumn }]);
    setNewColumn({
      name: "",
      type: "text",
      required: false,
      selectOptions: []
    });
  };

  const removeColumn = (index: number) => {
    setColumns(columns.filter((_, i) => i !== index));
  };

  const updateColumn = (index: number, updatedColumn: Column) => {
    setColumns(columns.map((col, i) => i === index ? updatedColumn : col));
  };

  const handleSave = () => {
    updateColumnsMutation.mutate(columns);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Columns - {tableName}</DialogTitle>
          <DialogDescription>
            Add, edit, or remove columns for this table. Changes will be applied to the table structure.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Existing Columns */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Current Columns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {columns.map((column, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{column.name}</span>
                        <Badge variant="secondary">{columnTypeLabels[column.type]}</Badge>
                        {column.required && <Badge variant="outline">Required</Badge>}
                      </div>
                      {column.type === 'select' && column.selectOptions && (
                        <div className="mt-1 text-sm text-muted-foreground">
                          Options: {column.selectOptions.join(', ')}
                        </div>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeColumn(index)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {columns.length === 0 && (
                  <p className="text-muted-foreground text-center py-4">
                    No columns defined yet. Add your first column below.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Add New Column */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Add New Column</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Column Name</Label>
                  <Input
                    value={newColumn.name}
                    onChange={(e) => setNewColumn(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter column name"
                  />
                </div>
                <div>
                  <Label>Column Type</Label>
                  <Select
                    value={newColumn.type}
                    onValueChange={(value: ColumnType) => setNewColumn(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(columnTypeLabels).map(([value, label]) => (
                        <SelectItem key={value} value={value}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {newColumn.type === 'select' && (
                <div>
                  <Label>Select Options (comma-separated)</Label>
                  <Input
                    value={newColumn.selectOptions?.join(', ') || ''}
                    onChange={(e) => {
                      const options = e.target.value.split(',').map(opt => opt.trim()).filter(Boolean);
                      setNewColumn(prev => ({ ...prev, selectOptions: options }));
                    }}
                    placeholder="Option 1, Option 2, Option 3"
                  />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="required"
                  checked={newColumn.required}
                  onChange={(e) => setNewColumn(prev => ({ ...prev, required: e.target.checked }))}
                  className="rounded"
                />
                <Label htmlFor="required">Required field</Label>
              </div>

              <Button onClick={addColumn} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Add Column
              </Button>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              disabled={updateColumnsMutation.isPending}
            >
              {updateColumnsMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}