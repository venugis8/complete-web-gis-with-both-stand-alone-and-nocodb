import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Column {
  key: string;
  label: string;
  isGeometry?: boolean;
  isBadge?: boolean;
  permission?: 'view' | 'edit' | 'hidden';
}

interface DataTableProps {
  data: any[];
  columns: Column[];
  isLoading: boolean;
  tableId?: string;
  getBadgeVariant?: (value: string) => "default" | "secondary" | "destructive" | "outline";
  getBadgeClass?: (value: string) => string;
}

export default function DataTable({ 
  data, 
  columns, 
  isLoading,
  tableId,
  getBadgeVariant = () => "default",
  getBadgeClass = () => ""
}: DataTableProps) {
  const [editMode, setEditMode] = useState(false);
  const [editingCell, setEditingCell] = useState<{row: number, col: string} | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);
  const [pendingEdit, setPendingEdit] = useState<{row: number, col: string, value: string} | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async ({ recordId, updates }: { recordId: string, updates: any }) => {
      return apiRequest(`/api/base/tables/${tableId}/records/${recordId}`, 'PATCH', updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/base/tables', tableId, 'records'] });
      toast({
        title: "Success",
        description: "Record updated successfully",
      });
      setEditingCell(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update record",
        variant: "destructive",
      });
    },
  });

  const handleCellClick = (rowIndex: number, column: Column, currentValue: any) => {
    if (editMode && column.permission === 'edit' && !column.isGeometry) {
      setEditingCell({ row: rowIndex, col: column.key });
      setEditValue(String(currentValue || ''));
    }
  };

  const handleSaveClick = (rowIndex: number, column: Column) => {
    setPendingEdit({ row: rowIndex, col: column.key, value: editValue });
    setShowSaveConfirm(true);
  };

  const confirmSave = () => {
    if (pendingEdit) {
      const record = data[pendingEdit.row];
      const recordId = record.Id || record.id;
      
      if (recordId) {
        const updates = { [pendingEdit.col]: pendingEdit.value };
        updateMutation.mutate({ recordId: String(recordId), updates });
      }
    }
    setShowSaveConfirm(false);
    setPendingEdit(null);
  };

  const cancelSave = () => {
    setShowSaveConfirm(false);
    setPendingEdit(null);
    handleCancelEdit();
  };

  const handleCancelEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  const getRowIcon = (item: any) => {
    if (item.category) {
      switch (item.category.toLowerCase()) {
        case 'office':
          return "fas fa-building text-blue-600";
        case 'warehouse':
          return "fas fa-warehouse text-green-600";
        case 'retail':
          return "fas fa-store text-purple-600";
        default:
          return "fas fa-map-marker-alt text-gray-400";
      }
    }
    return "fas fa-user text-gray-400";
  };

  // Filter out hidden columns
  const visibleColumns = columns.filter(col => col.permission !== 'hidden');

  if (isLoading) {
    return (
      <div className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">
                <Skeleton className="h-4 w-4" />
              </TableHead>
              {columns.map((column, index) => (
                <TableHead key={index}>
                  <Skeleton className="h-4 w-24" />
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {[...Array(5)].map((_, i) => (
              <TableRow key={i}>
                <TableCell>
                  <Skeleton className="h-4 w-4" />
                </TableCell>
                {columns.map((_, j) => (
                  <TableCell key={j}>
                    <Skeleton className="h-4 w-32" />
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="text-center">
          <i className="fas fa-table text-4xl text-gray-400 mb-4"></i>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Data</h3>
          <p className="text-gray-500">
            No records found in this table. Add some data to get started.
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Edit Mode Controls */}
      {hasEditableFields && (
        <div className="mb-4 flex items-center justify-between bg-blue-50 p-3 rounded-lg border">
          <div className="flex items-center space-x-3">
            <i className="fas fa-edit text-blue-600"></i>
            <span className="text-sm font-medium text-blue-900">
              {editMode ? 'Edit Mode Active - Click editable fields to modify' : 'View Mode - Enable editing to modify data'}
            </span>
          </div>
          <Button 
            onClick={() => {
              setEditMode(!editMode);
              setEditingCell(null);
              setEditValue('');
            }}
            variant={editMode ? "destructive" : "default"}
            size="sm"
          >
            <i className={`fas ${editMode ? 'fa-eye' : 'fa-edit'} mr-2`}></i>
            {editMode ? 'Exit Edit Mode' : 'Enable Editing'}
          </Button>
        </div>
      )}

      {/* Confirmation Dialog */}
      {showSaveConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center space-x-3 mb-4">
              <i className="fas fa-save text-blue-600 text-xl"></i>
              <h3 className="text-lg font-semibold">Confirm Edit</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Are you sure you want to save this change? This will update the data in NocoDB and cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={cancelSave}>
                Cancel
              </Button>
              <Button onClick={confirmSave} disabled={updateMutation.isPending}>
                {updateMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fas fa-check mr-2"></i>
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="overflow-auto custom-scrollbar">
        <Table>
          <TableHeader className="sticky top-0 z-10 bg-gray-50">
            <TableRow>
              <TableHead className="w-12">
                <input type="checkbox" className="rounded border-gray-300" />
              </TableHead>
            {columns.map((column) => (
              <TableHead key={column.key} className="border-r border-gray-200">
                <div className="flex items-center space-x-2">
                  <span>{column.label}</span>
                  {column.isGeometry && (
                    <i className="fas fa-map-marker-alt text-emerald-500 text-xs"></i>
                  )}
                  <i className="fas fa-sort text-gray-300 text-xs"></i>
                </div>
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((item, index) => (
            <TableRow key={item.id || index} className="hover:bg-gray-50">
              <TableCell className="border-r border-gray-200">
                <input type="checkbox" className="rounded border-gray-300" />
              </TableCell>
              {columns.map((column) => (
                <TableCell key={column.key} className="border-r border-gray-200">
                  {column.key === 'name' && item.category ? (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className={`${getRowIcon(item)} text-xs`}></i>
                      </div>
                      <span className="font-medium text-gray-900">{item[column.key]}</span>
                    </div>
                  ) : column.isGeometry ? (
                    <span className="font-mono text-sm text-gray-600">{item[column.key]}</span>
                  ) : column.isBadge ? (
                    <Badge 
                      variant={getBadgeVariant(item[column.key])}
                      className={getBadgeClass(item[column.key])}
                    >
                      {item[column.key]}
                    </Badge>
                  ) : (
                    <span className="text-sm text-gray-600">{item[column.key]}</span>
                  )}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
