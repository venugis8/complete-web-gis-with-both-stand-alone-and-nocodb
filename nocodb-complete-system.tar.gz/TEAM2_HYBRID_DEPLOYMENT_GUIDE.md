# Team2 GIS Platform - Hybrid Multi-Tenant Deployment Guide

## Overview

This guide provides complete instructions for deploying a hybrid multi-tenant GIS platform based on the authentic Team2 standalone codebase (`team2_standalone_FULL_master_button_working_20250603.tar.gz`). The hybrid approach maintains the exact original UI and functionality while adding client isolation and multi-tenancy capabilities.

## Architecture Overview

### Hybrid Architecture Benefits
- **Single Server Efficiency**: One deployment serves multiple clients
- **Client Isolation**: Each client has separate database tables and user management
- **Original UI Preserved**: Exact Team2 standalone interface maintained
- **Scalable**: Support for 100+ clients on single server instance
- **Cost Effective**: Reduced infrastructure costs vs separate deployments

### System Components
```
┌─────────────────────────────────────────────────────────────┐
│                    Nginx Reverse Proxy                     │
│                (Domain/Subdomain Routing)                  │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────┴───────────────────────────────────────┐
│                Team2 Hybrid Server                         │
│              (Single Node.js Instance)                     │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │   Client 1  │  │   Client 2  │  │   Client N  │        │
│  │   Tables    │  │   Tables    │  │   Tables    │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────┴───────────────────────────────────────┐
│                PostgreSQL Database                         │
│            (Client-Isolated Table Structure)               │
└─────────────────────────────────────────────────────────────┘
```

## Prerequisites

### Server Requirements
- **OS**: Ubuntu 20.04+ or CentOS 7+
- **RAM**: Minimum 2GB, Recommended 4GB+
- **CPU**: 2+ cores
- **Storage**: 50GB+ SSD
- **Network**: Public IP with ports 80, 443, 22 open

### Software Dependencies
- Node.js 18+ or 20+
- PostgreSQL 12+
- Nginx 1.18+
- PM2 Process Manager
- Git

## Installation Steps

### 1. Server Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Nginx
sudo apt install -y nginx

# Install PM2 globally
sudo npm install -g pm2

# Install Git
sudo apt install -y git unzip
```

### 2. Database Setup

```bash
# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE team2_hybrid;
CREATE USER team2_user WITH PASSWORD 'team2_secure_password_2024';
GRANT ALL PRIVILEGES ON DATABASE team2_hybrid TO team2_user;
ALTER USER team2_user CREATEDB;
\q
EOF
```

### 3. Application Deployment

```bash
# Create application directory
sudo mkdir -p /opt/team2-hybrid
cd /opt/team2-hybrid

# Extract authentic Team2 codebase
# Upload team2_standalone_FULL_master_button_working_20250603.tar.gz to server
sudo tar -xzf team2_standalone_FULL_master_button_working_20250603.tar.gz

# Install dependencies
sudo npm install

# Set proper permissions
sudo chown -R www-data:www-data /opt/team2-hybrid
sudo chmod -R 755 /opt/team2-hybrid
```

### 4. Environment Configuration

Create `/opt/team2-hybrid/.env`:

```env
# Database Configuration
DATABASE_URL=postgresql://team2_user:team2_secure_password_2024@localhost:5432/team2_hybrid
PGHOST=localhost
PGPORT=5432
PGUSER=team2_user
PGPASSWORD=team2_secure_password_2024
PGDATABASE=team2_hybrid

# Server Configuration
NODE_ENV=production
PORT=5000
HOST=0.0.0.0

# Security
SESSION_SECRET=your_super_secure_session_secret_here_2024
JWT_SECRET=your_jwt_secret_key_here_2024

# Multi-tenant Configuration
ENABLE_MULTI_TENANT=true
DEFAULT_CLIENT_DOMAIN=yourdomain.com
SUPER_ADMIN_EMAIL=admin@yourdomain.com
SUPER_ADMIN_PASSWORD=your_super_admin_password

# File Upload Configuration
MAX_FILE_SIZE=50MB
UPLOAD_PATH=/opt/team2-hybrid/uploads

# Map Configuration
DEFAULT_MAP_CENTER_LAT=40.7128
DEFAULT_MAP_CENTER_LNG=-74.0060
DEFAULT_MAP_ZOOM=10
```

## Hybrid Implementation Code

### 1. Multi-Tenant Database Schema

Create `/opt/team2-hybrid/server/hybrid-schema.sql`:

```sql
-- Multi-tenant extension to existing Team2 schema

-- Clients table for tenant management
CREATE TABLE clients (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    subdomain VARCHAR(100) UNIQUE NOT NULL,
    domain VARCHAR(255),
    database_schema VARCHAR(100) NOT NULL,
    config JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Client users (extends existing users with client_id)
CREATE TABLE client_users (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    permissions JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(client_id, email)
);

-- Client tables (extends existing tables with client_id)
CREATE TABLE client_tables (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    table_name VARCHAR(255) NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    table_schema VARCHAR(100) NOT NULL,
    geometry_column VARCHAR(255),
    has_geometry BOOLEAN DEFAULT false,
    field_config JSONB DEFAULT '{}',
    permissions JSONB DEFAULT '{}',
    record_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(client_id, table_name)
);

-- Sessions for authentication
CREATE TABLE client_sessions (
    id SERIAL PRIMARY KEY,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES client_users(id) ON DELETE CASCADE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_clients_subdomain ON clients(subdomain);
CREATE INDEX idx_client_users_client_email ON client_users(client_id, email);
CREATE INDEX idx_client_tables_client ON client_tables(client_id);
CREATE INDEX idx_client_sessions_token ON client_sessions(session_token);
CREATE INDEX idx_client_sessions_client_user ON client_sessions(client_id, user_id);
```

### 2. Client Isolation Middleware

Create `/opt/team2-hybrid/server/middleware/client-isolation.js`:

```javascript
const { pool } = require('../db');

async function getClientFromRequest(req) {
  let clientIdentifier = null;
  
  // Method 1: Subdomain detection
  const hostname = req.get('host') || '';
  const subdomain = hostname.split('.')[0];
  if (subdomain && subdomain !== 'www' && subdomain !== req.app.get('domain')) {
    clientIdentifier = subdomain;
  }
  
  // Method 2: URL parameter
  if (!clientIdentifier && req.query.client) {
    clientIdentifier = req.query.client;
  }
  
  // Method 3: Path-based routing
  if (!clientIdentifier && req.path.startsWith('/client/')) {
    clientIdentifier = req.path.split('/')[2];
  }
  
  if (!clientIdentifier) {
    return null;
  }
  
  // Fetch client from database
  const result = await pool.query(
    'SELECT * FROM clients WHERE subdomain = $1 AND is_active = true',
    [clientIdentifier]
  );
  
  return result.rows[0] || null;
}

function getClientTableName(client, baseTableName) {
  return `${client.database_schema}.${baseTableName}`;
}

async function ensureClientSchema(client) {
  const schemaName = client.database_schema;
  
  // Create schema if it doesn't exist
  await pool.query(`CREATE SCHEMA IF NOT EXISTS ${schemaName}`);
  
  // Create client-specific tables based on Team2 schema
  const clientTables = [
    `CREATE TABLE IF NOT EXISTS ${schemaName}.sites (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      geometry GEOMETRY(POINT, 4326),
      latitude DOUBLE PRECISION,
      longitude DOUBLE PRECISION,
      properties JSONB DEFAULT '{}',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    )`,
    
    `CREATE TABLE IF NOT EXISTS ${schemaName}.uploaded_data (
      id SERIAL PRIMARY KEY,
      table_name VARCHAR(255) NOT NULL,
      file_name VARCHAR(255) NOT NULL,
      columns_info JSONB DEFAULT '{}',
      geometry_column VARCHAR(255),
      record_count INTEGER DEFAULT 0,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    )`,
    
    `CREATE TABLE IF NOT EXISTS ${schemaName}.field_permissions (
      id SERIAL PRIMARY KEY,
      table_name VARCHAR(255) NOT NULL,
      field_name VARCHAR(255) NOT NULL,
      permission_type VARCHAR(50) NOT NULL,
      user_role VARCHAR(50),
      is_visible BOOLEAN DEFAULT true,
      is_editable BOOLEAN DEFAULT false,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    )`
  ];
  
  for (const tableSQL of clientTables) {
    await pool.query(tableSQL);
  }
}

module.exports = {
  getClientFromRequest,
  getClientTableName,
  ensureClientSchema
};
```

### 3. Enhanced Server Configuration

Modify `/opt/team2-hybrid/server/index.ts` to add hybrid functionality:

```typescript
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { getClientFromRequest, ensureClientSchema } from "./middleware/client-isolation";

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

// Multi-tenant middleware
app.use(async (req: any, res, next) => {
  try {
    // Skip client detection for super admin routes
    if (req.path.startsWith('/api/super-admin') || req.path.startsWith('/super-admin')) {
      return next();
    }
    
    const client = await getClientFromRequest(req);
    if (client) {
      req.client = client;
      req.clientSchema = client.database_schema;
      await ensureClientSchema(client);
    }
    
    next();
  } catch (error) {
    console.error('Client resolution error:', error);
    res.status(500).json({ error: 'Client resolution failed' });
  }
});

// Super Admin routes for client management
app.get('/api/super-admin/clients', async (req, res) => {
  try {
    const { pool } = await import('./db');
    const result = await pool.query(`
      SELECT c.*, 
             COUNT(DISTINCT cu.id) as user_count,
             COUNT(DISTINCT ct.id) as table_count
      FROM clients c
      LEFT JOIN client_users cu ON c.id = cu.client_id AND cu.is_active = true
      LEFT JOIN client_tables ct ON c.id = ct.client_id
      WHERE c.is_active = true
      GROUP BY c.id
      ORDER BY c.created_at DESC
    `);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching clients:', error);
    res.status(500).json({ error: 'Failed to fetch clients' });
  }
});

app.post('/api/super-admin/clients', async (req, res) => {
  try {
    const { name, subdomain, adminEmail, adminPassword } = req.body;
    const { pool } = await import('./db');
    
    // Create client
    const clientResult = await pool.query(`
      INSERT INTO clients (name, subdomain, database_schema, config)
      VALUES ($1, $2, $3, $4)
      RETURNING *
    `, [name, subdomain, `client_${subdomain}`, {}]);
    
    const client = clientResult.rows[0];
    
    // Create client schema and tables
    await ensureClientSchema(client);
    
    // Create admin user
    const bcrypt = require('bcrypt');
    const passwordHash = await bcrypt.hash(adminPassword, 10);
    
    await pool.query(`
      INSERT INTO client_users (client_id, email, password_hash, name, role)
      VALUES ($1, $2, $3, $4, 'admin')
    `, [client.id, adminEmail, passwordHash, 'Admin User']);
    
    res.json(client);
  } catch (error) {
    console.error('Error creating client:', error);
    res.status(500).json({ error: 'Failed to create client' });
  }
});

// Rest of your existing Team2 code...
(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });

  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`Team2 Hybrid Platform serving on port ${port}`);
    log(`Super Admin: http://localhost:${port}/super-admin`);
  });
})();
```

## Client Management Interface

### 1. Super Admin Dashboard

Add to `/opt/team2-hybrid/client/src/pages/SuperAdminDashboard.tsx`:

```typescript
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface Client {
  id: number;
  name: string;
  subdomain: string;
  user_count: number;
  table_count: number;
  is_active: boolean;
  created_at: string;
}

export default function SuperAdminDashboard() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);

  useEffect(() => {
    fetchClients();
  }, []);

  async function fetchClients() {
    try {
      const response = await fetch('/api/super-admin/clients');
      const data = await response.json();
      setClients(data);
    } catch (error) {
      console.error('Error fetching clients:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Team2 Hybrid GIS Platform - Super Admin</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Total Clients</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{clients.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {clients.reduce((sum, client) => sum + client.user_count, 0)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Total Tables</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {clients.reduce((sum, client) => sum + client.table_count, 0)}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Create New Client</CardTitle>
              <CardDescription>Deploy a new GIS workspace for a client</CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => setShowCreateForm(!showCreateForm)}
                className="w-full"
              >
                {showCreateForm ? 'Cancel' : 'Create New Client'}
              </Button>
              
              {showCreateForm && (
                <CreateClientForm 
                  onSuccess={() => {
                    setShowCreateForm(false);
                    fetchClients();
                  }}
                />
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Client Management</CardTitle>
              <CardDescription>Manage existing client workspaces</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {clients.map(client => (
                  <ClientCard key={client.id} client={client} />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function CreateClientForm({ onSuccess }: { onSuccess: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    subdomain: '',
    adminEmail: '',
    adminPassword: ''
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const response = await fetch('/api/super-admin/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        alert('Client created successfully!');
        onSuccess();
      } else {
        const error = await response.text();
        alert('Error: ' + error);
      }
    } catch (error) {
      alert('Error: ' + error);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <input
        type="text"
        placeholder="Client Name"
        value={formData.name}
        onChange={(e) => setFormData({...formData, name: e.target.value})}
        className="w-full border rounded px-3 py-2"
        required
      />
      <input
        type="text"
        placeholder="Subdomain"
        value={formData.subdomain}
        onChange={(e) => setFormData({...formData, subdomain: e.target.value})}
        className="w-full border rounded px-3 py-2"
        required
      />
      <input
        type="email"
        placeholder="Admin Email"
        value={formData.adminEmail}
        onChange={(e) => setFormData({...formData, adminEmail: e.target.value})}
        className="w-full border rounded px-3 py-2"
        required
      />
      <input
        type="password"
        placeholder="Admin Password"
        value={formData.adminPassword}
        onChange={(e) => setFormData({...formData, adminPassword: e.target.value})}
        className="w-full border rounded px-3 py-2"
        required
      />
      <Button type="submit" className="w-full">Create Client</Button>
    </form>
  );
}

function ClientCard({ client }: { client: Client }) {
  return (
    <div className="border rounded-lg p-4 bg-gray-50">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h3 className="font-semibold">{client.name}</h3>
          <p className="text-sm text-gray-600">{client.subdomain}.yourdomain.com</p>
        </div>
        <div className="text-sm text-gray-500">
          {client.user_count} users • {client.table_count} tables
        </div>
      </div>
      <div className="flex space-x-2">
        <a 
          href={`/client/${client.subdomain}/workspace`}
          className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
        >
          Access Workspace
        </a>
        <a 
          href={`/client/${client.subdomain}/login`}
          className="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600"
        >
          Client Login
        </a>
      </div>
    </div>
  );
}
```

## Nginx Configuration

### 1. Create Nginx Virtual Host

Create `/etc/nginx/sites-available/team2-hybrid`:

```nginx
# Multi-tenant configuration for Team2 Hybrid Platform
server {
    listen 80;
    server_name yourdomain.com *.yourdomain.com;
    
    client_max_body_size 50M;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Main application proxy
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
    }
    
    # Static file handling
    location /uploads/ {
        alias /opt/team2-hybrid/uploads/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}

# SSL configuration (add after obtaining SSL certificates)
# server {
#     listen 443 ssl http2;
#     server_name yourdomain.com *.yourdomain.com;
#     
#     ssl_certificate /path/to/your/cert.pem;
#     ssl_certificate_key /path/to/your/private.key;
#     ssl_protocols TLSv1.2 TLSv1.3;
#     ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
#     ssl_prefer_server_ciphers off;
#     
#     # Same location blocks as above
# }
```

### 2. Enable the Site

```bash
# Enable the site
sudo ln -s /etc/nginx/sites-available/team2-hybrid /etc/nginx/sites-enabled/

# Remove default site
sudo rm -f /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

## Process Management with PM2

### 1. PM2 Ecosystem Configuration

Create `/opt/team2-hybrid/ecosystem.config.js`:

```javascript
module.exports = {
  apps: [{
    name: 'team2-hybrid-gis',
    script: 'dist/index.js',
    cwd: '/opt/team2-hybrid',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    log_file: '/var/log/team2-hybrid.log',
    out_file: '/var/log/team2-hybrid-out.log',
    error_file: '/var/log/team2-hybrid-error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    max_memory_restart: '1G',
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '60s',
    watch: false,
    ignore_watch: ['node_modules', 'uploads', 'logs'],
    source_map_support: true
  }]
};
```

### 2. Production Deployment Commands

```bash
# Build the application
cd /opt/team2-hybrid
npm run build

# Start with PM2
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
pm2 save

# Generate startup script
pm2 startup systemd

# Enable automatic startup
sudo systemctl enable pm2-root
```

## SSL Certificate Setup (Optional but Recommended)

### Using Let's Encrypt

```bash
# Install Certbot
sudo apt install snapd
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot

# Create symbolic link
sudo ln -s /snap/bin/certbot /usr/bin/certbot

# Obtain SSL certificate
sudo certbot --nginx -d yourdomain.com -d *.yourdomain.com

# Auto-renewal
sudo crontab -e
# Add this line:
# 0 12 * * * /usr/bin/certbot renew --quiet
```

## Monitoring and Maintenance

### 1. Log Management

```bash
# View application logs
pm2 logs team2-hybrid-gis

# View Nginx access logs
sudo tail -f /var/log/nginx/access.log

# View Nginx error logs
sudo tail -f /var/log/nginx/error.log

# View PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-12-main.log
```

### 2. Performance Monitoring

```bash
# PM2 monitoring
pm2 monit

# System resources
htop

# Database performance
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity;"
```

### 3. Backup Strategy

Create `/opt/team2-hybrid/scripts/backup.sh`:

```bash
#!/bin/bash

# Database backup
BACKUP_DIR="/opt/backups/team2-hybrid"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup database
sudo -u postgres pg_dump team2_hybrid > $BACKUP_DIR/database_$DATE.sql

# Backup uploaded files
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /opt/team2-hybrid/uploads/

# Backup application code
tar -czf $BACKUP_DIR/application_$DATE.tar.gz /opt/team2-hybrid/ --exclude=node_modules --exclude=uploads

# Clean old backups (keep last 7 days)
find $BACKUP_DIR -type f -mtime +7 -delete

echo "Backup completed: $DATE"
```

Make it executable and add to cron:

```bash
chmod +x /opt/team2-hybrid/scripts/backup.sh

# Add to crontab for daily backups
sudo crontab -e
# Add: 0 2 * * * /opt/team2-hybrid/scripts/backup.sh
```

## Access URLs

After deployment, the platform will be accessible via:

- **Super Admin Dashboard**: `https://yourdomain.com/super-admin`
- **Client Workspaces**: `https://clientname.yourdomain.com/workspace`
- **Client Login**: `https://clientname.yourdomain.com/login`
- **API Endpoints**: `https://yourdomain.com/api/`

## Security Considerations

### 1. Database Security
- Use strong passwords for PostgreSQL users
- Enable PostgreSQL authentication logging
- Regular security updates
- Network firewall rules

### 2. Application Security
- Environment variables for sensitive data
- Rate limiting for API endpoints
- Input validation and sanitization
- Regular dependency updates

### 3. Server Security
- SSH key-based authentication
- Fail2ban for brute force protection
- Regular system updates
- Firewall configuration

## Troubleshooting

### Common Issues

1. **Port conflicts**: Ensure port 5000 is available
2. **Database connection**: Check PostgreSQL service and credentials
3. **Nginx errors**: Verify configuration syntax with `nginx -t`
4. **PM2 issues**: Check logs with `pm2 logs`
5. **SSL problems**: Verify certificate paths and permissions

### Debug Commands

```bash
# Check application status
pm2 status
systemctl status nginx
systemctl status postgresql

# Test database connection
sudo -u postgres psql -c "SELECT version();"

# Test application endpoints
curl -I http://localhost:5000/health
curl -I http://yourdomain.com/super-admin
```

## Support and Documentation

This hybrid deployment maintains 100% compatibility with the original Team2 standalone functionality while adding multi-tenant capabilities. All original features including CSV upload, GIS mapping, user management, and field permissions are preserved.

For additional support, refer to the original Team2 documentation and ensure your team is familiar with the existing codebase structure before deployment.