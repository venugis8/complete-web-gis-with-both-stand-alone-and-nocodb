# Complete Technical Documentation & Knowledge Transfer

## System Access & Credentials

### Server Access
```bash
SSH: ssh root@172.232.108.139
Password: Geo@asset15!
Application: /opt/team2-gis
Port: 5000
Status: Production Active
```

### PostgreSQL Database
```bash
# Master Access (Full Admin)
Host: 172.232.108.139
Port: 5432
Username: postgres
Password: PostgresAdmin2024!
Database: gisdb

# Application Access
Username: gisuser
Password: gispassword123
Connection: postgresql://gisuser:gispassword123@172.232.108.139:5432/gisdb

# External Tools (pgAdmin/DBeaver)
Host: 172.232.108.139
Port: 5432
Username: postgres
Password: PostgresAdmin2024!
SSL: Prefer/Allow
```

## Complete Application Structure

### Core Architecture
```
team2-gis/
├── client/                          # React Frontend Application
│   ├── index.html                   # Entry HTML template
│   └── src/
│       ├── components/              # React Components
│       │   ├── ui/                  # Base UI Components (shadcn/ui)
│       │   │   ├── accordion.tsx
│       │   │   ├── alert-dialog.tsx
│       │   │   ├── button.tsx
│       │   │   ├── card.tsx
│       │   │   ├── dialog.tsx
│       │   │   ├── form.tsx
│       │   │   ├── input.tsx
│       │   │   ├── table.tsx
│       │   │   ├── toast.tsx
│       │   │   └── [50+ UI components]
│       │   ├── column-management-modal.tsx    # Data column management
│       │   ├── csv-upload-modal.tsx          # File upload interface
│       │   ├── deployment-selector-modal.tsx # Deployment configuration
│       │   ├── enhanced-data-table.tsx       # Advanced data table
│       │   ├── magic-link-banner.tsx         # Magic link UI
│       │   ├── magic-link-display.tsx        # Magic link generation
│       │   ├── map-view-new.tsx              # Enhanced map component
│       │   ├── map-view.tsx                  # Base map component
│       │   ├── nocodb-ui-customizer.tsx      # NocoDB customization
│       │   ├── nocodb-user-management.tsx    # User management
│       │   ├── permissions-matrix.tsx        # Permission management
│       │   ├── system-mode-switcher.tsx      # System mode toggle
│       │   └── user-management-modal.tsx     # User administration
│       ├── pages/                   # Route Components
│       │   ├── admin-setup.tsx      # Admin configuration
│       │   ├── base-workspace.tsx   # Main workspace
│       │   ├── get-magic-link.tsx   # Magic link generation
│       │   ├── login.tsx            # Authentication
│       │   ├── logs.tsx             # System logs
│       │   ├── map-fullscreen.tsx   # Fullscreen map
│       │   ├── master-admin.tsx     # Master administration
│       │   ├── not-found.tsx        # 404 handler
│       │   ├── super-admin-deploy.tsx # Deployment management
│       │   ├── super-admin.tsx      # Super admin panel
│       │   └── test-magic-link.tsx  # Magic link testing
│       ├── hooks/                   # Custom React Hooks
│       │   ├── use-map.ts           # Map functionality
│       │   ├── use-mobile.tsx       # Mobile detection
│       │   └── use-toast.ts         # Toast notifications
│       ├── lib/                     # Utility Libraries
│       │   ├── auth.ts              # Authentication utilities
│       │   ├── map-utils.ts         # Map helper functions
│       │   ├── queryClient.ts       # TanStack Query setup
│       │   ├── system-mode.ts       # System mode management
│       │   └── utils.ts             # General utilities
│       ├── App.tsx                  # Main application component
│       ├── main.tsx                 # React entry point
│       └── index.css                # Global styles with Tailwind
├── server/                          # Backend Express Server
│   ├── index.ts                     # Main server entry
│   ├── routes.ts                    # API route definitions
│   ├── storage.ts                   # Data access layer
│   ├── db.ts                        # Database configuration
│   ├── vite.ts                      # Vite development integration
│   └── public/                      # Static file serving
├── shared/                          # Shared TypeScript Definitions
│   └── schema.ts                    # Database schema & types
├── Configuration Files
│   ├── package.json                 # Project dependencies
│   ├── package-lock.json            # Dependency lock
│   ├── tsconfig.json                # TypeScript configuration
│   ├── vite.config.ts               # Vite build configuration
│   ├── tailwind.config.ts           # Tailwind CSS setup
│   ├── drizzle.config.ts            # Database ORM configuration
│   ├── components.json              # shadcn/ui component config
│   ├── postcss.config.js            # CSS processing
│   └── .env                         # Environment variables
└── Documentation
    └── README.md                    # Project documentation
```

## Technology Stack Details

### Frontend Technologies
- **React**: 18.3.1 (Latest stable with concurrent features)
- **TypeScript**: 5.6.3 (Full type safety)
- **Vite**: 5.4.14 (Fast build tool and dev server)
- **TanStack Query**: 5.60.5 (Server state management)
- **React Hook Form**: 7.55.0 (Form handling)
- **Zod**: 3.24.2 (Schema validation)
- **Tailwind CSS**: 3.4.17 (Utility-first styling)
- **Radix UI**: Complete component primitives
- **Leaflet**: 1.9.4 (Interactive maps)
- **Lucide React**: 0.453.0 (Icon library)
- **Wouter**: 3.3.5 (Lightweight routing)

### Backend Technologies
- **Node.js**: 20.19.2 (LTS runtime)
- **Express**: 4.21.2 (Web framework)
- **Drizzle ORM**: 0.39.1 (Type-safe database ORM)
- **PostgreSQL**: 14+ with PostGIS (Spatial database)
- **Passport.js**: 0.7.0 (Authentication middleware)
- **bcrypt**: 6.0.0 (Password hashing)
- **express-session**: 1.18.1 (Session management)

## Database Schema Complete

### Core Tables Structure
```sql
-- Main tenant/base management
CREATE TABLE bases (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    subdomain VARCHAR(100) UNIQUE NOT NULL,
    custom_domain VARCHAR(255),
    db_path VARCHAR(255) DEFAULT 'default',
    status VARCHAR(50) DEFAULT 'active',
    settings JSONB DEFAULT '{}',
    system_mode VARCHAR(50) DEFAULT 'standalone',
    deployment_type VARCHAR(50) DEFAULT 'basic',
    nocodb_base_id TEXT,
    nocodb_url TEXT,
    nocodb_api_key TEXT,
    nocodb_admin_email TEXT,
    nocodb_admin_password TEXT,
    sites_table_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User authentication and management
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'user',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Session management
CREATE TABLE user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Geospatial site data
CREATE TABLE sites (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location TEXT,
    coordinates GEOMETRY(POINT, 4326),
    properties JSONB DEFAULT '{}',
    user_id INTEGER REFERENCES users(id),
    base_id INTEGER REFERENCES bases(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Performance indexes
CREATE INDEX idx_bases_subdomain ON bases(subdomain);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_sessions_expires ON user_sessions(expires_at);
CREATE INDEX idx_sites_coordinates ON sites USING GIST (coordinates);
CREATE INDEX idx_sites_base_id ON sites(base_id);
```

### Current Database Content
```sql
-- Existing bases
SELECT * FROM bases;
-- Results:
-- id=1: Team 2 Standalone (subdomain: team2)
-- id=2: sln (subdomain: sln)
```

## API Endpoints Reference

### Authentication Endpoints
```
POST /api/auth/login              # Standard login
POST /api/auth/logout             # User logout
GET  /api/auth/me                 # Current user info
GET  /api/magic-link/:token       # Magic link authentication
```

### Base Management (Super Admin)
```
GET  /api/super-admin/bases       # List all bases
POST /api/super-admin/bases       # Create new base
PUT  /api/super-admin/bases/:id   # Update base
DELETE /api/super-admin/bases/:id # Delete base
```

### Data Management
```
GET  /api/sites                   # List sites
POST /api/sites                   # Create site
GET  /api/sites/:id               # Get specific site
PUT  /api/sites/:id               # Update site
DELETE /api/sites/:id             # Delete site
```

### File Operations
```
POST /api/upload                  # File upload
POST /api/import-csv              # CSV data import
```

## Operational Commands

### Application Management
```bash
# PM2 Process Management
pm2 status                        # Check process status
pm2 start npm --name "team2-gis" -- run dev
pm2 stop team2-gis               # Stop application
pm2 restart team2-gis            # Restart application
pm2 logs team2-gis               # View logs
pm2 logs team2-gis --lines 100   # View more logs
pm2 delete team2-gis             # Remove process

# Application Health Check
curl http://localhost:5000/       # Test frontend
curl http://localhost:5000/api/super-admin/bases  # Test API
```

### Database Operations
```bash
# Database Connection Test
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT version();"

# List all tables
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "\dt"

# Check bases
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT * FROM bases;"

# Database backup
pg_dump -U gisuser -h localhost gisdb > backup_$(date +%Y%m%d_%H%M%S).sql

# Master access (full privileges)
PGPASSWORD=PostgresAdmin2024! psql -U postgres -h localhost -d gisdb
```

### System Monitoring
```bash
# Server resource usage
top
htop
df -h                             # Disk usage
free -h                          # Memory usage

# Network connectivity
netstat -tulpn | grep :5000      # Check port 5000
ss -tulpn | grep :5432           # Check PostgreSQL port

# Service status
systemctl status postgresql      # Database service
systemctl status nginx          # Web server (if configured)
```

## Development Workflow

### Local Development
```bash
# Start development server
cd /opt/team2-gis
npm run dev                      # Runs on localhost:5000

# Build for production
npm run build                    # Creates dist/ directory

# Type checking
npm run check                    # TypeScript validation

# Database operations
npm run db:push                  # Push schema changes
```

### Environment Configuration
```bash
# .env file contents
DATABASE_URL=postgresql://gisuser:gispassword123@localhost:5432/gisdb
NODE_ENV=development
PORT=5000
HOST=0.0.0.0
```

## Feature Overview

### Core Features Implemented
1. **Multi-tenant Architecture**: Complete base isolation with subdomain routing
2. **Authentication System**: Passport.js with session management
3. **Magic Link Deployment**: Automated tenant setup via magic links
4. **Geospatial Data Management**: PostGIS integration with Leaflet maps
5. **File Upload System**: CSV import with geometry detection
6. **User Management**: Role-based access control
7. **Data Tables**: Advanced sorting, filtering, and pagination
8. **Responsive UI**: Mobile-first design with Tailwind CSS
9. **Real-time Updates**: TanStack Query for efficient data fetching
10. **Type Safety**: Full TypeScript implementation

### Advanced Components
- **Enhanced Data Table**: Sortable columns, filtering, export functionality
- **Map Integration**: Interactive Leaflet maps with geospatial data visualization
- **CSV Upload Modal**: Drag-and-drop file upload with data preview
- **Permission Matrix**: Granular access control management
- **Magic Link System**: Automated deployment and setup
- **System Mode Switcher**: Toggle between standalone and multi-tenant modes

## Security Implementation

### Authentication Security
- bcrypt password hashing with salt rounds
- Session-based authentication with PostgreSQL storage
- CSRF protection via express session configuration
- Role-based access control (admin, user, viewer)

### Database Security
- Parameterized queries preventing SQL injection
- Connection encryption between application and database
- User privilege separation (application vs admin access)
- Regular security updates and patches

### Network Security
- HTTPS/TLS termination at reverse proxy level
- Firewall configuration restricting unnecessary ports
- SSH key-based authentication recommended
- Database access restricted to application user

## Backup Strategy

### Automated Backups
```bash
# Daily database backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -U gisuser -h localhost gisdb > /opt/backups/gisdb_$DATE.sql
find /opt/backups -name "*.sql" -mtime +7 -delete

# Application backup
tar --exclude='node_modules' -czf /opt/backups/team2-gis_$DATE.tar.gz /opt/team2-gis/
```

### Recovery Procedures
```bash
# Database restore
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb < backup_file.sql

# Application restore
tar -xzf backup_file.tar.gz -C /opt/
pm2 restart team2-gis
```

## Performance Optimization

### Database Performance
- Proper indexing on frequently queried columns
- PostGIS spatial indexes for geometric queries
- Connection pooling for efficient resource usage
- Query optimization for large datasets

### Application Performance
- Vite build optimization with code splitting
- React component lazy loading
- TanStack Query caching strategy
- Tailwind CSS purging for minimal bundle size

### Server Performance
- PM2 cluster mode for multiple CPU cores
- Nginx reverse proxy for static asset serving
- Gzip compression for network optimization
- Memory and CPU monitoring with PM2

This documentation provides complete technical knowledge transfer for maintaining, developing, and scaling the GIS SaaS platform.