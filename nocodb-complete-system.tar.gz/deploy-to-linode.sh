#!/bin/bash

# Deploy NocoDB System to Linode - Exact mapz.in:5001 equivalent
# This script deploys the pure NocoDB system from GitHub to Linode server

SERVER_IP="172.232.108.139"
SERVER_USER="root"
SERVER_PASS="Geo@asset15!"
DEPLOY_DIR="/opt/nocodb-gis"

echo "🚀 Deploying NocoDB System to Linode..."
echo "Target: mapz.online (${SERVER_IP})"

# Upload the exact NocoDB server file
sshpass -p "${SERVER_PASS}" scp -o StrictHostKeyChecking=no nocodb-server.cjs ${SERVER_USER}@${SERVER_IP}:${DEPLOY_DIR}/nocodb-5001.cjs

# Stop existing process and start new one
sshpass -p "${SERVER_PASS}" ssh -o StrictHostKeyChecking=no ${SERVER_USER}@${SERVER_IP} << 'EOF'
cd /opt/nocodb-gis
pm2 stop nocodb-5001 2>/dev/null || true
pm2 start nocodb-5001.cjs --name nocodb-5001
pm2 save
EOF

echo "✅ Deployment complete!"
echo "🔗 System available at: http://mapz.online"
echo "📊 API Endpoints:"
echo "   - Tables: http://mapz.online/api/v1/nocodb-tables"
echo "   - Admin: http://mapz.online/api/super-admin/bases"
echo "   - Health: http://mapz.online/health"