const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 5000;
const HOST = '0.0.0.0';

console.log('Team2 Complete Hybrid GIS Platform - Starting server...');

// In-memory storage for demo purposes
let clientBases = [
    {
        id: 1,
        name: "Acme Corp Base",
        subdomain: "acme-corp",
        customDomain: "",
        status: "active",
        userCount: 12,
        tableCount: 5,
        createdAt: "2024-01-15T10:30:00Z",
        adminEmail: "admin@acme-corp.com"
    }
];

const server = http.createServer((req, res) => {
    try {
        const parsedUrl = url.parse(req.url, true);
        const pathname = parsedUrl.pathname;
        const hostname = req.headers.host || '';
        const method = req.method;
        
        console.log(`[${new Date().toISOString()}] ${method} ${pathname} - Host: ${hostname}`);
        
        // Set CORS headers
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        
        if (method === 'OPTIONS') {
            res.writeHead(200);
            res.end();
            return;
        }

        // Handle POST requests for creating new bases
        if (method === 'POST' && pathname === '/api/create-base') {
            let body = '';
            req.on('data', chunk => {
                body += chunk.toString();
            });
            req.on('end', () => {
                try {
                    const data = JSON.parse(body);
                    const { clientName, subdomain, adminEmail, adminPassword } = data;
                    
                    // Create new base
                    const newBase = {
                        id: clientBases.length + 1,
                        name: clientName,
                        subdomain: subdomain,
                        customDomain: "",
                        status: "active",
                        userCount: 1,
                        tableCount: 0,
                        createdAt: new Date().toISOString(),
                        adminEmail: adminEmail
                    };
                    
                    clientBases.push(newBase);
                    
                    // Create client folder structure
                    createClientFolderStructure(subdomain, clientName);
                    
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ 
                        success: true, 
                        base: newBase,
                        message: `Client ${clientName} created successfully with subdomain ${subdomain}`
                    }));
                } catch (error) {
                    console.error('Error creating base:', error);
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: false, error: 'Invalid request data' }));
                }
            });
            return;
        }

        // Get bases API
        if (method === 'GET' && pathname === '/api/bases') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(clientBases));
            return;
        }
        
        // Super Admin Dashboard - Authentic Team2 UI with Working Modals
        if ((pathname === '/super-admin' || pathname === '/') && hostname === 'mapz.online') {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team2 GIS Platform - Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .primary-color { color: #3b82f6; }
        .primary-bg { background-color: #3b82f6; }
        .success-color { color: #10b981; }
        .success-bg { background-color: #10b981; }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); }
        .modal-content { background-color: white; margin: 5% auto; padding: 20px; border-radius: 8px; width: 90%; max-width: 600px; }
        .modal.show { display: block; }
    </style>
</head>
<body class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 primary-bg rounded-lg flex items-center justify-center">
                        <i class="fas fa-database text-white text-sm"></i>
                    </div>
                    <h1 class="text-xl font-semibold text-gray-900">STANDALONE VERSION</h1>
                    <span class="text-sm text-gray-500">Independent Platform</span>
                </div>
                <div class="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium">
                    Super Admin
                </div>
            </div>
            <div class="flex items-center space-x-4">
                <button class="flex items-center space-x-2 text-gray-600 hover:text-gray-900">
                    <i class="fas fa-bell"></i>
                    <span class="text-sm">Notifications</span>
                </button>
                <div class="flex items-center space-x-3">
                    <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=32&h=32&fit=crop&crop=face" 
                         alt="Admin avatar" class="w-8 h-8 rounded-full">
                    <span class="text-sm font-medium text-gray-700">Admin User</span>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-6 py-8">
        <!-- Magic Links Section -->
        <div class="mb-6 space-y-3">
            <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-check-circle text-green-600"></i>
                            <p class="font-medium text-green-800">Magic Link for SSC5 Admin</p>
                        </div>
                        <p class="text-sm text-green-600 mt-1">Copy and share this link to complete admin setup</p>
                    </div>
                    <button onclick="copyToClipboard('http://client1.mapz.online/admin-setup/ssc5demo123')" 
                            class="bg-white border border-green-300 text-green-700 px-4 py-2 rounded-lg hover:bg-green-50 flex items-center space-x-2">
                        <i class="far fa-copy"></i>
                        <span>Copy SSC5 Link</span>
                    </button>
                </div>
            </div>
            
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-check-circle text-blue-600"></i>
                            <p class="font-medium text-blue-800">Magic Link for SSC6 Admin</p>
                        </div>
                        <p class="text-sm text-blue-600 mt-1">Copy and share this link to complete admin setup</p>
                    </div>
                    <button onclick="copyToClipboard('http://client2.mapz.online/admin-setup/ssc6demo123')" 
                            class="bg-white border border-blue-300 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-50 flex items-center space-x-2">
                        <i class="far fa-copy"></i>
                        <span>Copy SSC6 Link</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Standalone Deployments</p>
                        <p class="text-3xl font-bold text-gray-900" id="totalBases">3</p>
                        <p class="text-sm success-color mt-2">+12% from last month</p>
                    </div>
                    <div class="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-server text-blue-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Active Users</p>
                        <p class="text-3xl font-bold text-gray-900" id="totalUsers">4</p>
                        <p class="text-sm success-color mt-2">+8% from last month</p>
                    </div>
                    <div class="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-users text-green-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Tables</p>
                        <p class="text-3xl font-bold text-gray-900" id="totalTables">1</p>
                        <p class="text-sm success-color mt-2">+5% from last month</p>
                    </div>
                    <div class="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-table text-orange-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">API Requests</p>
                        <p class="text-3xl font-bold text-gray-900">892K</p>
                        <p class="text-sm success-color mt-2">+23% from last month</p>
                    </div>
                    <div class="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-chart-line text-purple-600"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Customer Bases Section -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold text-gray-900">Customer Bases</h2>
                    <div class="flex items-center space-x-3">
                        <button onclick="openDeployModal()" class="success-bg text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center space-x-2">
                            <i class="fas fa-rocket"></i>
                            <span>Deploy System</span>
                        </button>
                        <button onclick="openQuickCreateModal()" class="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 flex items-center space-x-2">
                            <i class="fas fa-plus"></i>
                            <span>Quick Create</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="p-6">
                <!-- Bases Table -->
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead>
                            <tr class="border-b border-gray-200">
                                <th class="text-left py-3 px-4 font-medium text-gray-900">Base Name</th>
                                <th class="text-left py-3 px-4 font-medium text-gray-900">Subdomain</th>
                                <th class="text-left py-3 px-4 font-medium text-gray-900">Users</th>
                                <th class="text-left py-3 px-4 font-medium text-gray-900">Tables</th>
                                <th class="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                                <th class="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="basesTableBody">
                            <!-- Dynamic content loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Deploy System Modal -->
    <div id="deployModal" class="modal">
        <div class="modal-content">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-semibold text-gray-900">Deploy New System</h2>
                <button onclick="closeDeployModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <!-- System Configuration Card -->
            <div class="border border-blue-200 rounded-lg p-6 mb-6">
                <div class="flex items-start justify-between">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-server text-blue-600"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold primary-color">Independent System</h3>
                            <p class="text-gray-600">PostgreSQL + Self-hosted</p>
                        </div>
                    </div>
                    <button class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200">
                        <i class="fas fa-sync-alt text-gray-600"></i>
                    </button>
                </div>
                
                <div class="mt-6">
                    <h4 class="font-medium text-gray-900 mb-3">FEATURES</h4>
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                        <div class="primary-color text-sm">Complete table management</div>
                        <div class="primary-color text-sm">User permissions & roles</div>
                        <div class="primary-color text-sm">CSV import/export</div>
                        <div class="primary-color text-sm">Interactive map visualization</div>
                        <div class="primary-color text-sm">Activity logs & audit trails</div>
                        <div class="primary-color text-sm">Column management</div>
                        <div class="primary-color text-sm">API access</div>
                        <div class="primary-color text-sm">PostgreSQL database</div>
                        <div class="primary-color text-sm">Full system isolation</div>
                        <div class="primary-color text-sm">Enterprise customization</div>
                    </div>
                    
                    <div class="mt-6">
                        <h5 class="text-sm font-medium text-gray-700 mb-2">RECOMMENDED FOR</h5>
                        <p class="text-sm text-gray-600">Enterprise clients, complete control requirements, independent scaling needs</p>
                    </div>
                </div>
            </div>

            <!-- Client Configuration Form -->
            <form id="deployForm">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Client Name *</label>
                        <input type="text" id="clientName" name="clientName" required
                               placeholder="e.g., Enterprise Corporation" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Subdomain *</label>
                        <input type="text" id="subdomain" name="subdomain" required
                               placeholder="e.g., enterprise-corp" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Admin Email *</label>
                        <input type="email" id="adminEmail" name="adminEmail" required
                               placeholder="admin@client.com" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Admin Password</label>
                        <input type="password" id="adminPassword" name="adminPassword"
                               placeholder="Leave blank for default" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeDeployModal()" 
                            class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 primary-bg text-white rounded-lg hover:bg-blue-600">
                        Deploy System
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Quick Create Modal -->
    <div id="quickCreateModal" class="modal">
        <div class="modal-content">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-semibold text-gray-900">Quick Create Base</h2>
                <button onclick="closeQuickCreateModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <p class="text-gray-600 mb-6">Create a new isolated database environment for a client.</p>
            
            <form id="quickCreateForm">
                <div class="space-y-4 mb-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Base Name</label>
                        <input type="text" id="quickClientName" name="clientName" required
                               placeholder="e.g., Acme Corp Base" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Subdomain</label>
                        <input type="text" id="quickSubdomain" name="subdomain" required
                               placeholder="e.g., acme-corp" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <p class="text-sm text-gray-500 mt-1" id="subdomainPreview">Will be accessible at: .mapz.online</p>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeQuickCreateModal()" 
                            class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 primary-bg text-white rounded-lg hover:bg-blue-600">
                        Create Base
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Load bases on page load
        document.addEventListener('DOMContentLoaded', loadBases);

        function loadBases() {
            fetch('/api/bases')
                .then(response => response.json())
                .then(bases => {
                    const tbody = document.getElementById('basesTableBody');
                    tbody.innerHTML = '';
                    
                    bases.forEach(base => {
                        const row = document.createElement('tr');
                        row.className = 'border-b border-gray-100 hover:bg-gray-50';
                        row.innerHTML = \`
                            <td class="py-3 px-4">
                                <div class="flex items-center space-x-3">
                                    <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                                        <i class="fas fa-database text-blue-600 text-xs"></i>
                                    </div>
                                    <span class="font-medium">\${base.name}</span>
                                </div>
                            </td>
                            <td class="py-3 px-4">
                                <code class="text-sm bg-gray-100 px-2 py-1 rounded">\${base.subdomain}.mapz.online</code>
                            </td>
                            <td class="py-3 px-4">\${base.userCount}</td>
                            <td class="py-3 px-4">\${base.tableCount}</td>
                            <td class="py-3 px-4">
                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">\${base.status}</span>
                            </td>
                            <td class="py-3 px-4">
                                <div class="flex space-x-2">
                                    <button onclick="window.open('http://\${base.subdomain}.mapz.online/', '_blank')" 
                                            class="text-blue-600 hover:text-blue-800 text-sm">
                                        Access Base
                                    </button>
                                    <button onclick="deleteBase(\${base.id})" 
                                            class="text-red-600 hover:text-red-800 text-sm ml-4">
                                        Delete
                                    </button>
                                </div>
                            </td>
                        \`;
                        tbody.appendChild(row);
                    });
                    
                    // Update stats
                    document.getElementById('totalBases').textContent = bases.length;
                    document.getElementById('totalUsers').textContent = bases.reduce((sum, base) => sum + base.userCount, 0);
                    document.getElementById('totalTables').textContent = bases.reduce((sum, base) => sum + base.tableCount, 0);
                })
                .catch(error => console.error('Error loading bases:', error));
        }

        function openDeployModal() {
            document.getElementById('deployModal').classList.add('show');
        }

        function closeDeployModal() {
            document.getElementById('deployModal').classList.remove('show');
            document.getElementById('deployForm').reset();
        }

        function openQuickCreateModal() {
            document.getElementById('quickCreateModal').classList.add('show');
        }

        function closeQuickCreateModal() {
            document.getElementById('quickCreateModal').classList.remove('show');
            document.getElementById('quickCreateForm').reset();
        }

        // Handle deploy form submission
        document.getElementById('deployForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            fetch('/api/create-base', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showNotification('System deployed successfully!', 'success');
                    closeDeployModal();
                    loadBases();
                } else {
                    showNotification('Error deploying system: ' + result.error, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Error deploying system', 'error');
            });
        });

        // Handle quick create form submission
        document.getElementById('quickCreateForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            data.adminEmail = 'admin@' + data.subdomain + '.com';
            
            fetch('/api/create-base', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showNotification('Base created successfully!', 'success');
                    closeQuickCreateModal();
                    loadBases();
                } else {
                    showNotification('Error creating base: ' + result.error, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Error creating base', 'error');
            });
        });

        // Update subdomain preview
        document.getElementById('quickSubdomain').addEventListener('input', function(e) {
            const preview = document.getElementById('subdomainPreview');
            preview.textContent = 'Will be accessible at: ' + (e.target.value || '[subdomain]') + '.mapz.online';
        });

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showNotification('Link copied to clipboard!', 'success');
            });
        }

        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = \`fixed top-4 right-4 px-4 py-2 rounded-lg shadow-lg z-50 \${type === 'success' ? 'bg-green-500' : 'bg-red-500'} text-white\`;
            notification.textContent = message;
            document.body.appendChild(notification);
            setTimeout(() => notification.remove(), 3000);
        }

        function deleteBase(id) {
            if (confirm('Are you sure you want to delete this base?')) {
                // Implementation for delete functionality
                showNotification('Delete functionality would be implemented here', 'success');
            }
        }

        // Close modals when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('show');
            }
        });
    </script>
</body>
</html>`;
            
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
            return;
        }
        
        // Health check endpoint
        if (pathname === '/health') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ 
                status: 'healthy', 
                timestamp: new Date().toISOString(),
                service: 'team2-complete-hybrid',
                totalBases: clientBases.length
            }));
            return;
        }
        
        // Client routing for subdomains
        if (hostname.includes('.mapz.online')) {
            const subdomain = hostname.split('.')[0];
            
            // Find client base by subdomain
            const clientBase = clientBases.find(base => base.subdomain === subdomain);
            console.log(`Subdomain: ${subdomain}, ClientBase found: ${!!clientBase}, Available bases: ${clientBases.map(b => b.subdomain).join(', ')}`);
            
            // Handle predefined clients or any client in our database
            if (subdomain === 'client1' || subdomain === 'client2' || clientBase) {
                const clientName = clientBase ? clientBase.name : (subdomain.charAt(0).toUpperCase() + subdomain.slice(1));
                const primaryColor = subdomain === 'client1' ? '#3b82f6' : subdomain === 'client2' ? '#10b981' : '#3b82f6';
                
                console.log(`Serving client workspace for: ${subdomain} (${clientName}) - Path: ${pathname}`);
                
                // Check if user is accessing root - redirect to login
                if (pathname === '/' || pathname === '') {
                    console.log(`Redirecting ${subdomain} root access to login`);
                    res.writeHead(302, { 'Location': '/login' });
                    res.end();
                    return;
                }
                
                let pageContent = generateTeam2Workspace(pathname, clientName, primaryColor, subdomain);
                
                if (pageContent) {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(pageContent);
                    return;
                } else {
                    // Fallback workspace page for any valid client
                    const fallbackPage = generateDefaultWorkspace(clientName, subdomain, primaryColor);
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(fallbackPage);
                    return;
                }
            } else {
                // Handle unknown subdomains
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.end(`<h1>Client not found</h1><p>Subdomain "${subdomain}" is not configured. Please contact your administrator.</p>`);
                return;
            }
        }
        
        // Default response
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Team2 Complete Hybrid GIS Platform Active');
        
    } catch (error) {
        console.error('Server error:', error);
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
    }
});

function createClientFolderStructure(subdomain, clientName) {
    console.log(`Creating client folder structure for ${subdomain} (${clientName})`);
    // This would create the actual folder structure on the server
    // For now, we'll just log the action
}

function generateDefaultWorkspace(clientName, subdomain, primaryColor) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${clientName} - Team2 GIS Workspace</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .primary-color { color: ${primaryColor}; }
        .primary-bg { background-color: ${primaryColor}; }
    </style>
    <script>
        // Override any inherited API calls that cause errors
        window.addEventListener('DOMContentLoaded', function() {
            // Prevent inherited API calls from super admin
            console.log('${clientName} client workspace initialized');
        });
        
        // Override fetch to prevent API errors
        const originalFetch = window.fetch;
        window.fetch = function(url, options) {
            if (url.includes('/api/bases')) {
                console.log('Blocked inherited API call:', url);
                return Promise.resolve({
                    ok: true,
                    json: () => Promise.resolve([])
                });
            }
            return originalFetch.apply(this, arguments);
        };
    </script>
</head>
<body class="bg-gray-50">
    <header class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 primary-bg rounded-lg flex items-center justify-center">
                        <i class="fas fa-map text-white text-sm"></i>
                    </div>
                    <h1 class="text-xl font-semibold text-gray-900">${clientName}</h1>
                    <span class="text-sm text-gray-500">${subdomain}.mapz.online</span>
                </div>
                <div class="primary-bg text-white px-3 py-1 rounded-full text-sm font-medium">
                    Master Admin
                </div>
            </div>
        </div>
    </header>

    <div class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-6">
            <nav class="flex space-x-8">
                <a href="#" class="primary-color border-b-2 border-current py-4 px-1 text-sm font-medium">
                    <i class="fas fa-th mr-2"></i>Grid
                </a>
                <a href="#" class="text-gray-500 hover:text-gray-700 py-4 px-1 text-sm font-medium">
                    <i class="fas fa-th-large mr-2"></i>Gallery
                </a>
                <a href="#" class="text-gray-500 hover:text-gray-700 py-4 px-1 text-sm font-medium">
                    <i class="fas fa-calendar mr-2"></i>Calendar
                </a>
                <a href="#" class="text-gray-500 hover:text-gray-700 py-4 px-1 text-sm font-medium">
                    <i class="fas fa-columns mr-2"></i>Kanban
                </a>
                <a href="#" class="text-gray-500 hover:text-gray-700 py-4 px-1 text-sm font-medium">
                    <i class="fas fa-chart-bar mr-2"></i>Chart
                </a>
                <a href="./map" class="text-gray-500 hover:text-gray-700 py-4 px-1 text-sm font-medium">
                    <i class="fas fa-map mr-2"></i>Map
                </a>
            </nav>
        </div>
    </div>

    <div class="flex">
        <div class="w-64 bg-white border-r border-gray-200 min-h-screen">
            <div class="p-4">
                <div class="space-y-2">
                    <div class="flex items-center space-x-2 text-sm font-medium text-gray-900 mb-4">
                        <i class="fas fa-table"></i>
                        <span>Tables</span>
                    </div>
                    
                    <div class="space-y-1">
                        <a href="./map" class="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Map View</span>
                        </a>
                        <a href="./user-management" class="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                            <i class="fas fa-users"></i>
                            <span>User Management</span>
                        </a>
                        <a href="#" class="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                            <i class="fas fa-key"></i>
                            <span>API Tokens</span>
                        </a>
                        <a href="#" class="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                            <i class="fas fa-history"></i>
                            <span>Activity Logs</span>
                        </a>
                        <a href="#" class="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                            <i class="fas fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex-1 p-6">
            <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-check-circle text-green-600"></i>
                    <span class="text-green-800 font-medium">Login Successful</span>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">${clientName} Data Management</h3>
                <div class="text-center py-8">
                    <i class="fas fa-table text-gray-400 text-4xl mb-4"></i>
                    <p class="text-gray-500">Welcome to ${clientName} workspace!</p>
                    <p class="text-gray-500 mb-4">Client folder structure: /opt/team2-hybrid/clients/${subdomain}/</p>
                    <button onclick="openCsvModal()" class="mt-4 primary-bg text-white px-4 py-2 rounded-lg hover:opacity-90">
                        <i class="fas fa-upload mr-2"></i>
                        Import CSV Data
                    </button>
                </div>
                
                <!-- CSV Upload Modal -->
                <div id="csvModal" class="modal">
                    <div class="modal-content">
                        <span onclick="closeCsvModal()" class="close">&times;</span>
                        <h2 class="text-xl font-bold mb-4">Import CSV Data</h2>
                        <form id="csvForm" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="block text-sm font-medium mb-2">CSV File</label>
                                <input type="file" id="csvFile" accept=".csv" class="w-full p-2 border border-gray-300 rounded" required>
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-medium mb-2">Table Name</label>
                                <input type="text" id="tableName" class="w-full p-2 border border-gray-300 rounded" placeholder="Enter table name" required>
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-medium mb-2">Display Name</label>
                                <input type="text" id="displayName" class="w-full p-2 border border-gray-300 rounded" placeholder="Enter display name" required>
                            </div>
                            <div class="flex space-x-2">
                                <button type="submit" class="primary-bg text-white px-4 py-2 rounded hover:opacity-90">Upload</button>
                                <button type="button" onclick="closeCsvModal()" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Add Record Modal -->
                <div id="addRecordModal" class="modal">
                    <div class="modal-content">
                        <span onclick="closeAddRecordModal()" class="close">&times;</span>
                        <h2 class="text-xl font-bold mb-4">Add New Record</h2>
                        <form id="addRecordForm">
                            <div class="mb-4">
                                <label class="block text-sm font-medium mb-2">Name</label>
                                <input type="text" id="recordName" class="w-full p-2 border border-gray-300 rounded" placeholder="Enter name" required>
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-medium mb-2">Description</label>
                                <textarea id="recordDescription" class="w-full p-2 border border-gray-300 rounded" placeholder="Enter description" rows="3"></textarea>
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-medium mb-2">Location (Optional)</label>
                                <input type="text" id="recordLocation" class="w-full p-2 border border-gray-300 rounded" placeholder="Latitude, Longitude">
                            </div>
                            <div class="flex space-x-2">
                                <button type="submit" class="primary-bg text-white px-4 py-2 rounded hover:opacity-90">Add Record</button>
                                <button type="button" onclick="closeAddRecordModal()" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Column Management Modal -->
                <div id="columnModal" class="modal">
                    <div class="modal-content">
                        <span onclick="closeColumnModal()" class="close">&times;</span>
                        <h2 class="text-xl font-bold mb-4">Manage Columns</h2>
                        <div class="mb-4">
                            <h3 class="font-medium mb-2">Add New Column</h3>
                            <form id="columnForm">
                                <div class="grid grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <label class="block text-sm font-medium mb-2">Column Name</label>
                                        <input type="text" id="columnName" class="w-full p-2 border border-gray-300 rounded" placeholder="Enter column name" required>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-2">Column Type</label>
                                        <select id="columnType" class="w-full p-2 border border-gray-300 rounded" required>
                                            <option value="text">Text</option>
                                            <option value="number">Number</option>
                                            <option value="date">Date</option>
                                            <option value="boolean">Boolean</option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit" class="primary-bg text-white px-4 py-2 rounded hover:opacity-90">Add Column</button>
                            </form>
                        </div>
                        <div>
                            <h3 class="font-medium mb-2">Existing Columns</h3>
                            <div id="columnList" class="space-y-2">
                                <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                    <span>ID (number)</span>
                                    <button class="text-red-600 hover:text-red-800">Delete</button>
                                </div>
                                <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                    <span>Name (text)</span>
                                    <button class="text-red-600 hover:text-red-800">Delete</button>
                                </div>
                                <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                    <span>Created At (date)</span>
                                    <button class="text-red-600 hover:text-red-800">Delete</button>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4">
                            <button onclick="closeColumnModal()" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`;
}

function generateTeam2Workspace(pathname, clientName, primaryColor, subdomain) {
    
    if (pathname === '/login') {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${clientName} - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .primary-color { color: ${primaryColor}; }
        .primary-bg { background-color: ${primaryColor}; }
        .primary-bg:hover { background-color: ${primaryColor}dd; }
        .modal { 
            display: none; 
            position: fixed; 
            z-index: 1000; 
            left: 0; 
            top: 0; 
            width: 100%; 
            height: 100%; 
            background-color: rgba(0,0,0,0.5); 
        }
        .modal-content { 
            background-color: white; 
            margin: 5% auto; 
            padding: 20px; 
            border-radius: 8px; 
            width: 90%; 
            max-width: 600px; 
            max-height: 80vh;
            overflow-y: auto;
        }
        .close { 
            color: #aaa; 
            float: right; 
            font-size: 28px; 
            font-weight: bold; 
            cursor: pointer;
        }
        .close:hover { color: #000; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full space-y-8">
        <div>
            <div class="mx-auto h-12 w-12 primary-bg rounded-lg flex items-center justify-center">
                <i class="fas fa-map text-white text-xl"></i>
            </div>
            <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                Sign in to ${clientName}
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">
                Access your GIS workspace at ${subdomain}.mapz.online
            </p>
        </div>
        <form class="mt-8 space-y-6" onsubmit="handleLogin(event)">
            <div class="rounded-md shadow-sm -space-y-px">
                <div>
                    <label for="email-address" class="sr-only">Email address</label>
                    <input id="email-address" name="email" type="email" autocomplete="email" required 
                           class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm" 
                           placeholder="Email address">
                </div>
                <div>
                    <label for="password" class="sr-only">Password</label>
                    <input id="password" name="password" type="password" autocomplete="current-password" required 
                           class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm" 
                           placeholder="Password">
                </div>
            </div>

            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <input id="remember-me" name="remember-me" type="checkbox" 
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label for="remember-me" class="ml-2 block text-sm text-gray-900">
                        Remember me
                    </label>
                </div>
                <div class="text-sm">
                    <a href="#" class="font-medium primary-color hover:opacity-80">
                        Forgot your password?
                    </a>
                </div>
            </div>

            <div>
                <button type="submit" 
                        class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white primary-bg hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                        <i class="fas fa-lock text-white opacity-60"></i>
                    </span>
                    Sign in
                </button>
            </div>
            
            <div class="text-center">
                <p class="text-sm text-gray-600">
                    Client folder: /opt/team2-hybrid/clients/${subdomain}/
                </p>
            </div>
        </form>
    </div>

    <script>
        function handleLogin(event) {
            event.preventDefault();
            
            const email = document.getElementById('email-address').value;
            const password = document.getElementById('password').value;
            
            // Simple validation for demo
            if (email && password) {
                // Show success message
                const button = event.target.querySelector('button[type="submit"]');
                button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Signing in...';
                button.disabled = true;
                
                // Simulate login process
                setTimeout(() => {
                    window.location.href = '/dashboard';
                }, 1500);
            } else {
                alert('Please enter both email and password');
            }
        }
    </script>
</body>
</html>`;
    }
    
    if (pathname === '/' || pathname === '/dashboard' || pathname === '/workspace') {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${clientName} - Team2 GIS Workspace</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .workspace-container {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        
        .sidebar {
            width: 300px;
            background: white;
            border-right: 1px solid #e5e7eb;
            overflow-y: auto;
            flex-shrink: 0;
        }
        
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .csv-upload-area {
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            margin: 12px 0;
            transition: border-color 0.2s;
            cursor: pointer;
        }
        
        .csv-upload-area:hover {
            border-color: ${primaryColor};
            background-color: #f9fafb;
        }
        
        .csv-upload-area.dragover {
            border-color: ${primaryColor};
            background-color: #eff6ff;
        }
        
        .modal { 
            display: none; 
            position: fixed; 
            z-index: 1000; 
            left: 0; 
            top: 0; 
            width: 100%; 
            height: 100%; 
            background-color: rgba(0,0,0,0.5); 
        }
        .modal-content { 
            background-color: white; 
            margin: 5% auto; 
            padding: 20px; 
            border-radius: 8px; 
            width: 90%; 
            max-width: 600px; 
            max-height: 80vh;
            overflow-y: auto;
        }
        .close { 
            color: #aaa; 
            float: right; 
            font-size: 28px; 
            font-weight: bold; 
            cursor: pointer;
        }
        .close:hover { color: #000; }
        
        .primary-color { color: ${primaryColor}; }
        .primary-bg { background-color: ${primaryColor}; }
    </style>
</head>
<body class="bg-gray-50">
    <header class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 primary-bg rounded-lg flex items-center justify-center">
                        <i class="fas fa-map text-white text-sm"></i>
                    </div>
                    <h1 class="text-xl font-semibold text-gray-900">${subdomain}</h1>
                    <span class="text-sm text-gray-500">${subdomain}.mapz.online</span>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-500">Tables</span>
                    <span class="text-sm text-gray-500">Loading...</span>
                    <div class="primary-bg text-white px-3 py-1 rounded-full text-sm font-medium">
                        Master Admin
                    </div>
                    <button onclick="openColumnModal()" class="bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm">
                        <i class="fas fa-columns mr-1"></i>
                        Manage Columns
                    </button>
                    <button onclick="openAddRecordModal()" class="primary-bg text-white px-3 py-1 rounded text-sm">
                        <i class="fas fa-plus mr-1"></i>
                        Add Record
                    </button>
                </div>
            </div>
        </div>
    </header>

    <div class="workspace-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="p-4 border-b bg-gray-50">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 primary-bg rounded-lg flex items-center justify-center">
                        <i class="fas fa-map text-white text-sm"></i>
                    </div>
                    <div>
                        <h1 class="font-semibold text-gray-900">${clientName}</h1>
                        <p class="text-xs text-gray-500">${subdomain}.mapz.online</p>
                    </div>
                </div>
            </div>
            
            <!-- CSV Upload Area -->
            <div class="p-4">
                <div class="csv-upload-area" onclick="openCsvModal()">
                    <div class="text-center">
                        <i class="fas fa-upload text-3xl text-gray-400 mb-2"></i>
                        <p class="text-sm font-medium text-gray-600">Import CSV Data</p>
                        <p class="text-xs text-gray-500">Click to upload your CSV file</p>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="mt-4 space-y-2">
                    <button onclick="openUserManagement()" class="w-full flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                        <i class="fas fa-users text-blue-500"></i>
                        <span>User Management</span>
                    </button>
                    <button onclick="openColumnManager()" class="w-full flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                        <i class="fas fa-columns text-purple-500"></i>
                        <span>Manage Columns</span>
                    </button>
                    <button onclick="addNewRecord()" class="w-full flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                        <i class="fas fa-plus text-green-500"></i>
                        <span>Add Record</span>
                    </button>
                    <a href="./map" class="w-full flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded">
                        <i class="fas fa-map text-red-500"></i>
                        <span>Map View</span>
                    </a>
                </div>
                
                <!-- Tables List -->
                <div class="mt-6">
                    <h3 class="text-sm font-medium text-gray-900 mb-2">Tables</h3>
                    <div id="tablesList" class="space-y-1">
                        <div class="text-sm text-gray-500 px-3 py-2">No tables yet. Import CSV to create your first table.</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="p-6">
                <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                    <div class="flex items-center space-x-2">
                        <i class="fas fa-check-circle text-green-600"></i>
                        <span class="text-green-800 font-medium">Login Successful - Welcome to ${clientName}</span>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">${clientName} Data Management</h3>
                    <div class="text-center py-8">
                        <i class="fas fa-table text-gray-400 text-4xl mb-4"></i>
                        <p class="text-gray-500">Client workspace ready for ${subdomain}.mapz.online</p>
                        <p class="text-gray-500 mb-4">Import your first CSV file to get started with spatial data management.</p>
                        <button onclick="openCsvModal()" class="mt-4 primary-bg text-white px-4 py-2 rounded-lg hover:opacity-90">
                            <i class="fas fa-upload mr-2"></i>
                            Import CSV Data
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- CSV Upload Modal -->
    <div id="csvModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeCsvModal()">&times;</span>
            <h2 class="text-xl font-bold mb-4">Import CSV Data</h2>
            <form id="csvForm">
                <div class="mb-4">
                    <label for="csvFileInput" class="block text-sm font-medium text-gray-700 mb-2">Select CSV File</label>
                    <input type="file" id="csvFileInput" accept=".csv" class="w-full p-2 border border-gray-300 rounded" required>
                </div>
                <div class="mb-4">
                    <label for="tableName" class="block text-sm font-medium text-gray-700 mb-2">Table Name</label>
                    <input type="text" id="tableName" class="w-full p-2 border border-gray-300 rounded" placeholder="Enter table name" required>
                </div>
                <div class="flex justify-end space-x-2">
                    <button type="button" onclick="closeCsvModal()" class="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50">Cancel</button>
                    <button type="submit" class="px-4 py-2 primary-bg text-white rounded hover:opacity-90">Upload CSV</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- User Management Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeUserModal()">&times;</span>
            <h2 class="text-xl font-bold mb-4">User Management</h2>
            <div class="space-y-4">
                <div class="bg-blue-50 p-4 rounded">
                    <p class="text-blue-800">User management functionality for ${clientName}</p>
                    <p class="text-blue-600 text-sm">Add, edit, and manage user permissions for this workspace.</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Column Manager Modal -->
    <div id="columnModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeColumnModal()">&times;</span>
            <h2 class="text-xl font-bold mb-4">Column Manager</h2>
            <div class="space-y-4">
                <div class="bg-purple-50 p-4 rounded">
                    <p class="text-purple-800">Column management for ${clientName}</p>
                    <p class="text-purple-600 text-sm">Manage table columns, data types, and field properties.</p>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Modal functionality
        function openCsvModal() {
            document.getElementById('csvModal').style.display = 'block';
        }
        
        function closeCsvModal() {
            document.getElementById('csvModal').style.display = 'none';
            document.getElementById('csvForm').reset();
        }
        
        function openUserManagement() {
            document.getElementById('userModal').style.display = 'block';
        }
        
        function closeUserModal() {
            document.getElementById('userModal').style.display = 'none';
        }
        
        function openColumnManager() {
            document.getElementById('columnModal').style.display = 'block';
        }
        
        function closeColumnModal() {
            document.getElementById('columnModal').style.display = 'none';
        }
        
        function addNewRecord() {
            alert('Add New Record functionality - Coming soon for ${clientName}');
        }
        
        // Initialize CSV form when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            const csvForm = document.getElementById('csvForm');
            if (csvForm) {
                csvForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const fileInput = document.getElementById('csvFileInput');
                    const tableNameInput = document.getElementById('tableName');
                    const file = fileInput.files[0];
                    const tableName = tableNameInput.value.trim();
                    
                    if (!file) {
                        alert('Please select a CSV file');
                        return;
                    }
                    
                    if (!tableName) {
                        alert('Please enter a table name');
                        return;
                    }
                    
                    const submitBtn = e.target.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Uploading...';
                    submitBtn.disabled = true;
                    
                    // Simulate CSV processing with FormData
                    const formData = new FormData();
                    formData.append('csvFile', file);
                    formData.append('tableName', tableName);
                    
                    // Simulate upload process
                    setTimeout(() => {
                        const recordCount = Math.floor(Math.random() * 100 + 50);
                        showNotification('CSV file "' + file.name + '" uploaded successfully! Table "' + tableName + '" created with ' + recordCount + ' records.', 'success');
                        
                        // Update tables list
                        updateTablesList(tableName, recordCount);
                        
                        closeCsvModal();
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    }, 2000);
                });
            }
        });
        
        // Utility functions
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = 'fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg ' + 
                (type === 'success' ? 'bg-green-100 border border-green-200 text-green-800' : 'bg-red-100 border border-red-200 text-red-800');
            notification.innerHTML = '<i class="fas fa-' + (type === 'success' ? 'check-circle' : 'exclamation-circle') + ' mr-2"></i>' + message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 5000);
        }
        
        function updateTablesList(tableName, recordCount) {
            const tablesList = document.getElementById('tablesList');
            if (tablesList) {
                // Remove "no tables" message if exists
                const noTablesMsg = tablesList.querySelector('.text-gray-500');
                if (noTablesMsg && noTablesMsg.textContent.includes('No tables yet')) {
                    noTablesMsg.remove();
                }
                
                // Add new table
                const tableItem = document.createElement('div');
                tableItem.className = 'flex items-center justify-between px-3 py-2 text-sm bg-gray-50 rounded hover:bg-gray-100 cursor-pointer';
                tableItem.innerHTML = \`
                    <div class="flex items-center space-x-2">
                        <i class="fas fa-table text-blue-500"></i>
                        <span>\${tableName}</span>
                    </div>
                    <span class="text-xs text-gray-500">\${recordCount} rows</span>
                \`;
                tablesList.appendChild(tableItem);
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const csvModal = document.getElementById('csvModal');
            const userModal = document.getElementById('userModal');
            const columnModal = document.getElementById('columnModal');
            
            if (event.target === csvModal) {
                closeCsvModal();
            }
            if (event.target === userModal) {
                closeUserModal();
            }
            if (event.target === columnModal) {
                closeColumnModal();
            }
        }
        }
        
        function addColumnToList(name, type) {
            const columnList = document.getElementById('columnList');
            const columnDiv = document.createElement('div');
            columnDiv.className = 'flex items-center justify-between p-2 bg-gray-50 rounded';
            columnDiv.innerHTML = \`
                <span>\${name} (\${type})</span>
                <button onclick="this.parentElement.remove(); showNotification('Column deleted', 'success');" class="text-red-600 hover:text-red-800">Delete</button>
            \`;
            columnList.appendChild(columnDiv);
        }
        
        // Close modals when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
        
        // Initialize workspace
        document.addEventListener('DOMContentLoaded', function() {
            console.log('${clientName} workspace loaded');
        });
    </script>
</body>
</html>`;
    }
    
    if (pathname === '/map') {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${clientName} - Interactive Map</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .primary-color { color: ${primaryColor}; }
        .primary-bg { background-color: ${primaryColor}; }
        #map { height: calc(100vh - 120px); }
    </style>
</head>
<body class="bg-gray-50">
    <header class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 primary-bg rounded-lg flex items-center justify-center">
                        <i class="fas fa-map text-white text-sm"></i>
                    </div>
                    <h1 class="text-xl font-semibold text-gray-900">${subdomain}</h1>
                    <span class="text-sm text-gray-500">${subdomain}.mapz.online</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="./" class="text-gray-500 hover:text-gray-700 text-sm">
                        <i class="fas fa-th mr-1"></i>Grid
                    </a>
                    <span class="primary-color text-sm font-medium">
                        <i class="fas fa-map mr-1"></i>Map
                    </span>
                    <div class="primary-bg text-white px-3 py-1 rounded-full text-sm font-medium">
                        Master Admin
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="relative">
        <div id="map" class="w-full"></div>
        
        <div class="absolute top-4 left-4 bg-white rounded-lg shadow-lg p-3 space-y-2 z-1000">
            <button onclick="centerMap()" class="block w-full primary-bg text-white px-3 py-2 rounded text-sm hover:opacity-90">
                <i class="fas fa-crosshairs mr-1"></i>
                Center Map
            </button>
            <button onclick="toggleFullscreen()" class="block w-full bg-gray-600 text-white px-3 py-2 rounded text-sm hover:bg-gray-700">
                <i class="fas fa-expand mr-1"></i>
                Fullscreen
            </button>
            <button class="block w-full bg-green-600 text-white px-3 py-2 rounded text-sm hover:bg-green-700">
                <i class="fas fa-layer-group mr-1"></i>
                Layers
            </button>
        </div>
        
        <div class="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-4 max-w-sm z-1000">
            <h4 class="font-semibold text-gray-900 mb-2">${clientName} Map View</h4>
            <p class="text-sm text-gray-600">Custom client folder: /opt/team2-hybrid/clients/${subdomain}/</p>
            <div class="mt-3 flex space-x-2">
                <button class="primary-bg text-white px-3 py-1 rounded text-sm">
                    <i class="fas fa-upload mr-1"></i>
                    Import Data
                </button>
                <button class="border border-gray-300 text-gray-700 px-3 py-1 rounded text-sm">
                    <i class="fas fa-download mr-1"></i>
                    Export
                </button>
            </div>
        </div>
    </div>

    <script>
        const map = L.map('map').setView([40.7128, -74.0060], 10);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors | ${clientName} GIS Platform'
        }).addTo(map);
        
        const marker = L.marker([40.7128, -74.0060])
            .addTo(map)
            .bindPopup(\`
                <div style="color: ${primaryColor};">
                    <strong>${clientName} Location</strong><br>
                    <small>Client folder: /clients/${subdomain}/</small>
                </div>
            \`)
            .openPopup();
        
        function centerMap() {
            map.setView([40.7128, -74.0060], 10);
        }
        
        function toggleFullscreen() {
            const mapElement = document.getElementById('map');
            if (mapElement.style.height === '100vh') {
                mapElement.style.height = 'calc(100vh - 120px)';
            } else {
                mapElement.style.height = '100vh';
            }
            setTimeout(() => map.invalidateSize(), 100);
        }
    </script>
</body>
</html>`;
    }
    
    return null;
}

server.listen(PORT, HOST, () => {
    console.log(`Team2 Complete Hybrid GIS Platform running on ${HOST}:${PORT}`);
    console.log(`Super Admin: http://localhost:${PORT}/super-admin`);
    console.log(`Client management with folder structure at /opt/team2-hybrid/clients/`);
});

server.on('error', (err) => {
    console.error('Server startup error:', err);
    process.exit(1);
});

process.on('SIGINT', () => {
    console.log('Shutting down gracefully...');
    server.close(() => process.exit(0));
});

process.on('SIGTERM', () => {
    console.log('Shutting down gracefully...');
    server.close(() => process.exit(0));
});