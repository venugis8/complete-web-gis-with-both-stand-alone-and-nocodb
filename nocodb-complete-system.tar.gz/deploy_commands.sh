#!/bin/bash
echo "Deploying Team 2 Standalone GIS Fix..."

# Stop current process
pm2 stop team2-standalone-gis 2>/dev/null || true
pm2 delete team2-standalone-gis 2>/dev/null || true

# Copy files to deployment directory
cp production_server.js /opt/team2-gis/
cp ecosystem.config.js /opt/team2-gis/

# Start with PM2
cd /opt/team2-gis
pm2 start ecosystem.config.js
pm2 save

# Restart Nginx
systemctl restart nginx

# Verify deployment
echo "Checking application status..."
pm2 status
echo "Checking port binding..."
netstat -tlnp | grep :5000
echo "Testing local connection..."
curl -I http://localhost:5000
echo "Testing external access..."
curl -I http://localhost

echo "Deployment complete. Application should be accessible at http://172.232.108.139"
