#!/bin/bash

# Fix Team 2 Standalone GIS Deployment Script
echo "=== Fixing Team 2 Standalone GIS Deployment ==="

# Variables
SERVER_IP="172.232.108.139"
SERVER_USER="root"
SERVER_PASS="Geo@asset12!"
APP_DIR="/opt/team2-gis"

# Function to execute remote commands
remote_exec() {
    sshpass -p "$SERVER_PASS" ssh -o StrictHostKeyChecking=no "$SERVER_USER@$SERVER_IP" "$1"
}

# Function to copy files to remote server
remote_copy() {
    sshpass -p "$SERVER_PASS" scp -o StrictHostKeyChecking=no "$1" "$SERVER_USER@$SERVER_IP:$2"
}

echo "1. Checking current server status..."
remote_exec "pm2 status"

echo "2. Stopping current application..."
remote_exec "pm2 stop team2-standalone-gis || true"
remote_exec "pm2 delete team2-standalone-gis || true"

echo "3. Checking application binding..."
remote_exec "netstat -tlnp | grep :5000"

echo "4. Creating production server configuration..."
cat > production_server.js << 'EOF'
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';

// Serve static files
app.use(express.static(path.join(__dirname, 'dist')));

// API routes (if any)
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve the React app for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, HOST, () => {
    console.log(`Server running on http://${HOST}:${PORT}`);
});
EOF

echo "5. Copying production server to remote..."
remote_copy "production_server.js" "$APP_DIR/"

echo "6. Starting application with correct host binding..."
remote_exec "cd $APP_DIR && HOST=0.0.0.0 PORT=5000 pm2 start production_server.js --name 'team2-standalone-gis'"

echo "7. Saving PM2 configuration..."
remote_exec "pm2 save"

echo "8. Checking application status..."
remote_exec "pm2 status"

echo "9. Testing local connection..."
remote_exec "curl -I http://localhost:5000"

echo "10. Checking what's listening on port 5000..."
remote_exec "netstat -tlnp | grep :5000"

echo "11. Restarting Nginx..."
remote_exec "systemctl restart nginx"

echo "12. Testing Nginx proxy..."
remote_exec "curl -I http://localhost"

echo "13. Checking Nginx error logs..."
remote_exec "tail -10 /var/log/nginx/error.log"

echo "=== Deployment Fix Complete ==="
echo "Application should now be accessible at http://$SERVER_IP"