const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

function getClient(hostname, query) {
  if (hostname === 'mapz.online' || hostname === 'www.mapz.online') {
    return { client: 'super-admin', isSuperAdmin: true };
  }
  
  if (hostname.endsWith('.mapz.online')) {
    const subdomain = hostname.split('.')[0];
    return { client: subdomain, isSuperAdmin: false };
  }
  
  return { client: query.client || 'demo', isSuperAdmin: false };
}

app.use((req, res, next) => {
  const { client, isSuperAdmin } = getClient(req.hostname, req.query);
  req.client = client;
  req.isSuperAdmin = isSuperAdmin;
  next();
});

// Handle superadmin path routing - FIXED
app.get('/superadmin', (req, res) => {
  if (!req.isSuperAdmin) {
    return res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head><title>Access Denied</title></head>
      <body>
        <h1>Access Denied</h1>
        <p>Super admin access only available from mapz.online</p>
        <p>Current domain: ${req.hostname}</p>
      </body>
      </html>
    `);
  }
  res.redirect('/');
});

app.get('/superadmin/*', (req, res) => {
  if (!req.isSuperAdmin) {
    return res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head><title>Access Denied</title></head>
      <body>
        <h1>Access Denied</h1>
        <p>Super admin access only available from mapz.online</p>
      </body>
      </html>
    `);
  }
  res.redirect('/');
});

// Super Admin API routes
app.get('/api/super-admin/bases', (req, res) => {
  if (!req.isSuperAdmin) {
    return res.status(403).json({ error: 'Access denied. Super admin only.' });
  }
  
  const bases = [
    { id: 1, name: 'Acme Corp Base', subdomain: 'acme-corp', status: 'active', userCount: 2, tableCount: 0 },
    { id: 2, name: 'TechStart Inc', subdomain: 'techstart', status: 'active', userCount: 0, tableCount: 0 },
    { id: 4, name: 'SSC6', subdomain: 'ssc6', status: 'active', userCount: 1, tableCount: 0 },
    { id: 5, name: 'Demo Base', subdomain: 'demo', status: 'active', userCount: 1, tableCount: 0 }
  ];
  
  res.json(bases);
});

// Client-specific API routes
app.get('/api/tables', (req, res) => {
  if (req.isSuperAdmin) {
    return res.status(403).json({ error: 'Use client-specific subdomain' });
  }
  
  const clientTables = {
    'acme-corp': [{ id: 1, name: 'acme_corp_sites', displayName: 'Sites', type: 'spatial' }],
    'ssc6': [{ id: 2, name: 'ssc6_sites', displayName: 'Sites', type: 'spatial' }],
    'demo': [{ id: 3, name: 'demo_sites', displayName: 'Sites', type: 'spatial' }],
    'techstart': [{ id: 4, name: 'techstart_sites', displayName: 'Sites', type: 'spatial' }]
  };
  
  res.json(clientTables[req.client] || []);
});

app.get('/api/tables/:tableId/data', (req, res) => {
  if (req.isSuperAdmin) {
    return res.status(403).json({ error: 'Use client-specific subdomain' });
  }
  
  const sampleData = {
    'acme-corp': [
      { id: 1, name: 'Acme HQ', description: 'Main headquarters', wkt_geometry: 'POINT(-122.4194 37.7749)' },
      { id: 2, name: 'Acme Factory', description: 'Manufacturing facility', wkt_geometry: 'POLYGON((-122.5 37.8, -122.4 37.8, -122.4 37.7, -122.5 37.7, -122.5 37.8))' }
    ],
    'ssc6': [
      { id: 1, name: 'SSC6 Office', description: 'Regional office', wkt_geometry: 'POINT(-118.2437 34.0522)' },
      { id: 2, name: 'SSC6 Warehouse', description: 'Storage facility', wkt_geometry: 'POLYGON((-118.3 34.1, -118.2 34.1, -118.2 34.0, -118.3 34.0, -118.3 34.1))' }
    ],
    'demo': [
      { id: 1, name: 'Demo Point', description: 'Sample point location', wkt_geometry: 'POINT(-74.006 40.7128)' },
      { id: 2, name: 'Demo Area', description: 'Sample polygon area', wkt_geometry: 'POLYGON((-74.1 40.8, -74.0 40.8, -74.0 40.7, -74.1 40.7, -74.1 40.8))' }
    ],
    'techstart': [
      { id: 1, name: 'TechStart HQ', description: 'Headquarters', wkt_geometry: 'POINT(-73.935242 40.730610)' }
    ]
  };
  
  res.json(sampleData[req.client] || []);
});

// Main page routing
app.get('/', (req, res) => {
  if (req.isSuperAdmin) {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
          <title>Super Admin Dashboard - MapZ Platform</title>
          <style>
              body { font-family: Arial, sans-serif; margin: 0; padding: 2rem; background: #f5f5f5; }
              .container { max-width: 1200px; margin: 0 auto; background: white; padding: 2rem; border-radius: 8px; }
              .header { border-bottom: 2px solid #3b82f6; padding-bottom: 1rem; margin-bottom: 2rem; }
              .bases-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }
              .base-card { border: 1px solid #e5e7eb; padding: 1rem; border-radius: 6px; }
              .base-card h3 { color: #1f2937; margin: 0 0 0.5rem 0; }
              .base-url { color: #3b82f6; font-size: 0.9rem; }
              .nav { margin: 1rem 0; }
              .nav a { background: #3b82f6; color: white; padding: 0.5rem 1rem; text-decoration: none; border-radius: 4px; margin-right: 1rem; }
          </style>
      </head>
      <body>
          <div class="container">
              <div class="header">
                  <h1>Super Admin Dashboard</h1>
                  <p>Manage all client bases and monitor system status</p>
                  <div class="nav">
                      <a href="/superadmin">Admin Panel</a>
                      <a href="/api/super-admin/bases">View Bases API</a>
                  </div>
              </div>
              <div id="bases-list">Loading client bases...</div>
          </div>
          <script>
              fetch('/api/super-admin/bases')
                  .then(r => r.json())
                  .then(bases => {
                      const html = '<div class="bases-grid">' + 
                          bases.map(base => 
                              '<div class="base-card">' +
                                  '<h3>' + base.name + '</h3>' +
                                  '<div class="base-url"><a href="http://' + base.subdomain + '.mapz.online" target="_blank">' + base.subdomain + '.mapz.online</a></div>' +
                                  '<p>Users: ' + base.userCount + ' | Tables: ' + base.tableCount + '</p>' +
                                  '<p>Status: ' + base.status + '</p>' +
                              '</div>'
                          ).join('') + '</div>';
                      document.getElementById('bases-list').innerHTML = html;
                  })
                  .catch(() => {
                      document.getElementById('bases-list').innerHTML = 'Error loading bases';
                  });
          </script>
      </body>
      </html>
    `);
  } else {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
          <title>${req.client.toUpperCase()} Dashboard - GIS Platform</title>
          <style>
              body { font-family: Arial, sans-serif; margin: 0; background: #f8fafc; }
              .header { background: #1e293b; color: white; padding: 1rem 2rem; }
              .nav { display: flex; gap: 2rem; margin-top: 1rem; }
              .nav a { color: #94a3b8; text-decoration: none; padding: 0.5rem 1rem; border-radius: 4px; }
              .nav a:hover { background: #374151; color: white; }
              .content { padding: 2rem; max-width: 1200px; margin: 0 auto; }
              .widget { background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; margin: 1rem 0; }
              .widget h3 { margin-top: 0; color: #1f2937; }
              .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
              .stat-card { background: #f8fafc; padding: 1rem; border-radius: 6px; text-align: center; }
              .stat-value { font-size: 2rem; font-weight: bold; color: #3b82f6; }
              .stat-label { color: #64748b; font-size: 0.9rem; }
          </style>
      </head>
      <body>
          <div class="header">
              <h1>${req.client.toUpperCase()} GIS Platform</h1>
              <div class="nav">
                  <a href="/dashboard">Dashboard</a>
                  <a href="/workspace">Workspace</a>
                  <a href="/map">Map View</a>
              </div>
          </div>
          <div class="content">
              <div class="widget">
                  <h3>Site Statistics</h3>
                  <div class="stats">
                      <div class="stat-card">
                          <div class="stat-value" id="site-count">0</div>
                          <div class="stat-label">Total Sites</div>
                      </div>
                      <div class="stat-card">
                          <div class="stat-value">WKT</div>
                          <div class="stat-label">Geometry Support</div>
                      </div>
                  </div>
              </div>
              <div class="widget">
                  <h3>Client Structure</h3>
                  <ul>
                      <li>Individual pages: /clients/${req.client}/pages/</li>
                      <li>WKT geometry: POINT, POLYGON, LINESTRING</li>
                      <li>CSV upload with spatial processing</li>
                      <li>Client-isolated database tables</li>
                      <li>Blocked from super admin functions</li>
                  </ul>
              </div>
          </div>
          <script>
              fetch('/api/tables/1/data')
                  .then(r => r.json())
                  .then(data => {
                      document.getElementById('site-count').textContent = data.length;
                  })
                  .catch(() => {
                      document.getElementById('site-count').textContent = '0';
                  });
          </script>
      </body>
      </html>
    `);
  }
});

app.get('/dashboard', (req, res) => res.redirect('/'));

app.get('/workspace', (req, res) => {
  if (req.isSuperAdmin) return res.redirect('/');
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>${req.client.toUpperCase()} Workspace</title></head>
    <body>
      <h1>${req.client.toUpperCase()} Workspace</h1>
      <p>Individual workspace page for ${req.client}</p>
      <p>Page structure: /clients/${req.client}/pages/workspace/</p>
      <a href="/">Back to Dashboard</a>
    </body>
    </html>
  `);
});

app.get('/map', (req, res) => {
  if (req.isSuperAdmin) return res.redirect('/');
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>${req.client.toUpperCase()} Map View</title></head>
    <body>
      <h1>${req.client.toUpperCase()} Map View</h1>
      <p>Individual map page for ${req.client} with WKT geometry support</p>
      <p>Page structure: /clients/${req.client}/pages/map/</p>
      <a href="/">Back to Dashboard</a>
    </body>
    </html>
  `);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Team2 Hybrid Server running on port ${PORT}`);
  console.log('Super Admin: mapz.online (access to /api/super-admin/* and /superadmin)');
  console.log('Clients: *.mapz.online (blocked from super admin, individual pages)');
});