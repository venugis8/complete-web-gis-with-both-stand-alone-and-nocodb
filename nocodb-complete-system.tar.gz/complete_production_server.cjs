const express = require('express');
const path = require('path');
const { Pool } = require('pg');
const fs = require('fs');
// const bcrypt = require('bcrypt'); // Removed for testing - add back for production

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://gisuser:gispassword123@localhost:5432/gisdb'
});

// Middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'dist/public'), {
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
}));

// Super Admin Authentication Routes
app.post('/api/super-admin/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Simple super admin authentication - replace with proper system
    if (email === 'ssc6@ppmail.com' && password === 'mypassword123') {
      res.json({ 
        success: true, 
        user: { id: 1, email: 'ssc6@ppmail.com', role: 'super_admin' },
        sessionToken: 'super_admin_token_' + Date.now()
      });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Super admin auth error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Super Admin API Routes
app.get('/api/super-admin/bases', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM bases ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/super-admin/bases', async (req, res) => {
  try {
    const { name, subdomain, systemMode, deploymentType, adminEmail, adminPassword, nocodbUrl, nocodbApiKey, nocodbBaseId } = req.body;
    
    // Create new base
    const baseResult = await pool.query(`
      INSERT INTO bases (name, subdomain, system_mode, deployment_type, nocodb_url, nocodb_api_key, nocodb_base_id, db_path)
      VALUES ($1, $2, $3, $4, $5, $6, $7, 'default')
      RETURNING *
    `, [name, subdomain, systemMode || 'standalone', deploymentType || 'basic', nocodbUrl, nocodbApiKey, nocodbBaseId]);
    
    const newBase = baseResult.rows[0];
    
    // Create admin user for the base if credentials provided
    if (adminEmail && adminPassword) {
      // Simple password storage for testing - replace with bcrypt in production
      await pool.query(`
        INSERT INTO base_users (base_id, username, email, password, name, role, is_active)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [newBase.id, adminEmail.split('@')[0], adminEmail, adminPassword, name + ' Admin', 'admin', true]);
    }
    
    res.json(newBase);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/super-admin/bases/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    // Delete related data first
    await pool.query('DELETE FROM base_users WHERE base_id = $1', [id]);
    await pool.query('DELETE FROM base_tables WHERE base_id = $1', [id]);
    await pool.query('DELETE FROM field_permissions WHERE base_id = $1', [id]);
    await pool.query('DELETE FROM api_tokens WHERE base_id = $1', [id]);
    await pool.query('DELETE FROM magic_links WHERE base_id = $1', [id]);
    
    // Delete the base
    const result = await pool.query('DELETE FROM bases WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Base-specific Authentication Routes
app.post('/api/base/:subdomain/login', async (req, res) => {
  try {
    const { subdomain } = req.params;
    const { email, password } = req.body;
    
    // Find the base by subdomain
    const baseResult = await pool.query('SELECT * FROM bases WHERE subdomain = $1', [subdomain]);
    if (baseResult.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    const base = baseResult.rows[0];
    
    // Find user in this base
    const userResult = await pool.query(
      'SELECT * FROM base_users WHERE base_id = $1 AND email = $2 AND is_active = true',
      [base.id, email]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const user = userResult.rows[0];
    
    // Verify password (simple comparison for testing - replace with bcrypt in production)
    const passwordMatch = password === user.password;
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Return successful login
    res.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      },
      base: {
        id: base.id,
        name: base.name,
        subdomain: base.subdomain,
        system_mode: base.system_mode
      },
      sessionToken: `${base.subdomain}_${user.id}_${Date.now()}`
    });
    
  } catch (error) {
    console.error('Base auth error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Base-specific API Routes
app.get('/api/base/:subdomain/info', async (req, res) => {
  try {
    const { subdomain } = req.params;
    
    const result = await pool.query('SELECT * FROM bases WHERE subdomain = $1', [subdomain]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/base/:subdomain/users', async (req, res) => {
  try {
    const { subdomain } = req.params;
    
    // Get base ID
    const baseResult = await pool.query('SELECT id FROM bases WHERE subdomain = $1', [subdomain]);
    if (baseResult.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    const baseId = baseResult.rows[0].id;
    
    // Get users for this base
    const usersResult = await pool.query(
      'SELECT id, username, email, name, role, is_active, created_at FROM base_users WHERE base_id = $1 ORDER BY created_at DESC',
      [baseId]
    );
    
    res.json(usersResult.rows);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/base/:subdomain/tables', async (req, res) => {
  try {
    const { subdomain } = req.params;
    
    // Get base ID
    const baseResult = await pool.query('SELECT id FROM bases WHERE subdomain = $1', [subdomain]);
    if (baseResult.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    const baseId = baseResult.rows[0].id;
    
    // Get tables for this base
    const tablesResult = await pool.query(
      'SELECT * FROM base_tables WHERE base_id = $1 ORDER BY created_at DESC',
      [baseId]
    );
    
    res.json(tablesResult.rows);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Magic Link Routes
app.get('/api/magic-link/:token', async (req, res) => {
  try {
    const { token } = req.params;
    
    // Handle demo tokens
    if (token === 'ssc5demo123' || token === 'ssc6demo123') {
      const baseName = token.includes('ssc5') ? 'SSC5' : 'SSC6';
      const adminEmail = `admin@${baseName.toLowerCase()}.com`;
      
      return res.json({ 
        base: { id: token.includes('ssc5') ? 3 : 4, name: baseName },
        adminEmail,
        token 
      });
    }
    
    // Check database for magic link
    const result = await pool.query(`
      SELECT ml.*, b.name as base_name, b.subdomain
      FROM magic_links ml
      JOIN bases b ON ml.base_id = b.id
      WHERE ml.token = $1 AND ml.is_used = false AND ml.expires_at > NOW()
    `, [token]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Invalid or expired magic link' });
    }
    
    const magicLink = result.rows[0];
    res.json({
      base: {
        id: magicLink.base_id,
        name: magicLink.base_name,
        subdomain: magicLink.subdomain
      },
      adminEmail: magicLink.admin_email,
      token
    });
    
  } catch (error) {
    console.error('Magic link error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/admin-setup', async (req, res) => {
  try {
    const { token, name, password } = req.body;
    
    // Find magic link
    const linkResult = await pool.query(`
      SELECT ml.*, b.id as base_id, b.subdomain
      FROM magic_links ml
      JOIN bases b ON ml.base_id = b.id
      WHERE ml.token = $1 AND ml.is_used = false AND ml.expires_at > NOW()
    `, [token]);
    
    if (linkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invalid or expired magic link' });
    }
    
    const magicLink = linkResult.rows[0];
    
    // Create admin user
    // Simple password storage for testing - replace with bcrypt in production
    const userResult = await pool.query(`
      INSERT INTO base_users (base_id, username, email, password, name, role, is_active)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id, username, email, name, role
    `, [magicLink.base_id, magicLink.admin_email.split('@')[0], magicLink.admin_email, password, name, 'admin', true]);
    
    // Mark magic link as used
    await pool.query('UPDATE magic_links SET is_used = true WHERE id = $1', [magicLink.id]);
    
    res.json({
      success: true,
      user: userResult.rows[0],
      redirectUrl: `/base/${magicLink.subdomain}`
    });
    
  } catch (error) {
    console.error('Admin setup error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Simple CSV data import endpoint
app.post('/api/base/:subdomain/import-csv', async (req, res) => {
  try {
    const { subdomain } = req.params;
    const { csvData, tableName } = req.body;
    
    if (!csvData || typeof csvData !== 'string') {
      return res.status(400).json({ error: 'No CSV data provided' });
    }

    // Get base information
    const baseResult = await pool.query('SELECT * FROM bases WHERE subdomain = $1', [subdomain]);
    if (baseResult.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    const base = baseResult.rows[0];
    
    // Parse CSV data
    const lines = csvData.trim().split('\n');
    if (lines.length < 2) {
      return res.status(400).json({ error: 'CSV must have at least header and one data row' });
    }
    
    // Extract headers
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const dataRows = lines.slice(1).map(line => {
      const values = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          values.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      values.push(current.trim());
      return values;
    });
    
    // Detect geometry fields
    const geometryFields = [];
    if (dataRows.length > 0) {
      headers.forEach((header, index) => {
        const sampleValue = dataRows[0][index] || '';
        if (header.toLowerCase().includes('geometry') || 
            header.toLowerCase().includes('geom') ||
            sampleValue.includes('POLYGON') || 
            sampleValue.includes('POINT') ||
            sampleValue.includes('MULTIPOLYGON')) {
          geometryFields.push(header);
        }
      });
    }
    
    // Create table schema
    const actualTableName = tableName || `imported_data_${Date.now()}`;
    const columnDefinitions = ['id SERIAL PRIMARY KEY', 'base_id INTEGER REFERENCES bases(id)'];
    
    headers.forEach(header => {
      const safeHeader = header.replace(/[^a-zA-Z0-9_]/g, '_');
      if (geometryFields.includes(header)) {
        columnDefinitions.push(`"${safeHeader}" GEOMETRY`);
      } else {
        columnDefinitions.push(`"${safeHeader}" TEXT`);
      }
    });
    
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS "${actualTableName}" (
        ${columnDefinitions.join(', ')}
      )
    `;
    
    await pool.query(createTableQuery);
    
    // Insert data
    let insertedCount = 0;
    for (const row of dataRows) {
      if (row.length !== headers.length) continue; // Skip malformed rows
      
      const values = [base.id]; // base_id first
      const placeholders = ['$1'];
      let paramIndex = 2;
      
      headers.forEach((header, index) => {
        let value = row[index] || null;
        if (value === '') value = null;
        values.push(value);
        placeholders.push(`$${paramIndex}`);
        paramIndex++;
      });
      
      const safeHeaders = headers.map(h => `"${h.replace(/[^a-zA-Z0-9_]/g, '_')}"`);
      const columnsList = ['base_id', ...safeHeaders];
      const insertQuery = `
        INSERT INTO "${actualTableName}" (${columnsList.join(', ')})
        VALUES (${placeholders.join(', ')})
      `;
      
      try {
        await pool.query(insertQuery, values);
        insertedCount++;
      } catch (insertError) {
        console.log(`Skipped row ${insertedCount + 1}: ${insertError.message}`);
      }
    }
    
    res.json({
      success: true,
      message: `Successfully imported ${insertedCount} records`,
      tableName: actualTableName,
      columns: headers,
      geometryFields,
      recordCount: insertedCount,
      totalRows: dataRows.length
    });
    
  } catch (error) {
    console.error('CSV import error:', error);
    res.status(500).json({ 
      error: 'Failed to import CSV data',
      details: error.message 
    });
  }
});

// Get tables for a specific base
app.get('/api/base/:subdomain/tables', async (req, res) => {
  try {
    const { subdomain } = req.params;
    
    // Get base information
    const baseResult = await pool.query('SELECT * FROM bases WHERE subdomain = $1', [subdomain]);
    if (baseResult.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    // Get all tables that have base_id column (multi-tenant tables)
    const tablesResult = await pool.query(`
      SELECT table_name, column_name
      FROM information_schema.columns 
      WHERE table_schema = 'public' 
      AND column_name = 'base_id'
      AND table_name NOT IN ('bases', 'base_users', 'user_sessions', 'api_tokens', 'field_permissions', 'magic_links')
      ORDER BY table_name
    `);
    
    const tables = [...new Set(tablesResult.rows.map(row => row.table_name))];
    
    res.json({ tables });
    
  } catch (error) {
    console.error('Tables fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get data from a specific table for a base
app.get('/api/base/:subdomain/tables/:tableName/data', async (req, res) => {
  try {
    const { subdomain, tableName } = req.params;
    const { limit = 100, offset = 0 } = req.query;
    
    // Get base information
    const baseResult = await pool.query('SELECT * FROM bases WHERE subdomain = $1', [subdomain]);
    if (baseResult.rows.length === 0) {
      return res.status(404).json({ error: 'Base not found' });
    }
    
    const base = baseResult.rows[0];
    
    // Sanitize table name to prevent SQL injection
    const sanitizedTableName = tableName.replace(/[^a-zA-Z0-9_]/g, '');
    
    // Get table data filtered by base_id
    const dataResult = await pool.query(`
      SELECT * FROM "${sanitizedTableName}" 
      WHERE base_id = $1 
      ORDER BY id 
      LIMIT $2 OFFSET $3
    `, [base.id, parseInt(limit), parseInt(offset)]);
    
    // Get total count
    const countResult = await pool.query(`
      SELECT COUNT(*) as total FROM "${sanitizedTableName}" WHERE base_id = $1
    `, [base.id]);
    
    res.json({
      data: dataResult.rows,
      total: parseInt(countResult.rows[0].total),
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
    
  } catch (error) {
    console.error('Table data fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'Team 2 GIS Complete System',
    timestamp: new Date().toISOString()
  });
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/public', 'index.html'));
});

// Start server
app.listen(PORT, HOST, () => {
  console.log(`Server running on http://${HOST}:${PORT}`);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('Shutting down server...');
  pool.end();
  process.exit(0);
});