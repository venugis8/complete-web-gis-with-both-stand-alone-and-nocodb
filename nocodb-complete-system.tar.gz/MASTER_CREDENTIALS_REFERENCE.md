# Master Credentials & System Access Reference

## Server Access
```
Server: 172.232.108.139
SSH User: root
SSH Password: Geo@asset15!
Application Path: /opt/team2-gis
Port: 5000
```

## PostgreSQL Database Credentials

### Master Database Access (Full Administrative Rights)
```
Host: 172.232.108.139
Port: 5432
Username: postgres
Password: PostgresAdmin2024!
Database: gisdb
Connection String: postgresql://postgres:PostgresAdmin2024!@172.232.108.139:5432/gisdb
```

### Application Database Access
```
Host: 172.232.108.139
Port: 5432
Username: gisuser
Password: gispassword123
Database: gisdb
Connection String: postgresql://gisuser:gispassword123@172.232.108.139:5432/gisdb
```

## External Database Access Commands

### Using psql Command Line
```bash
# Master access (full privileges)
PGPASSWORD=PostgresAdmin2024! psql -h 172.232.108.139 -U postgres -d gisdb

# Application access
PGPASSWORD=gispassword123 psql -h 172.232.108.139 -U gisuser -d gisdb
```

### pgAdmin Configuration
```
Host: 172.232.108.139
Port: 5432
Maintenance Database: gisdb
Username: postgres
Password: PostgresAdmin2024!
SSL Mode: Prefer
```

### DBeaver Configuration
```
Server Host: 172.232.108.139
Port: 5432
Database: gisdb
Username: postgres
Password: PostgresAdmin2024!
```

## Application Status Commands

### Process Management
```bash
# SSH into server
ssh root@172.232.108.139

# Check application status
pm2 status

# View application logs
pm2 logs team2-gis

# Restart application
pm2 restart team2-gis
```

### Database Operations
```bash
# Connect to database
PGPASSWORD=PostgresAdmin2024! psql -h 172.232.108.139 -U postgres -d gisdb

# List all tables
\dt

# Check bases (tenants)
SELECT * FROM bases;

# Check users
SELECT * FROM users;

# Exit psql
\q
```

## Web Application Access

### Frontend URLs
```
Main Application: http://172.232.108.139:5000
Super Admin Panel: http://172.232.108.139:5000/super-admin
Base Workspace (example): http://172.232.108.139:5000/team2
Base Workspace (sln): http://172.232.108.139:5000/sln
```

### Test Authentication
```bash
# Test API endpoint
curl http://172.232.108.139:5000/api/super-admin/bases

# Test base-specific login
curl -X POST http://172.232.108.139:5000/api/base/sln/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@sln.com", "password": "admin123"}'
```

## Current System Status

### Active Bases
- ID 1: Team 2 Standalone (subdomain: team2)
- ID 2: sln (subdomain: sln)

### Database Tables
- bases: Tenant management
- users: User authentication
- user_sessions: Session management
- sites: Geospatial data storage

### Technology Stack
- Frontend: React 18 + TypeScript + Tailwind CSS
- Backend: Node.js + Express + Drizzle ORM
- Database: PostgreSQL 14 + PostGIS
- Process Manager: PM2
- Maps: Leaflet.js with OpenStreetMap

## Security Notes

### Access Control
- Master postgres user has full database privileges
- Application gisuser has restricted access to application tables
- External connections enabled for both users
- SSH access available with root privileges

### Important Files
- Application: /opt/team2-gis/
- Environment: /opt/team2-gis/.env
- Logs: PM2 managed logging
- Database: Standard PostgreSQL data directory

### Port Configuration
- Application: 5000 (HTTP)
- Database: 5432 (PostgreSQL)
- SSH: 22 (Standard SSH)

This reference provides all essential credentials and access methods for complete system administration.