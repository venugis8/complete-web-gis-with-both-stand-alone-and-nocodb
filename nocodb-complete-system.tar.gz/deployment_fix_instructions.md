# Team 2 Standalone GIS Deployment Fix

## Problem Diagnosis
The 502 Bad Gateway error occurs because the application binds to localhost (127.0.0.1) only, preventing Nginx from proxying external requests.

## Solution
Replace the current server with one that binds to all interfaces (0.0.0.0).

## Step-by-Step Fix Instructions

### On Server 172.232.108.139:

1. **Copy the production server file**
   ```bash
   # Upload production_server.js to /opt/team2-gis/
   ```

2. **Stop current application**
   ```bash
   cd /opt/team2-gis
   pm2 stop team2-standalone-gis
   pm2 delete team2-standalone-gis
   ```

3. **Start new production server**
   ```bash
   pm2 start production_server.js --name "team2-standalone-gis"
   pm2 save
   ```

4. **Verify binding**
   ```bash
   netstat -tlnp | grep :5000
   # Should show: 0.0.0.0:5000 instead of 127.0.0.1:5000
   ```

5. **Test local connection**
   ```bash
   curl -I http://localhost:5000
   # Should return: HTTP/1.1 200 OK
   ```

6. **Restart Nginx**
   ```bash
   systemctl restart nginx
   ```

7. **Test external access**
   ```bash
   curl -I http://172.232.108.139
   # Should return: HTTP/1.1 200 OK (not 502)
   ```

## Verification
- Application accessible at: http://172.232.108.139
- Health check: http://172.232.108.139/api/health
- PM2 status should show process running
- No 502 errors in Nginx logs

## Files Created
- `production_server.js` - Production server that binds to all interfaces
- Includes proper error handling and logging
- Serves static files and API endpoints
- Graceful shutdown handling