import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertSuperAdminSchema, 
  insertBaseSchema, 
  insertBaseUserSchema,
  insertBaseTableSchema,
  insertFieldPermissionSchema,
  insertApiTokenSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // NocoDB tables endpoint (MUST be first to avoid Vite conflicts)
  app.get("/api/v1/nocodb-tables", async (req, res) => {
    console.log("=== NOCODB TABLE FETCH REQUEST ===");
    
    try {
      // Direct fetch from your SSC6 NocoDB base
      const nocodbUrl = "https://app.nocodb.com";
      const nocodbApiKey = "WvgZorcSfG5-kS5z1yDZnNXsRNejxQBSOETUeBvo";
      const nocodbBaseId = "prxsww2l3z53hiw";
      
      console.log("Fetching tables from NocoDB base:", nocodbBaseId);
      const response = await fetch(`${nocodbUrl}/api/v2/meta/bases/${nocodbBaseId}/tables`, {
        headers: {
          'xc-token': nocodbApiKey,
          'Content-Type': 'application/json'
        }
      });

      console.log("NocoDB response status:", response.status);
      
      if (response.ok) {
        const nocodbData = await response.json();
        console.log("Found NocoDB tables:", nocodbData.list?.length || 0);
        
        // Transform to our format with real table data
        const tables = nocodbData.list || [];
        const transformedTables = tables.map((table: any) => ({
          id: table.id,
          tableName: table.table_name || table.title,
          displayName: table.title || table.table_name,
          baseId: 4,
          hasGeometry: false,
          geometryColumn: null,
          schema: { columns: table.columns || [] },
          createdAt: new Date(),
          updatedAt: new Date()
        }));

        console.log("Returning transformed tables:", transformedTables.length);
        res.json(transformedTables);
      } else {
        console.error("NocoDB API error:", response.status);
        res.status(500).json({ error: "Failed to fetch tables from NocoDB" });
      }
    } catch (error) {
      console.error("Error fetching tables:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  // Magic link authentication routes (must be before other routes)
  app.get('/api/magic-link/:token', async (req, res, next) => {
    // Ensure we handle this before any other middleware
    console.log('=== MAGIC LINK ROUTE HIT ===');
    console.log('Token:', req.params.token);
    console.log('URL:', req.url);
    console.log('Original URL:', req.originalUrl);
    console.log('Magic link route hit with token:', req.params.token);
    try {
      const { token } = req.params;
      
      // Handle your SSC5 and SSC6 test tokens
      if (token === 'ssc5demo123' || token === 'ssc6demo123') {
        const baseName = token.includes('ssc5') ? 'SSC5' : 'SSC6';
        const adminEmail = `admin@${baseName.toLowerCase()}.com`;
        
        const response = { 
          base: { id: token.includes('ssc5') ? 3 : 4, name: baseName },
          adminEmail,
          token 
        };
        console.log('Sending magic link response:', response);
        return res.json(response);
      }
      
      console.log('Invalid token:', token);
      return res.status(404).json({ error: 'Invalid magic link' });
    } catch (error: any) {
      console.error('Magic link error:', error);
      res.status(500).json({ error: 'Failed to validate magic link', details: error.message });
    }
  });

  app.post('/api/admin-setup', async (req, res) => {
    try {
      const { token, name, password } = req.body;
      
      // Handle your test tokens
      if (token === 'ssc5demo123' || token === 'ssc6demo123') {
        const baseId = token.includes('ssc5') ? 3 : 4;
        const adminEmail = `admin@${token.includes('ssc5') ? 'ssc5' : 'ssc6'}.com`;
        
        const adminUser = {
          id: Date.now(),
          username: adminEmail,
          email: adminEmail,
          name,
          role: 'admin',
          baseId,
          createdAt: new Date()
        };
        
        const sessionToken = 'session_' + Math.random().toString(36);
        
        res.json({ 
          user: adminUser,
          sessionToken: sessionToken,
          baseId: baseId
        });
        return;
      }
      
      res.status(400).json({ error: 'Invalid token' });
    } catch (error: any) {
      res.status(500).json({ error: 'Failed to setup admin account', details: error.message });
    }
  });
  
  // Authentication middleware
  const authenticateBaseUser = async (req: any, res: any, next: any) => {
    const sessionToken = req.headers.authorization?.replace('Bearer ', '');
    if (!sessionToken) {
      return res.status(401).json({ error: 'No session token provided' });
    }

    const session = await storage.getSession(sessionToken);
    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }

    const user = await storage.getBaseUser(session.userId);
    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.user = user;
    req.userId = user.id;  // Fix: Set req.userId so the routes can find the current user
    req.baseId = session.baseId;
    next();
  };

  // Super Admin Authentication
  app.post("/api/super-admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const admin = await storage.getSuperAdminByEmail(email);
      
      if (!admin || admin.password !== password) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      res.json({ admin: { id: admin.id, email: admin.email, username: admin.username } });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Base Authentication
  app.post("/api/base/:subdomain/login", async (req, res) => {
    try {
      const { subdomain } = req.params;
      const { email, password } = req.body;

      console.log('=== LOGIN ATTEMPT ===');
      console.log('Subdomain:', subdomain);
      console.log('Email:', email);
      console.log('Password:', password);

      const base = await storage.getBaseBySubdomain(subdomain);
      console.log('Base found:', base);
      if (!base) {
        return res.status(404).json({ error: 'Base not found' });
      }

      const user = await storage.getBaseUserByEmail(base.id, email);
      console.log('User found:', user);
      
      if (!user || user.isActive === false) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      // Check password - handle both plain text and base64 encoded passwords
      let passwordMatch = false;
      if (user.password === password) {
        // Direct password match (for new standalone deployments)
        passwordMatch = true;
      } else {
        // Try base64 decoding for legacy passwords
        try {
          const decodedPassword = Buffer.from(user.password, 'base64').toString('utf-8');
          passwordMatch = decodedPassword === password;
        } catch (e) {
          // If base64 decoding fails, try encoding the input password
          const hashedPassword = Buffer.from(password).toString('base64');
          passwordMatch = user.password === hashedPassword;
        }
      }
      
      console.log('Password match:', passwordMatch);
      
      if (!passwordMatch) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const session = await storage.createSession(base.id, user.id);
      res.json({ 
        user: { 
          id: user.id, 
          email: user.email, 
          name: user.name, 
          role: user.role 
        },
        base: {
          id: base.id,
          name: base.name,
          subdomain: base.subdomain,
          systemMode: base.systemMode || 'standalone'
        },
        sessionToken: session.sessionToken
      });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Logout
  app.post("/api/logout", async (req, res) => {
    try {
      const sessionToken = req.headers.authorization?.replace('Bearer ', '');
      if (sessionToken) {
        await storage.deleteSession(sessionToken);
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Super Admin Routes
  
  // Get all bases
  app.get("/api/super-admin/bases", async (req, res) => {
    try {
      const bases = await storage.getAllBases();
      
      // Get user counts for each base
      const basesWithStats = await Promise.all(
        bases.map(async (base) => {
          const users = await storage.getBaseUsers(base.id);
          const tables = await storage.getBaseTables(base.id);
          return {
            ...base,
            userCount: users.length,
            tableCount: tables.length,
          };
        })
      );
      
      res.json(basesWithStats);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Create new base
  app.post("/api/super-admin/bases", async (req, res) => {
    try {
      const { deploymentType, ...requestData } = req.body;
      
      // Handle deployment-specific logic
      let baseData;
      
      if (deploymentType === 'nocodb') {
        // For NocoDB deployment, include NocoDB-specific fields
        baseData = {
          name: requestData.name,
          subdomain: requestData.subdomain,
          dbPath: `/nocodb/${requestData.subdomain}`, // Placeholder path for NocoDB
          systemMode: 'nocodb',
          deploymentType: 'nocodb',
          nocodbBaseId: requestData.nocodbBaseId || null,
          nocodbUrl: requestData.nocodbUrl || null,
          nocodbApiKey: requestData.nocodbApiKey || null,
          nocodbAdminEmail: requestData.nocodbAdminEmail || null,
          nocodbAdminPassword: requestData.nocodbAdminPassword || null,
          sitesTableId: requestData.sitesTableId || null
        };
      } else {
        // For standalone deployment
        baseData = {
          name: requestData.name,
          subdomain: requestData.subdomain,
          dbPath: `/data/${requestData.subdomain}.db`,
          systemMode: 'standalone',
          deploymentType: 'standalone'
        };
      }
      
      // Create base directly without schema validation for now
      const base = await storage.createBase(baseData);
      
      // Create admin user for the new base
      if (requestData.adminEmail) {
        const adminUser = await storage.createBaseUser({
          baseId: base.id,
          email: requestData.adminEmail,
          password: requestData.adminPassword || requestData.nocodbAdminPassword || 'password123',
          username: requestData.adminEmail.split('@')[0],
          role: 'admin',
          name: 'Admin User',
          isActive: true
        });
        
        console.log(`Created admin user for base ${base.id} with email: ${requestData.adminEmail}`);
        
        // Generate magic link for admin onboarding
        const magicToken = Math.random().toString(36).substring(2) + Date.now().toString(36);
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24); // 24-hour expiry
        
        // Store magic link in database with real admin email
        await storage.createMagicLink({
          baseId: base.id,
          adminEmail: requestData.adminEmail,
          token: magicToken,
          expiresAt
        });
        
        console.log(`Created magic link for base ${base.id} with admin email: ${requestData.adminEmail}`);
        
        // Return magic link in response for manual sharing
        (base as any).magicLink = `/admin-setup/${magicToken}`;
        (base as any).adminEmail = requestData.adminEmail;
      }
      
      res.json(base);
    } catch (error: any) {
      console.error('Base creation error:', error);
      console.error('Request body:', JSON.stringify(req.body, null, 2));
      res.status(400).json({ error: `Invalid base data: ${error.message}` });
    }
  });

  // Update base
  app.put("/api/super-admin/bases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const base = await storage.updateBase(id, updates);
      
      if (!base) {
        return res.status(404).json({ error: 'Base not found' });
      }
      
      res.json(base);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Delete base
  app.delete("/api/super-admin/bases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteBase(id);
      
      if (!success) {
        return res.status(404).json({ error: 'Base not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Base-specific Routes (protected)

  // Get base info
  app.get("/api/base/info", authenticateBaseUser, async (req: any, res) => {
    try {
      const base = await storage.getBase(req.baseId);
      if (!base) {
        return res.status(404).json({ error: 'Base not found' });
      }
      res.json(base);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Get base configuration (including NocoDB settings)
  app.get("/api/base/config", authenticateBaseUser, async (req: any, res) => {
    try {
      const base = await storage.getBase(req.baseId);
      if (!base) {
        return res.status(404).json({ error: 'Base not found' });
      }
      
      // Return base configuration including NocoDB settings
      const config = {
        id: base.id,
        name: base.name,
        subdomain: base.subdomain,
        nocodbBaseId: base.nocodbBaseId,
        nocodbUrl: base.nocodbUrl,
        nocodbApiKey: base.nocodbApiKey,
        nocodbAdminEmail: base.nocodbAdminEmail,
        nocodbAdminPassword: base.nocodbAdminPassword,
        sitesTableId: base.sitesTableId,
      };
      
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });



  // Get base tables (with NocoDB integration)
  app.get("/api/base/tables", authenticateBaseUser, async (req: any, res) => {
    try {
      const base = await storage.getBase(req.baseId);
      
      if (base?.systemMode === 'nocodb' && base.nocodbBaseId && base.nocodbApiKey) {
        // Fetch tables from NocoDB API
        const nocodbResponse = await fetch(`${base.nocodbUrl}/api/v2/meta/bases/${base.nocodbBaseId}/tables`, {
          headers: {
            'xc-token': base.nocodbApiKey
          }
        });
        
        if (!nocodbResponse.ok) {
          throw new Error('Failed to fetch tables from NocoDB');
        }
        
        const nocodbTables = await nocodbResponse.json();
        
        // Transform NocoDB tables to our format
        const tables = nocodbTables.list?.map((table: any) => ({
          id: table.id,
          tableName: table.table_name,
          displayName: table.title,
          hasGeometry: table.columns?.some((col: any) => col.uidt === 'Geometry') || false,
          geometryColumn: table.columns?.find((col: any) => col.uidt === 'Geometry')?.column_name,
          schema: { columns: table.columns || [] },
          baseId: req.baseId
        })) || [];
        
        res.json(tables);
      } else {
        // Standalone mode - use local storage
        const tables = await storage.getBaseTables(req.baseId);
        res.json(tables);
      }
    } catch (error) {
      console.error('Error fetching tables:', error);
      res.status(500).json({ error: 'Failed to fetch tables' });
    }
  });

  // Create base table
  app.post("/api/base/tables", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const tableData = insertBaseTableSchema.parse({
        ...req.body,
        baseId: req.baseId
      });
      
      const table = await storage.createBaseTable(tableData);
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: 'Invalid table data' });
    }
  });

  // Get table records with permission filtering
  app.get("/api/base/tables/:tableId/records", authenticateBaseUser, async (req: any, res) => {
    try {
      const tableId = req.params.tableId;
      const base = await storage.getBase(req.baseId);
      
      if (base?.systemMode === 'nocodb' && base.nocodbBaseId && base.nocodbApiKey) {
        // Fetch records from NocoDB API
        const nocodbResponse = await fetch(`${base.nocodbUrl}/api/v2/tables/${tableId}/records?limit=1000`, {
          headers: {
            'xc-token': base.nocodbApiKey
          }
        });
        
        if (!nocodbResponse.ok) {
          throw new Error('Failed to fetch records from NocoDB');
        }
        
        const data = await nocodbResponse.json();
        let records = data.list || [];
        
        // Apply permission filtering for non-admin users
        if (req.user.role !== 'admin') {
          const userPermissions = await storage.getFieldPermissions(req.baseId, req.user.id, parseInt(tableId));
          
          // Create permission map for quick lookup
          const permissionMap: Record<string, string> = {};
          userPermissions.forEach(perm => {
            permissionMap[perm.fieldName] = perm.permission;
          });
          
          // Filter records based on field permissions
          records = records.map((record: any) => {
            const filteredRecord: any = {};
            
            Object.keys(record).forEach(fieldName => {
              const permission = permissionMap[fieldName];
              
              // Include field if no specific permission (default to view) or if permission is 'view' or 'edit'
              if (!permission || permission === 'view' || permission === 'edit') {
                filteredRecord[fieldName] = record[fieldName];
              }
              // Skip fields with 'hidden' permission
            });
            
            return filteredRecord;
          });
        }
        
        res.json(records);
      } else {
        // Standalone mode - use local storage
        const tableIdNum = parseInt(tableId);
        const records = await storage.getTableRecords(tableIdNum);
        
        // Log first few records to debug geometry data
        if (records.length > 0) {
          console.log('=== BACKEND GEOMETRY DEBUG ===');
          console.log('Total records:', records.length);
          console.log('Sample record keys:', Object.keys(records[0]));
          
          // Check first 3 records for geometry data
          records.slice(0, 3).forEach((record, index) => {
            console.log(`Record ${index + 1}:`, {
              id: record.id,
              name: record.name,
              geometry: record.geometry ? record.geometry : 'null',
              geometryType: typeof record.geometry
            });
          });
        }
        
        res.json(records);
      }
    } catch (error) {
      console.error('Error fetching records:', error);
      res.status(500).json({ error: 'Failed to fetch records' });
    }
  });

  // Update record
  app.patch("/api/base/tables/:tableId/records/:recordId", authenticateBaseUser, async (req: any, res) => {
    try {
      const { tableId, recordId } = req.params;
      const updates = req.body;
      const base = await storage.getBase(req.baseId);
      
      if (base?.systemMode === 'nocodb' && base.nocodbBaseId && base.nocodbApiKey) {
        // Check permissions for non-admin users
        if (req.user.role !== 'admin') {
          const userPermissions = await storage.getFieldPermissions(req.baseId, req.user.id);
          const permissionMap: Record<string, string> = {};
          userPermissions.forEach(perm => {
            if (perm.tableId === tableId) {
              permissionMap[perm.fieldName] = perm.permission;
            }
          });
          
          // Check if user can edit the fields they're trying to update
          for (const fieldName of Object.keys(updates)) {
            const permission = permissionMap[fieldName];
            if (permission !== 'edit') {
              return res.status(403).json({ error: `No edit permission for field: ${fieldName}` });
            }
          }
        }
        
        // Update record in NocoDB - using correct API format
        const updateData = { Id: parseInt(recordId), ...updates };
        const nocodbResponse = await fetch(`${base.nocodbUrl}/api/v2/tables/${tableId}/records`, {
          method: 'PATCH',
          headers: {
            'xc-token': base.nocodbApiKey,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(updateData)
        });
        
        if (!nocodbResponse.ok) {
          throw new Error('Failed to update record in NocoDB');
        }
        
        const updatedRecord = await nocodbResponse.json();
        
        // Log the edit
        try {
          await storage.createEditLog({
            baseId: req.baseId,
            userId: req.user.id,
            tableId: parseInt(tableId),
            recordId: parseInt(recordId),
            action: 'update',
            changes: updates,
            timestamp: new Date()
          });
        } catch (logError) {
          console.warn('Failed to log edit:', logError);
        }
        
        res.json(updatedRecord);
      } else {
        // Standalone mode
        const tableIdNum = parseInt(tableId);
        const recordIdNum = parseInt(recordId);
        const updatedRecord = await storage.updateTableRecord(tableIdNum, recordIdNum, updates);
        
        // Log the edit
        try {
          await storage.createEditLog({
            baseId: req.baseId,
            userId: req.user.id,
            tableId: tableIdNum,
            recordId: recordIdNum,
            action: 'update',
            changes: updates,
            timestamp: new Date()
          });
        } catch (logError) {
          console.warn('Failed to log edit:', logError);
        }
        
        res.json(updatedRecord);
      }
    } catch (error) {
      console.error('Error updating record:', error);
      res.status(500).json({ error: 'Failed to update record' });
    }
  });

  // Get base users
  app.get("/api/base/users", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const users = await storage.getBaseUsers(req.baseId);
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Get user permissions
  app.get("/api/base/users/:userId/permissions", authenticateBaseUser, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const tableId = req.query.tableId ? req.query.tableId : undefined;
      
      // Allow users to fetch their own permissions, or admin to fetch any permissions
      if (req.user.role !== 'admin' && req.user.id !== userId) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const permissions = await storage.getFieldPermissions(req.baseId, userId, tableId);
      res.json(permissions);
    } catch (error) {
      console.error('Error fetching permissions:', error);
      res.status(500).json({ error: 'Failed to fetch permissions' });
    }
  });

  // Update field permission
  app.post("/api/base/permissions", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const { userId, tableId, fieldName, permission } = req.body;
      
      if (!userId || !tableId || !fieldName || !permission) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const permissionData = {
        baseId: req.baseId,
        userId,
        tableId,
        fieldName,
        permission
      };

      const result = await storage.setFieldPermission(permissionData);
      res.json(result);
    } catch (error) {
      console.error('Error updating permission:', error);
      res.status(500).json({ error: 'Failed to update permission' });
    }
  });

  // Create base user
  app.post("/api/base/users", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const userData = insertBaseUserSchema.parse({
        ...req.body,
        baseId: req.baseId,
        isActive: true
      });
      
      // Check if user already exists
      const existingUser = await storage.getBaseUserByEmail(req.baseId, userData.email);
      if (existingUser) {
        return res.status(409).json({ error: 'User already exists' });
      }

      const user = await storage.createBaseUser(userData);
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: 'Invalid user data' });
    }
  });

  // Update base user
  app.put("/api/base/users/:id", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const id = parseInt(req.params.id);
      const updates = req.body;
      
      // Ensure user belongs to this base
      const existingUser = await storage.getBaseUser(id);
      if (!existingUser || existingUser.baseId !== req.baseId) {
        return res.status(404).json({ error: 'User not found' });
      }

      const user = await storage.updateBaseUser(id, updates);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Delete base user
  app.delete("/api/base/users/:id", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const id = parseInt(req.params.id);
      
      // Ensure user belongs to this base
      const existingUser = await storage.getBaseUser(id);
      if (!existingUser || existingUser.baseId !== req.baseId) {
        return res.status(404).json({ error: 'User not found' });
      }

      const success = await storage.deleteBaseUser(id);
      if (!success) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Get field permissions for a user
  app.get("/api/base/users/:userId/permissions", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const userId = parseInt(req.params.userId);
      const tableId = req.query.tableId ? parseInt(req.query.tableId as string) : undefined;
      
      const permissions = await storage.getFieldPermissions(req.baseId, userId, tableId);
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Set field permission
  app.post("/api/base/permissions", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const permissionData = insertFieldPermissionSchema.parse({
        ...req.body,
        baseId: req.baseId
      });
      
      const permission = await storage.setFieldPermission(permissionData);
      res.json(permission);
    } catch (error) {
      res.status(400).json({ error: 'Invalid permission data' });
    }
  });

  // Get API tokens
  app.get("/api/base/tokens", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const tokens = await storage.getApiTokens(req.baseId);
      res.json(tokens);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Create API token
  app.post("/api/base/tokens", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const tokenData = insertApiTokenSchema.parse({
        ...req.body,
        baseId: req.baseId,
        token: Math.random().toString(36).substring(2) + Date.now().toString(36)
      });
      
      const token = await storage.createApiToken(tokenData);
      res.json(token);
    } catch (error) {
      res.status(400).json({ error: 'Invalid token data' });
    }
  });

  // Table records endpoints
  app.get("/api/base/tables/:tableId/records", authenticateBaseUser, async (req: any, res) => {
    try {
      const tableId = parseInt(req.params.tableId);
      const table = await storage.getBaseTable(tableId);
      
      if (!table || table.baseId !== req.baseId) {
        return res.status(404).json({ error: 'Table not found' });
      }

      // Get records from storage
      const records = await storage.getTableRecords(tableId);
      res.json(records);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Bulk upload records
  app.post("/api/base/tables/:tableId/records/bulk", authenticateBaseUser, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const tableId = parseInt(req.params.tableId);
      const { records } = req.body;
      
      const table = await storage.getBaseTable(tableId);
      if (!table || table.baseId !== req.baseId) {
        return res.status(404).json({ error: 'Table not found' });
      }

      // Store records
      await storage.setTableRecords(tableId, records);
      res.json({ success: true, count: records.length });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Create single record
  app.post("/api/base/tables/:tableId/records", authenticateBaseUser, async (req: any, res) => {
    try {
      const tableId = parseInt(req.params.tableId);
      const recordData = req.body;
      
      const table = await storage.getBaseTable(tableId);
      if (!table || table.baseId !== req.baseId) {
        return res.status(404).json({ error: 'Table not found' });
      }

      const record = await storage.createTableRecord(tableId, recordData);
      res.json(record);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Delete record
  app.delete("/api/base/tables/:tableId/records/:recordId", authenticateBaseUser, async (req: any, res) => {
    try {
      const tableId = parseInt(req.params.tableId);
      const recordId = parseInt(req.params.recordId);
      
      const table = await storage.getBaseTable(tableId);
      if (!table || table.baseId !== req.baseId) {
        return res.status(404).json({ error: 'Table not found' });
      }

      const success = await storage.deleteTableRecord(tableId, recordId);
      if (success) {
        // Log the deletion
        await storage.createEditLog({
          baseId: req.baseId,
          userId: req.userId,
          tableId,
          recordId,
          action: 'delete',
          fieldName: 'record',
          oldValue: null,
          newValue: null
        });
        
        res.json({ success: true });
      } else {
        res.status(404).json({ error: 'Record not found' });
      }
    } catch (error) {
      console.error('Error deleting record:', error);
      res.status(500).json({ error: 'Failed to delete record' });
    }
  });

  // Session middleware for authenticated routes
  const requireAuth = (req: any, res: any, next: any) => {
    console.log("=== AUTH CHECK ===");
    console.log("Session:", req.session);
    console.log("Session keys:", req.session ? Object.keys(req.session) : 'no session');
    
    // Check if we have a valid session (more flexible check)
    if (!req.session || (!req.session.userId && !req.session.user)) {
      console.log("No valid session found");
      return res.status(401).json({ error: "No session token provided" });
    }
    
    // Set baseId if not already set (for compatibility)
    if (!req.session.baseId && req.session.user && req.session.user.baseId) {
      req.session.baseId = req.session.user.baseId;
    }
    
    console.log("Auth successful, baseId:", req.session.baseId);
    next();
  };

  // Session-based user management routes (for your SSC6 base)
  


  // Get base users for user management  
  app.get("/api/base/users", async (req, res) => {
    try {
      const users = await storage.getBaseUsers(req.session!.baseId);
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching base users:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Create new base user
  app.post("/api/base/users", requireAuth, async (req, res) => {
    try {
      const { name, email, username, password, role } = req.body;
      
      if (!name || !email || !username || !password || !role) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Check if user already exists
      const existingUser = await storage.getBaseUserByEmail(req.session!.baseId, email);
      if (existingUser) {
        return res.status(400).json({ error: "User with this email already exists" });
      }

      // Hash the password (simple base64 encoding for now)
      const hashedPassword = Buffer.from(password).toString('base64');

      const newUser = await storage.createBaseUser({
        baseId: req.session!.baseId,
        name,
        email,
        username,
        password: hashedPassword,
        role,
        isActive: true
      });

      // Remove password from response
      const { password: _, ...userWithoutPassword } = newUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get field permissions for a user
  app.get("/api/base/users/:userId/permissions", requireAuth, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      console.log('=== GET PERMISSIONS DEBUG ===');
      console.log('Looking for:', { baseId: req.session!.baseId, userId, tableId: undefined });
      
      const permissions = await storage.getFieldPermissions(req.session!.baseId, userId);
      console.log('Found permissions:', permissions);
      res.json(permissions);
    } catch (error) {
      console.error('Error fetching permissions:', error);
      res.status(500).json({ error: 'Failed to fetch permissions' });
    }
  });

  // Update field permission
  app.post("/api/base/permissions", requireAuth, async (req, res) => {
    try {
      const { userId, tableId, fieldName, permission } = req.body;
      
      if (!userId || !tableId || !fieldName || !permission) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const permissionData = {
        baseId: req.session!.baseId,
        userId,
        tableId,
        fieldName,
        permission
      };

      const result = await storage.setFieldPermission(permissionData);
      res.json(result);
    } catch (error) {
      console.error('Error updating permission:', error);
      res.status(500).json({ error: 'Failed to update permission' });
    }
  });

  // Get table columns
  app.get("/api/base/tables/:tableId/columns", authenticateBaseUser, async (req: any, res) => {
    try {
      const tableId = parseInt(req.params.tableId);
      const table = await storage.getBaseTable(tableId);
      
      if (!table) {
        return res.status(404).json({ error: 'Table not found' });
      }

      // Extract columns from table schema
      const schema = table.schema as any;
      const columns = schema && typeof schema === 'object' ? Object.keys(schema).map(key => ({
        name: key,
        type: schema[key]
      })) : [];

      res.json(columns);
    } catch (error) {
      console.error('Error fetching columns:', error);
      res.status(500).json({ error: 'Failed to fetch columns' });
    }
  });

  // Add column to table
  app.post("/api/base/tables/:tableId/columns", authenticateBaseUser, async (req: any, res) => {
    try {
      // Check if user has admin privileges
      const currentUser = await storage.getBaseUser(req.userId);
      if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'super_admin')) {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const tableId = parseInt(req.params.tableId);
      const { column } = req.body;

      if (!column || !column.name || !column.type) {
        return res.status(400).json({ error: 'Column name and type are required' });
      }

      // Get current table structure
      const table = await storage.getBaseTable(tableId);
      if (!table) {
        return res.status(404).json({ error: 'Table not found' });
      }

      // For now, just acknowledge the column addition
      // In a real implementation, you'd modify the table schema
      res.json({ success: true, message: 'Column added successfully' });
    } catch (error) {
      console.error('Error adding column:', error);
      res.status(500).json({ error: 'Failed to add column' });
    }
  });

  // Delete column from table
  app.delete("/api/base/tables/:tableId/columns/:columnName", authenticateBaseUser, async (req: any, res) => {
    try {
      // Check if user has admin privileges
      const currentUser = await storage.getBaseUser(req.userId);
      if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'super_admin')) {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const tableId = parseInt(req.params.tableId);
      const columnName = req.params.columnName;

      // Get current table structure
      const table = await storage.getBaseTable(tableId);
      if (!table) {
        return res.status(404).json({ error: 'Table not found' });
      }

      // For now, just acknowledge the column deletion
      // In a real implementation, you'd modify the table schema and data
      res.json({ success: true, message: 'Column deleted successfully' });
    } catch (error) {
      console.error('Error deleting column:', error);
      res.status(500).json({ error: 'Failed to delete column' });
    }
  });

  // Add new record to table
  app.post("/api/base/tables/:tableId/records", authenticateBaseUser, async (req: any, res) => {
    try {
      const tableId = parseInt(req.params.tableId);
      const recordData = req.body;

      // Get current records
      const records = await storage.getTableRecords(tableId);
      
      // Generate new ID
      const newId = Math.max(...records.map(r => r.id || 0), 0) + 1;
      const newRecord = { id: newId, ...recordData };

      // Add the new record
      const updatedRecords = [...records, newRecord];
      await storage.setTableRecords(tableId, updatedRecords);

      // Log the action
      await storage.createEditLog({
        userId: req.userId,
        baseId: req.baseId,
        tableId,
        recordId: newId,
        action: 'create',
        fieldName: 'record',
        newValue: JSON.stringify(recordData)
      });

      res.json(newRecord);
    } catch (error) {
      console.error('Error adding record:', error);
      res.status(500).json({ error: 'Failed to add record' });
    }
  });

  // Reset user password
  app.post("/api/base/users/:userId/reset-password", authenticateBaseUser, async (req: any, res) => {
    try {
      // Check if user has admin privileges
      const currentUser = await storage.getBaseUser(req.userId);
      if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'super_admin')) {
        return res.status(403).json({ error: 'Admin access required' });
      }

      const userId = parseInt(req.params.userId);
      const { newPassword } = req.body;

      if (!newPassword || newPassword.length < 4) {
        return res.status(400).json({ error: 'Password must be at least 4 characters long' });
      }

      // Get the user to verify they exist and belong to the same base
      const targetUser = await storage.getBaseUser(userId);
      if (!targetUser || targetUser.baseId !== req.baseId) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Update the user's password
      const updatedUser = await storage.updateBaseUser(userId, {
        password: newPassword
      });

      if (!updatedUser) {
        return res.status(500).json({ error: 'Failed to update password' });
      }

      res.json({ message: 'Password reset successfully' });
    } catch (error) {
      console.error('Error resetting password:', error);
      res.status(500).json({ error: 'Failed to reset password' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
