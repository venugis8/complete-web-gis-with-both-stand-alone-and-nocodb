import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Add magic link routes before any other middleware
app.get('/api/magic-link/:token', async (req, res) => {
  console.log('=== DIRECT MAGIC LINK ROUTE HIT ===');
  console.log('Token:', req.params.token);
  
  try {
    const { token } = req.params;
    
    // For the demo SSC6 token, simulate using your actual client email
    if (token === 'ssc6demo123') {
      const response = { 
        base: { id: 4, name: 'SSC6' },
        adminEmail: 'ssc6@ppmail.com', // Using your actual client admin email
        token 
      };
      console.log('Sending magic link response:', response);
      return res.json(response);
    }
    
    // Handle SSC5 demo token
    if (token === 'ssc5demo123') {
      const response = { 
        base: { id: 3, name: 'SSC5' },
        adminEmail: 'admin@ssc5demo.com',
        token 
      };
      console.log('Sending magic link response:', response);
      return res.json(response);
    }
    
    console.log('Invalid token:', token);
    return res.status(404).json({ error: 'Invalid magic link' });
  } catch (error: any) {
    console.error('Magic link error:', error);
    res.status(500).json({ error: 'Failed to validate magic link', details: error.message });
  }
});

app.post('/api/admin-setup', async (req, res) => {
  console.log('=== ADMIN SETUP ROUTE HIT ===');
  console.log('Body:', req.body);
  
  try {
    const { token, name, password } = req.body;
    
    // Handle your test tokens
    if (token === 'ssc5demo123' || token === 'ssc6demo123') {
      const baseId = token.includes('ssc5') ? 3 : 4;
      // Use the same email from the magic link validation
      const adminEmail = token.includes('ssc5') ? 'admin@ssc5demo.com' : 'ssc6@ppmail.com';
      
      // Hash the password (simple hash for demo - in production use bcrypt)
      const hashedPassword = Buffer.from(password).toString('base64');
      
      const adminUser = {
        id: Date.now(),
        username: adminEmail,
        email: adminEmail,
        password: hashedPassword,
        name,
        role: 'admin',
        baseId,
        createdAt: new Date()
      };
      
      const sessionToken = 'session_' + Math.random().toString(36);
      
      // Store the admin user in the system (for demo using in-memory storage)
      // In production, this would use proper database storage
      console.log('Creating admin user in system:', adminUser);
      
      // Create the base user record so they can login
      const { storage } = await import('./storage');
      const baseUser = await storage.createBaseUser({
        baseId: baseId,
        username: adminEmail,
        email: adminEmail,
        password: hashedPassword,
        name: name,
        role: 'admin',
        isActive: true
      });
      
      console.log('Base user created:', baseUser);
      
      console.log('Admin setup successful:', { adminUser, sessionToken });
      res.json({ 
        user: adminUser,
        sessionToken: sessionToken,
        baseId: baseId
      });
      return;
    }
    
    res.status(400).json({ error: 'Invalid token' });
  } catch (error: any) {
    console.error('Admin setup error:', error);
    res.status(500).json({ error: 'Failed to setup admin account', details: error.message });
  }
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
