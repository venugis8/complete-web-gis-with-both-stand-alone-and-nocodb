#!/bin/bash

# GIS SaaS Platform Deployment Script for Linode
# This script automates the deployment process on a fresh Ubuntu server

set -e

echo "🚀 Starting GIS SaaS Platform deployment..."

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo "❌ This script should not be run as root. Please run as a regular user with sudo privileges."
   exit 1
fi

# Update system
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Docker
echo "🐳 Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    echo "✅ Docker installed successfully"
else
    echo "✅ Docker already installed"
fi

# Install Docker Compose
echo "📋 Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    echo "✅ Docker Compose installed successfully"
else
    echo "✅ Docker Compose already installed"
fi

# Create application directory
echo "📁 Creating application directory..."
sudo mkdir -p /opt/gis-saas
sudo chown $USER:$USER /opt/gis-saas
cd /opt/gis-saas

# Clone repository (update with your actual repository URL)
echo "📥 Cloning repository..."
if [ ! -d ".git" ]; then
    read -p "Enter your Git repository URL: " REPO_URL
    git clone $REPO_URL .
else
    echo "✅ Repository already exists, pulling latest changes..."
    git pull origin main
fi

# Create environment file
echo "⚙️  Configuring environment..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    
    # Generate secure secrets
    POSTGRES_PASSWORD=$(openssl rand -base64 32)
    SESSION_SECRET=$(openssl rand -base64 64)
    
    # Update .env file
    sed -i "s/your_secure_password/$POSTGRES_PASSWORD/" .env
    sed -i "s/your-very-secure-session-secret-here/$SESSION_SECRET/" .env
    sed -i "s/NODE_ENV=development/NODE_ENV=production/" .env
    
    echo "✅ Environment configured with secure passwords"
    echo "📝 Please review and update .env file with your specific settings"
else
    echo "✅ Environment file already exists"
fi

# Create data directories
echo "📂 Creating data directories..."
sudo mkdir -p /var/lib/app/data
sudo mkdir -p /var/lib/app/uploads
sudo chown -R 1000:1000 /var/lib/app

# Set up firewall
echo "🔥 Configuring firewall..."
sudo ufw --force enable
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
echo "✅ Firewall configured"

# Start services
echo "🎯 Starting services..."
export POSTGRES_PASSWORD=$(grep POSTGRES_PASSWORD .env | cut -d '=' -f2)
export SESSION_SECRET=$(grep SESSION_SECRET .env | cut -d '=' -f2)

docker-compose up -d

# Wait for services to start
echo "⏳ Waiting for services to start..."
sleep 30

# Check if services are running
echo "🔍 Checking service status..."
docker-compose ps

# Initialize database
echo "🗄️  Initializing database..."
sleep 10
docker-compose exec -T app npm run db:push || echo "⚠️  Database initialization may need manual intervention"

# Display deployment information
echo ""
echo "🎉 Deployment completed successfully!"
echo ""
echo "📋 Deployment Summary:"
echo "========================"
echo "Application URL: http://$(curl -s ifconfig.me)"
echo "Data Directory: /var/lib/app/data"
echo "Uploads Directory: /var/lib/app/uploads"
echo "Configuration: /opt/gis-saas/.env"
echo ""
echo "🔧 Next Steps:"
echo "1. Configure your domain DNS to point to this server"
echo "2. Set up SSL certificate using certbot"
echo "3. Review and customize .env settings"
echo "4. Create your first super admin account"
echo ""
echo "📊 Monitor your deployment:"
echo "docker-compose logs -f app"
echo "docker-compose ps"
echo ""
echo "🔒 Security Note:"
echo "Your database password and session secret have been automatically generated."
echo "Keep your .env file secure and backed up."