#!/bin/bash

# GitHub-based deployment script for Linode server
# This script will be used once GitHub access is granted

REPO_URL="https://github.com/venugis8/replit-nocodb-webgis-team1.git"
DEPLOY_DIR="/opt/nocodb-gis"
APP_NAME="nocodb-gis-platform"

echo "Starting deployment from GitHub..."

# Navigate to deployment directory
cd $DEPLOY_DIR

# Pull latest changes from GitHub
echo "Pulling latest code from GitHub..."
git remote add origin $REPO_URL 2>/dev/null || true
git fetch origin main
git reset --hard origin/main

# Install dependencies
echo "Installing dependencies..."
npm install --production

# Copy environment file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating environment file..."
    cp .env.example .env
    echo "Please configure .env file with your database credentials"
fi

# Set up database (if configured)
if [ -f .env ]; then
    echo "Setting up database..."
    npm run db:push 2>/dev/null || echo "Database setup skipped - configure .env first"
fi

# Stop existing PM2 process
echo "Stopping existing processes..."
pm2 stop $APP_NAME 2>/dev/null || true
pm2 delete $APP_NAME 2>/dev/null || true

# Start application with PM2
echo "Starting application..."
pm2 start ecosystem.config.js --name $APP_NAME
pm2 save

# Reload Nginx configuration
echo "Reloading Nginx..."
nginx -s reload 2>/dev/null || true

echo "Deployment completed successfully!"
echo "Application is running on PM2 as '$APP_NAME'"
echo "Check status: pm2 status"
echo "View logs: pm2 logs $APP_NAME"