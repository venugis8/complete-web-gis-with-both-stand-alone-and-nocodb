#!/bin/bash

# Complete Team 2 Standalone GIS System Deployment Script for Fresh Linode Instance
# This script installs all dependencies and deploys the system in one go

set -e  # Exit on any error

echo "=============================================="
echo "Team 2 Standalone GIS System Deployment"
echo "=============================================="
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "Please run this script as root (use sudo)"
    exit 1
fi

print_header "STEP 1: SYSTEM UPDATE AND BASIC PACKAGES"

print_status "Updating system packages..."
apt update && apt upgrade -y

print_status "Installing essential packages..."
apt install -y curl wget git vim nano htop unzip build-essential software-properties-common

print_header "STEP 2: POSTGRESQL WITH POSTGIS INSTALLATION"

print_status "Installing PostgreSQL and PostGIS..."
apt install -y postgresql postgresql-contrib postgresql-14-postgis-3 postgresql-14-postgis-3-scripts

print_status "Starting PostgreSQL service..."
systemctl start postgresql
systemctl enable postgresql

print_status "Setting up PostgreSQL user and database..."
sudo -u postgres psql << 'EOSQL'
CREATE USER gisuser WITH PASSWORD 'gispassword123';
CREATE DATABASE gisdb OWNER gisuser;
\c gisdb;
CREATE EXTENSION postgis;
CREATE EXTENSION postgis_topology;
GRANT ALL PRIVILEGES ON DATABASE gisdb TO gisuser;
EOSQL

print_status "PostgreSQL with PostGIS installed successfully"

print_header "STEP 3: NODE.JS INSTALLATION"

print_status "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

print_status "Node.js version: $(node --version)"
print_status "NPM version: $(npm --version)"

print_header "STEP 4: PM2 PROCESS MANAGER INSTALLATION"

print_status "Installing PM2 globally..."
npm install -g pm2

print_status "Setting up PM2 startup script..."
pm2 startup
env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u root --hp /root

print_header "STEP 5: FIREWALL CONFIGURATION"

print_status "Configuring UFW firewall..."
ufw --force enable
ufw allow ssh
ufw allow 80
ufw allow 443
ufw allow 5002  # Team 2 standalone port

print_header "STEP 6: FILE UPLOAD PREPARATION"

print_status "Creating deployment directory..."
mkdir -p /opt/team2-gis
cd /opt/team2-gis

print_warning "=========================================="
print_warning "UPLOAD REQUIRED: team2_standalone_FULL_master_button_working_20250603.tar.gz"
print_warning "=========================================="
echo ""
echo -e "${YELLOW}Please upload the file:${NC} team2_standalone_FULL_master_button_working_20250603.tar.gz"
echo -e "${YELLOW}To directory:${NC} /opt/team2-gis/"
echo ""
echo -e "${YELLOW}Use WinSCP or your preferred method to upload the file.${NC}"
echo ""
echo -e "${BLUE}Upload location: /opt/team2-gis/team2_standalone_FULL_master_button_working_20250603.tar.gz${NC}"
echo ""
read -p "Press ENTER after uploading the file to continue..."

# Verify file exists
if [ ! -f "/opt/team2-gis/team2_standalone_FULL_master_button_working_20250603.tar.gz" ]; then
    print_error "File not found! Please upload the file first."
    exit 1
fi

print_header "STEP 7: EXTRACTING AND SETTING UP APPLICATION"

print_status "Extracting application files..."
tar -xzf team2_standalone_FULL_master_button_working_20250603.tar.gz

print_status "Moving application to proper location..."
mv mapz_standalone_clean/* /opt/team2-gis/
rm -rf mapz_standalone_clean
rm team2_standalone_FULL_master_button_working_20250603.tar.gz

print_status "Setting up directory permissions..."
chown -R root:root /opt/team2-gis
chmod -R 755 /opt/team2-gis

print_header "STEP 8: ENVIRONMENT CONFIGURATION"

print_status "Creating environment configuration..."
cat > /opt/team2-gis/.env << 'EOF'
NODE_ENV=production
PORT=5002
DATABASE_URL=postgresql://gisuser:gispassword123@localhost:5432/gisdb
PGUSER=gisuser
PGPASSWORD=gispassword123
PGDATABASE=gisdb
PGHOST=localhost
PGPORT=5432
EOF

print_header "STEP 9: INSTALLING APPLICATION DEPENDENCIES"

print_status "Installing Node.js dependencies..."
cd /opt/team2-gis
npm install --production

print_header "STEP 10: DATABASE SETUP"

print_status "Running database migrations/setup..."
# Check if there are any database setup scripts
if [ -f "drizzle.config.ts" ]; then
    npm run db:push 2>/dev/null || print_warning "No database push script found"
fi

print_header "STEP 11: PM2 APPLICATION SETUP"

print_status "Creating PM2 ecosystem configuration..."
cat > /opt/team2-gis/ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'team2-standalone-gis',
    script: './server/index.ts',
    cwd: '/opt/team2-gis',
    env: {
      NODE_ENV: 'production',
      PORT: 5002
    },
    interpreter: 'node',
    interpreter_args: '--loader=tsx',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: './logs/error.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
EOF

print_status "Creating logs directory..."
mkdir -p /opt/team2-gis/logs

print_status "Installing tsx for TypeScript execution..."
npm install -g tsx

print_header "STEP 12: STARTING THE APPLICATION"

print_status "Starting application with PM2..."
cd /opt/team2-gis
pm2 start ecosystem.config.js

print_status "Saving PM2 configuration..."
pm2 save

print_header "STEP 13: NGINX REVERSE PROXY SETUP"

print_status "Installing and configuring Nginx..."
apt install -y nginx

print_status "Creating Nginx configuration..."
cat > /etc/nginx/sites-available/team2-gis << 'EOF'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://localhost:5002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
}
EOF

print_status "Enabling Nginx site..."
ln -sf /etc/nginx/sites-available/team2-gis /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

print_status "Testing Nginx configuration..."
nginx -t

print_status "Starting Nginx..."
systemctl restart nginx
systemctl enable nginx

print_header "STEP 14: FINAL VERIFICATION"

print_status "Checking application status..."
pm2 status

print_status "Checking if application is responding..."
sleep 5
if curl -f http://localhost:5002 > /dev/null 2>&1; then
    print_status "Application is responding on port 5002"
else
    print_warning "Application may not be responding yet, check logs with: pm2 logs"
fi

print_status "Checking Nginx status..."
systemctl status nginx --no-pager

print_header "DEPLOYMENT COMPLETE!"

echo ""
print_status "Team 2 Standalone GIS System has been deployed successfully!"
echo ""
echo -e "${GREEN}Access your application at:${NC}"
echo -e "${BLUE}http://$(curl -s ifconfig.me)${NC} (External IP)"
echo -e "${BLUE}http://localhost:5002${NC} (Direct application access)"
echo ""
echo -e "${GREEN}System Information:${NC}"
echo -e "Application Directory: /opt/team2-gis"
echo -e "Database: PostgreSQL with PostGIS"
echo -e "Database Name: gisdb"
echo -e "Database User: gisuser"
echo -e "Process Manager: PM2"
echo -e "Web Server: Nginx"
echo ""
echo -e "${GREEN}Useful Commands:${NC}"
echo -e "pm2 status                 - Check application status"
echo -e "pm2 logs team2-standalone-gis  - View application logs"
echo -e "pm2 restart team2-standalone-gis  - Restart application"
echo -e "systemctl status nginx     - Check Nginx status"
echo -e "systemctl status postgresql - Check PostgreSQL status"
echo ""
echo -e "${GREEN}Next Steps:${NC}"
echo -e "1. Access the application via web browser"
echo -e "2. Configure any additional settings as needed"
echo -e "3. Set up SSL certificate if required (Let's Encrypt recommended)"
echo ""
print_status "Deployment completed successfully!"