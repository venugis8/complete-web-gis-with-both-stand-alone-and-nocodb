# Team 2 Standalone GIS System - Complete Documentation

## 1. Complete Architecture Overview

### System Architecture
The Team 2 Standalone GIS system is a full-stack web application designed for geospatial data management with the following architecture:

**Frontend Layer:**
- React 18 with TypeScript for type safety
- Vite for fast development and optimized production builds
- Tailwind CSS with shadcn/ui components for modern UI
- Leaflet.js for interactive map rendering and geospatial visualization
- React Query (TanStack Query) for efficient data fetching and caching
- Wouter for lightweight client-side routing

**Backend Layer:**
- Express.js server with TypeScript
- RESTful API architecture for data operations
- Session-based authentication with PostgreSQL storage
- Drizzle ORM for type-safe database operations
- Express middleware for JSON parsing and static file serving

**Database Layer:**
- PostgreSQL 16 with PostGIS extensions for spatial data
- Structured schema for bases, users, permissions, and geospatial data
- Connection pooling for optimal performance
- ACID compliance for data integrity

**Infrastructure Layer:**
- Ubuntu 24.04 LTS server environment
- Nginx reverse proxy for production deployment
- PM2 process manager for application lifecycle
- Node.js 20 runtime environment

### Data Flow
1. Client requests → Nginx → Express.js server
2. API calls → Authentication middleware → Route handlers
3. Database operations → Drizzle ORM → PostgreSQL
4. Geospatial queries → PostGIS functions → Leaflet frontend
5. Static assets served directly by Nginx

## 2. Complete Software Stack and Dependencies

### System Software
- **Operating System:** Ubuntu 24.04 LTS
- **Node.js:** Version 20.x LTS
- **PostgreSQL:** Version 16.9 with PostGIS 3.4
- **Nginx:** Version 1.24+ (reverse proxy)
- **PM2:** Version 5.x (process manager)

### Core Dependencies
```json
{
  "runtime": {
    "express": "^5.0.0",
    "pg": "^8.11.0",
    "@neondatabase/serverless": "^0.9.0",
    "drizzle-orm": "^0.30.0",
    "bcrypt": "^5.1.0",
    "express-session": "^1.18.0",
    "connect-pg-simple": "^9.0.0"
  },
  "frontend": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "leaflet": "^1.9.4",
    "react-hook-form": "^7.45.0",
    "@tanstack/react-query": "^5.0.0",
    "wouter": "^3.0.0",
    "lucide-react": "^0.400.0"
  },
  "ui_framework": {
    "tailwindcss": "^3.4.0",
    "@radix-ui/react-*": "^1.0.0",
    "tailwindcss-animate": "^1.0.7",
    "class-variance-authority": "^0.7.0"
  },
  "development": {
    "typescript": "^5.0.0",
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.0.0",
    "tsx": "^4.0.0",
    "drizzle-kit": "^0.20.0"
  }
}
```

### System Services
- **PostgreSQL Service:** `postgresql.service`
- **Nginx Service:** `nginx.service`
- **PM2 Startup:** Auto-start on system boot
- **Node.js Application:** Managed by PM2 as `team2-standalone-gis`

## 3. Deployment Instructions

### Prerequisites
- Fresh Ubuntu 24.04 LTS server
- Root access or sudo privileges
- Domain name or IP address for external access

### Step 1: System Preparation
```bash
# Update system packages
apt update && apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
apt-get install -y nodejs

# Install PostgreSQL with PostGIS
apt install -y postgresql postgresql-contrib postgis

# Install Nginx and PM2
apt install -y nginx
npm install -g pm2
```

### Step 2: Database Setup
```bash
# Switch to postgres user
sudo -u postgres psql

-- Create database and user
CREATE USER gisuser WITH PASSWORD 'gispassword123';
CREATE DATABASE gisdb OWNER gisuser;
GRANT ALL PRIVILEGES ON DATABASE gisdb TO gisuser;

-- Enable PostGIS extension
\c gisdb
CREATE EXTENSION postgis;
CREATE EXTENSION postgis_topology;

-- Create application tables
CREATE TABLE bases (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  subdomain TEXT NOT NULL UNIQUE,
  system_mode TEXT NOT NULL DEFAULT 'standalone',
  deployment_type TEXT NOT NULL DEFAULT 'basic',
  db_path TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW() NOT NULL
);
```

### Step 3: Application Deployment
```bash
# Create application directory
mkdir -p /opt/team2-gis
cd /opt/team2-gis

# Upload application files (dist folder and server files)
# Configure environment variables
cat > .env << EOF
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
DATABASE_URL=postgresql://gisuser:gispassword123@localhost:5432/gisdb
EOF

# Start application with PM2
pm2 start production_server.cjs --name "team2-standalone-gis"
pm2 save
pm2 startup
```

### Step 4: Nginx Configuration
```bash
# Create Nginx site configuration
cat > /etc/nginx/sites-available/team2-gis << EOF
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable site and restart Nginx
ln -s /etc/nginx/sites-available/team2-gis /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

### Step 5: Security Configuration
```bash
# Configure firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# Set up SSL (optional but recommended)
certbot --nginx -d your-domain.com
```

## 4. Knowledge Transfer Summary for Development Team

### System Overview
The Team 2 Standalone GIS system is a modern, scalable web application for geospatial data management. It provides a complete solution for organizations needing to manage spatial data with user authentication, role-based permissions, and interactive mapping capabilities.

### Key Technologies Understanding

**Frontend Development:**
- Built with React 18 and TypeScript for type safety and modern development practices
- Uses Vite for lightning-fast development and optimized production builds
- Tailwind CSS with shadcn/ui provides consistent, accessible component library
- Leaflet.js handles all mapping functionality including markers, polygons, and spatial analysis
- React Query manages server state with automatic caching and synchronization

**Backend Development:**
- Express.js provides RESTful API endpoints with middleware architecture
- Drizzle ORM offers type-safe database operations with migration support
- PostgreSQL with PostGIS handles both relational and spatial data efficiently
- Session-based authentication with secure password hashing using bcrypt

**Database Schema:**
- `bases` table: Core tenant/organization data
- `users` table: Authentication and user management
- `permissions` table: Role-based access control
- Spatial tables: Geographic data with PostGIS geometry types

### Development Workflow

**Local Development:**
```bash
npm install          # Install dependencies
npm run dev         # Start development server
npm run build       # Build for production
npm run db:generate # Generate database migrations
npm run db:push     # Apply migrations
```

**Key Files and Directories:**
- `/client/` - React frontend application
- `/server/` - Express.js backend API
- `/shared/` - Shared TypeScript types and schemas
- `/dist/` - Production build output
- `drizzle.config.ts` - Database configuration
- `vite.config.ts` - Frontend build configuration

### Authentication System
- Email/password authentication with session management
- Default super admin: `ssc6@ppmail.com` / `mypassword123`
- Sessions stored in PostgreSQL for persistence
- Role-based access control for different user types

### API Endpoints
- `GET /api/super-admin/bases` - List all bases/tenants
- `POST /api/super-admin/bases` - Create new base/tenant
- `POST /api/auth/login` - User authentication
- `GET /api/auth/logout` - Session termination

### Deployment Considerations
- Application runs on port 5000 internally
- Nginx reverse proxy handles external traffic on port 80/443
- PM2 manages application lifecycle with auto-restart
- Database connection pooling prevents connection exhaustion
- Environment variables control configuration between environments

### Monitoring and Maintenance
- PM2 provides application monitoring: `pm2 monit`
- Application logs: `pm2 logs team2-standalone-gis`
- Database monitoring through PostgreSQL system views
- Nginx access logs: `/var/log/nginx/access.log`

### Scaling Considerations
- Horizontal scaling possible with load balancer and multiple app instances
- Database read replicas can be added for read-heavy workloads
- CDN integration possible for static asset delivery
- Redis can be added for session storage in multi-instance deployments

### Security Best Practices
- All passwords hashed with bcrypt
- SQL injection protection through parameterized queries
- HTTPS recommended for production deployments
- Regular security updates for all system dependencies
- Database backups scheduled and tested regularly

### Common Issues and Solutions
- Database connection errors: Check DATABASE_URL environment variable
- Static file serving issues: Verify dist/public directory structure
- Authentication failures: Confirm session storage configuration
- Map loading problems: Check Leaflet CSS and JavaScript inclusion

This system provides a solid foundation for geospatial applications and can be extended with additional features like advanced spatial analysis, real-time data streaming, or integration with external GIS services.