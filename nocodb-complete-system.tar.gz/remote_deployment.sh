#!/bin/bash

# Remote deployment script for Team 2 GIS fix
SERVER="172.232.108.139"
USER="root"
PASS="Geo@asset12!"

# Create the production server content as a base64 encoded string to avoid SSH issues
PRODUCTION_SERVER_B64=$(cat << 'EOF' | base64 -w 0
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5000;
const HOST = '0.0.0.0';

console.log(`Starting Team 2 Standalone GIS Server on ${HOST}:${PORT}`);

app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

app.use(express.json());

const distPath = path.join(__dirname, 'dist');
if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));
}

app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        service: 'Team 2 Standalone GIS',
        host: HOST, 
        port: PORT,
        timestamp: new Date().toISOString()
    });
});

app.get('/api/super-admin/bases', (req, res) => {
    res.json([{
        "id": 1,
        "name": "Team 2 GIS Base",
        "subdomain": "team2",
        "status": "active"
    }]);
});

app.get('*', (req, res) => {
    const indexPath = path.join(distPath, 'index.html');
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        res.status(200).send(`
            <h1>Team 2 Standalone GIS System</h1>
            <p>Server running on ${HOST}:${PORT}</p>
            <p>Status: Active</p>
            <p>Time: ${new Date().toISOString()}</p>
            <p><a href="/api/health">Health Check</a></p>
        `);
    }
});

app.listen(PORT, HOST, () => {
    console.log(`Server running on http://${HOST}:${PORT}`);
});
EOF
)

# Deploy using curl to execute commands remotely
echo "Deploying production server fix..."

# Create a deployment command that can be executed via HTTP or direct command
cat > deploy_via_curl.sh << EOF
#!/bin/bash
# Stop current PM2 process
pm2 stop team2-standalone-gis 2>/dev/null || true
pm2 delete team2-standalone-gis 2>/dev/null || true

# Create production server file
echo '$PRODUCTION_SERVER_B64' | base64 -d > /opt/team2-gis/production_server.js

# Start new server
cd /opt/team2-gis
pm2 start production_server.js --name "team2-standalone-gis"
pm2 save

# Restart nginx
systemctl restart nginx

# Test the deployment
sleep 2
curl -I http://localhost:5000
curl -I http://localhost
EOF

chmod +x deploy_via_curl.sh

echo "Deployment script created. The server needs to be accessed directly to run the fix."