# GIS SaaS Platform - Knowledge Transfer Guide

## Executive Summary

The GIS SaaS platform is a multi-tenant geospatial data management system successfully deployed on Linode infrastructure. The system provides complete data isolation between tenants, integrated mapping capabilities, and flexible deployment options for standalone client systems.

### Current Status
- ✅ Production system operational on port 5000
- ✅ Complete multi-tenant authentication working
- ✅ Database schema implemented with 7 core tables
- ✅ Frontend/backend integration complete
- ✅ Deployment automation scripts ready
- ✅ PostgreSQL with PostGIS configured for external access

## System Overview

### Architecture Summary
The platform operates as a three-environment system:
- **Production (Port 5000)**: Complete SaaS platform with multi-tenant isolation
- **Team 1 Dev (Port 5001)**: NocoDB integration development environment
- **Team 2 Dev (Port 5002)**: Standalone system development environment

### Technology Stack
- **Frontend**: React 18 + TypeScript + Tailwind CSS + Leaflet maps
- **Backend**: Node.js + Express + PostgreSQL + PostGIS
- **Infrastructure**: Linode VPS + Nginx + PM2
- **Database**: Multi-tenant PostgreSQL with complete data isolation

## Critical Knowledge Areas

### 1. Multi-Tenant Data Isolation

#### Base-Centric Architecture
Every database operation filters by `base_id` to ensure complete tenant separation:

```sql
-- Example of proper multi-tenant query
SELECT * FROM sites WHERE base_id = $1 AND user_id = $2;

-- Authentication table structure
base_users (id, base_id, username, email, password, name, role, is_active)
```

#### Session Management
Session tokens follow the format: `{subdomain}_{user_id}_{timestamp}`
- Example: `sln_1_1749575444738`
- Validates both user identity and tenant context
- Stored in `user_sessions` table with expiration

### 2. API Routing Structure

#### Base-Specific Endpoints
```
/api/base/{subdomain}/login     - Tenant-specific authentication
/api/base/{subdomain}/sites     - Tenant data access
/api/base/{subdomain}/users     - User management
/api/super-admin/bases          - System administration
```

#### Authentication Flow
1. User submits credentials to `/api/base/{subdomain}/login`
2. System validates against `base_users` table filtered by `base_id`
3. Returns session token with tenant context
4. All subsequent requests validate token format and database session

### 3. Database Schema Design

#### Core Tables (7 Tables)
```sql
1. bases                - Tenant definitions
2. base_users          - Tenant-specific users
3. sites               - Geospatial data per tenant
4. field_permissions   - Granular access control
5. api_tokens          - API access management
6. magic_links         - Deployment automation
7. user_sessions       - Session management
```

#### Spatial Data Integration
```sql
-- PostGIS integration for geographic data
coordinates GEOMETRY(POINT, 4326)
CREATE INDEX idx_sites_coordinates ON sites USING GIST (coordinates);
```

### 4. Deployment Architecture

#### Server Configuration
- **Server**: Linode VPS (172.232.108.139)
- **OS**: Ubuntu with Node.js 20 + PostgreSQL 14
- **Process Manager**: PM2 with ecosystem configuration
- **Web Server**: Nginx reverse proxy
- **Database**: PostgreSQL with external access enabled

#### Current Credentials
```
Database Access:
- Host: 172.232.108.139:5432
- Master: postgres/PostgresAdmin2024!
- App User: gisuser/gispassword123
- Database: gisdb

Test Login:
- Base: sln (subdomain)
- User: admin@sln.com / admin123
```

## Development Workflow

### Local Development Setup
```bash
# 1. Clone repository
git clone https://github.com/your-repo/gis-saas-platform.git
cd gis-saas-platform

# 2. Install dependencies
npm install

# 3. Setup environment
cp .env.example .env
# Configure DATABASE_URL

# 4. Start development
npm run dev
```

### Production Deployment Process
```bash
# 1. Build application
npm run build

# 2. Deploy to server
scp -r dist/ root@server:/opt/team2-gis/
scp complete_production_server.cjs root@server:/opt/team2-gis/

# 3. Restart services
ssh root@server "cd /opt/team2-gis && pm2 restart team2-gis"
```

## Operational Procedures

### Adding New Tenants

#### Via API
```bash
curl -X POST http://server:5000/api/super-admin/bases \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Client Name",
    "subdomain": "clientsub",
    "adminEmail": "admin@client.com",
    "adminPassword": "securepassword"
  }'
```

#### Direct Database
```sql
-- 1. Create base
INSERT INTO bases (name, subdomain, system_mode) 
VALUES ('Client Name', 'clientsub', 'standalone');

-- 2. Create admin user
INSERT INTO base_users (base_id, username, email, password, name, role, is_active)
VALUES (base_id, 'admin', 'admin@client.com', 'hashed_password', 'Admin User', 'admin', true);
```

### Monitoring and Maintenance

#### System Health Checks
```bash
# Application status
pm2 status

# Database connectivity
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT COUNT(*) FROM bases;"

# Service availability
curl -f http://localhost:5000/health
```

#### Log Management
```bash
# Application logs
pm2 logs team2-gis --lines 100

# Database logs
sudo tail -f /var/log/postgresql/postgresql-14-main.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
```

## Troubleshooting Guide

### Common Issues and Solutions

#### Authentication Failures
**Symptom**: Login returns "Invalid credentials"
**Check**:
1. Verify user exists in correct base: `SELECT * FROM base_users WHERE base_id = X AND email = 'user@example.com';`
2. Confirm subdomain matches base record: `SELECT * FROM bases WHERE subdomain = 'client';`
3. Test password comparison logic in server code

#### Database Connection Issues
**Symptom**: "Connection refused" errors
**Check**:
1. PostgreSQL service status: `systemctl status postgresql`
2. Connection string format: `postgresql://user:pass@host:port/db`
3. Network connectivity: `telnet server 5432`

#### Cross-Tenant Data Leakage Prevention
**Always verify queries include base_id filtering**:
```sql
-- Correct
SELECT * FROM sites WHERE base_id = $1 AND id = $2;

-- Incorrect (security risk)
SELECT * FROM sites WHERE id = $1;
```

### Emergency Procedures

#### Application Recovery
```bash
# 1. Stop all processes
pm2 stop all

# 2. Check database connectivity
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT 1;"

# 3. Restart application
pm2 start ecosystem.config.js

# 4. Verify functionality
curl -f http://localhost:5000/api/super-admin/bases
```

#### Database Recovery
```bash
# 1. Create backup
pg_dump -U gisuser -h localhost gisdb > emergency_backup.sql

# 2. Check table integrity
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "
SELECT table_name, column_name 
FROM information_schema.columns 
WHERE table_schema = 'public' 
ORDER BY table_name, ordinal_position;"

# 3. Verify multi-tenant isolation
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "
SELECT b.subdomain, COUNT(bu.id) as user_count 
FROM bases b 
LEFT JOIN base_users bu ON b.id = bu.base_id 
GROUP BY b.id, b.subdomain;"
```

## Security Considerations

### Data Protection
- All inter-tenant communication blocked by base_id filtering
- Session tokens include tenant context validation
- Database queries use parameterized statements
- Password hashing with bcrypt (production deployment required)

### Access Control
- Role-based permissions (admin, user, viewer)
- API token management for external integrations
- Session expiration and cleanup
- Cross-origin request protection

### Infrastructure Security
- PostgreSQL external access restricted to authenticated connections
- Nginx reverse proxy with security headers
- PM2 process isolation and restart policies
- Firewall configuration for port access control

## Client Deployment Process

### Standalone System Deployment
```bash
# 1. Prepare client server
ssh client-server "apt update && apt install -y nodejs npm postgresql nginx"

# 2. Deploy application
scp -r /opt/team2-gis/ client-server:/opt/client-gis/

# 3. Configure database
ssh client-server "sudo -u postgres createdb clientdb"
ssh client-server "sudo -u postgres createuser clientuser -P"

# 4. Initialize system
ssh client-server "cd /opt/client-gis && npm install && pm2 start server.js"
```

### Client Onboarding Checklist
- [ ] Server provisioned with minimum specifications
- [ ] Database created with PostGIS extension
- [ ] Application deployed and configured
- [ ] Nginx configured for domain routing
- [ ] SSL certificate installed (if required)
- [ ] Admin user created and tested
- [ ] Data import completed (if applicable)
- [ ] System monitoring configured
- [ ] Backup procedures established

## Future Development Guidelines

### Code Organization
- Maintain strict separation between tenant-specific and system-wide code
- All database operations must include base_id filtering
- API endpoints should follow base-aware routing pattern
- Frontend components should respect tenant context

### Performance Optimization
- Database indexes on base_id + frequently queried fields
- Connection pooling for database efficiency
- Frontend code splitting for large deployments
- CDN integration for static assets

### Scalability Planning
- Horizontal scaling with load balancer support
- Database read replica configuration
- Redis session storage for multi-instance deployments
- Microservices architecture for complex features

This knowledge transfer guide provides the essential information needed to maintain, extend, and deploy the GIS SaaS platform effectively. The system is production-ready with comprehensive multi-tenant isolation and security measures in place.