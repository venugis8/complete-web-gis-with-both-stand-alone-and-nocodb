# Complete System Architecture & Knowledge Transfer

## System Overview

**Deployed Location**: Linode Server (172.232.108.139)  
**Application Path**: `/opt/team2-gis`  
**Port**: 5000  
**Status**: Production Ready

## Database Credentials

### PostgreSQL Master Access
- **Host**: 172.232.108.139
- **Port**: 5432
- **Master User**: postgres
- **Master Password**: PostgresAdmin2024!
- **Database**: gisdb

### Application Database Access
- **User**: gisuser
- **Password**: gispassword123
- **Database**: gisdb
- **Connection String**: `postgresql://gisuser:gispassword123@localhost:5432/gisdb`

### External Access Commands
```bash
# Connect via psql from external machine
PGPASSWORD=PostgresAdmin2024! psql -h 172.232.108.139 -U postgres -d gisdb

# Application user access
PGPASSWORD=gispassword123 psql -h 172.232.108.139 -U gisuser -d gisdb

# pgAdmin Connection
Host: 172.232.108.139
Port: 5432
Username: postgres
Password: PostgresAdmin2024!
```

## Complete Folder Structure

```
/opt/team2-gis/
├── client/                          # React Frontend
│   ├── index.html                   # Main HTML template
│   └── src/                         # React source code
│       ├── components/              # Reusable UI components
│       │   ├── ui/                  # shadcn/ui components
│       │   ├── forms/               # Form components
│       │   ├── maps/                # Map-related components
│       │   └── layout/              # Layout components
│       ├── pages/                   # Route components
│       ├── hooks/                   # Custom React hooks
│       ├── lib/                     # Utility functions
│       ├── App.tsx                  # Main application component
│       ├── main.tsx                 # React entry point
│       └── index.css                # Global styles
├── server/                          # Backend Server
│   ├── index.ts                     # Main server entry point
│   ├── routes.ts                    # API route definitions
│   ├── storage.ts                   # Data access layer
│   ├── db.ts                        # Database configuration
│   ├── vite.ts                      # Vite integration
│   └── public/                      # Static assets
├── shared/                          # Shared Types & Schema
│   └── schema.ts                    # Database schema definitions
├── node_modules/                    # Dependencies
├── package.json                     # Project configuration
├── package-lock.json                # Dependency lock file
├── tsconfig.json                    # TypeScript configuration
├── vite.config.ts                   # Vite build configuration
├── tailwind.config.ts               # Tailwind CSS configuration
├── drizzle.config.ts                # Database ORM configuration
├── components.json                  # shadcn/ui configuration
├── postcss.config.js                # PostCSS configuration
├── .env                             # Environment variables
└── README.md                        # Project documentation
```

## Database Schema

### Core Tables
```sql
-- Tenant Management
bases (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    subdomain VARCHAR(100) UNIQUE,
    custom_domain VARCHAR(255),
    db_path VARCHAR(255),
    status VARCHAR(50),
    settings JSONB,
    system_mode VARCHAR(50),
    deployment_type VARCHAR(50),
    nocodb_base_id TEXT,
    nocodb_url TEXT,
    nocodb_api_key TEXT,
    nocodb_admin_email TEXT,
    nocodb_admin_password TEXT,
    sites_table_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Management
users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    name VARCHAR(255),
    role VARCHAR(50),
    is_active BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Session Management
user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    session_token VARCHAR(255) UNIQUE,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Site Data (Geospatial)
sites (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    location TEXT,
    coordinates GEOMETRY(POINT, 4326),
    properties JSONB,
    user_id INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Technology Stack

### Frontend
- **Framework**: React 18.3.1 with TypeScript
- **Routing**: Wouter 3.3.5
- **State Management**: TanStack Query 5.60.5
- **UI Framework**: Tailwind CSS 3.4.17
- **Component Library**: Radix UI + shadcn/ui
- **Forms**: React Hook Form 7.55.0 + Zod validation
- **Maps**: Leaflet 1.9.4
- **Icons**: Lucide React 0.453.0
- **Build Tool**: Vite 5.4.14

### Backend
- **Runtime**: Node.js 20.19.2
- **Framework**: Express 4.21.2
- **Database**: PostgreSQL with PostGIS
- **ORM**: Drizzle ORM 0.39.1
- **Authentication**: Passport.js with local strategy
- **Session Storage**: PostgreSQL session store
- **File Processing**: Built-in Node.js modules

### Development Tools
- **TypeScript**: 5.6.3
- **Package Manager**: npm
- **Process Manager**: PM2
- **Database Migration**: Drizzle Kit 0.30.4
- **Code Execution**: tsx 4.19.1

## Application Architecture

### Multi-Tenant Design
```
Request Flow:
Client Request → Nginx → Express Server → Authentication → Base Context → Database Query

Base Context Isolation:
- Each tenant (base) has unique subdomain
- All database queries filtered by base context
- Session tokens include base information
- Complete data isolation between tenants
```

### API Endpoints
```
Authentication:
GET  /api/magic-link/:token          # Magic link authentication
POST /api/auth/login                 # Standard login
POST /api/auth/logout                # Logout
GET  /api/auth/me                    # Current user info

Base Management:
GET  /api/super-admin/bases          # List all bases
POST /api/super-admin/bases          # Create new base
GET  /api/base/:subdomain/*          # Base-specific routes

Data Management:
GET  /api/sites                      # List sites
POST /api/sites                      # Create site
PUT  /api/sites/:id                  # Update site
DELETE /api/sites/:id                # Delete site

File Upload:
POST /api/upload                     # File upload endpoint
```

### Authentication Flow
1. User accesses subdomain-specific route
2. System validates session token
3. Token contains base context information
4. All subsequent queries filtered by base_id
5. Complete tenant isolation maintained

## Deployment Configuration

### PM2 Process Management
```bash
# Current running process
pm2 list
# ID: 1, Name: team2-gis, Status: online

# Process commands
pm2 start npm --name "team2-gis" -- run dev
pm2 stop team2-gis
pm2 restart team2-gis
pm2 logs team2-gis
pm2 delete team2-gis
```

### Environment Variables
```bash
# .env file location: /opt/team2-gis/.env
DATABASE_URL=postgresql://gisuser:gispassword123@localhost:5432/gisdb
NODE_ENV=development
PORT=5000
HOST=0.0.0.0
```

### Build Process
```bash
# Development server
npm run dev

# Production build
npm run build

# Production start
npm run start

# Type checking
npm run check

# Database operations
npm run db:push
```

## Service Management

### System Services
```bash
# PostgreSQL
sudo systemctl status postgresql
sudo systemctl start postgresql
sudo systemctl stop postgresql
sudo systemctl restart postgresql

# Nginx (if configured)
sudo systemctl status nginx
sudo systemctl start nginx
sudo systemctl restart nginx
```

### Application Monitoring
```bash
# Check application status
curl http://localhost:5000/health

# View application logs
pm2 logs team2-gis --lines 100

# Monitor system resources
pm2 monit

# Check database connectivity
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT 1;"
```

## Security Configuration

### Database Security
- PostgreSQL configured for external access
- User-based authentication with encrypted passwords
- Connection encryption enabled
- Role-based access control

### Application Security
- Session-based authentication
- CORS protection configured
- Input validation with Zod schemas
- SQL injection prevention via parameterized queries

## Backup & Recovery

### Database Backup
```bash
# Create backup
pg_dump -U gisuser -h localhost gisdb > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore backup
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb < backup_file.sql
```

### Application Backup
```bash
# Backup application
tar -czf team2-gis-backup-$(date +%Y%m%d).tar.gz /opt/team2-gis/

# Exclude node_modules
tar --exclude='node_modules' -czf team2-gis-backup-$(date +%Y%m%d).tar.gz /opt/team2-gis/
```

## Operational Procedures

### Adding New Tenants
1. Create base record in database
2. Set up subdomain routing
3. Initialize base-specific data
4. Configure authentication

### Troubleshooting Common Issues
```bash
# Application won't start
pm2 logs team2-gis
pm2 restart team2-gis

# Database connection issues
sudo systemctl status postgresql
PGPASSWORD=gispassword123 psql -U gisuser -h localhost -d gisdb -c "SELECT version();"

# Port conflicts
netstat -tulpn | grep :5000
lsof -i :5000
```

## Development Workflow

### Local Development Setup
```bash
# Clone repository
git clone <repository-url>
cd team2-gis

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with local database settings

# Start development server
npm run dev
```

### Deployment Workflow
```bash
# Build application
npm run build

# Deploy to server
scp -r dist/ root@172.232.108.139:/opt/team2-gis/

# Restart services
ssh root@172.232.108.139 "cd /opt/team2-gis && pm2 restart team2-gis"
```

## Performance Optimization

### Database Optimization
- Indexes on frequently queried fields
- Connection pooling configured
- Query optimization for spatial data
- Regular maintenance and vacuum operations

### Application Optimization
- Vite build optimization
- Asset compression and minification
- Lazy loading for components
- Efficient state management

## Contact Information

### Server Access
- **SSH Access**: root@172.232.108.139
- **Password**: Geo@asset15!
- **Application Path**: /opt/team2-gis

### Database Access
- **Host**: 172.232.108.139:5432
- **Master**: postgres/PostgresAdmin2024!
- **Application**: gisuser/gispassword123

This documentation provides complete knowledge transfer for the deployed GIS SaaS platform with all credentials, configurations, and operational procedures necessary for ongoing maintenance and development.