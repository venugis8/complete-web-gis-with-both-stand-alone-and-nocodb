const http = require('http');
const url = require('url');

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  // NocoDB API endpoints - exact match to mapz.in:5001
  if (pathname === '/api/v1/nocodb-tables') {
    console.log('=== NOCODB TABLE FETCH REQUEST ===');
    
    try {
      const nocodbUrl = 'https://app.nocodb.com';
      const nocodbApiKey = 'WvgZorcSfG5-kS5z1yDZnNXsRNejxQBSOETUeBvo';
      const nocodbBaseId = 'prxsww2l3z53hiw';
      
      console.log('Fetching tables from NocoDB base:', nocodbBaseId);
      const response = await fetch(`${nocodbUrl}/api/v2/meta/bases/${nocodbBaseId}/tables`, {
        headers: {
          'xc-token': nocodbApiKey,
          'Content-Type': 'application/json'
        }
      });

      console.log('NocoDB response status:', response.status);
      
      if (response.ok) {
        const nocodbData = await response.json();
        console.log('Found NocoDB tables:', nocodbData.list?.length || 0);
        
        const tables = nocodbData.list || [];
        const transformedTables = tables.map((table) => ({
          id: table.id,
          tableName: table.table_name || table.title,
          displayName: table.title || table.table_name,
          baseId: 4,
          hasGeometry: false,
          geometryColumn: null,
          schema: { columns: table.columns || [] },
          createdAt: new Date(),
          updatedAt: new Date()
        }));
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(transformedTables));
      } else {
        throw new Error(`NocoDB API error: ${response.status}`);
      }
    } catch (error) {
      console.error('NocoDB fetch error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Failed to fetch NocoDB tables', details: error.message }));
    }
    return;
  }
  
  // Super Admin API - exact match to mapz.in:5001
  if (pathname === '/api/super-admin/bases') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify([
      {
        id: 4,
        name: 'SSC6 NocoDB Base',
        subdomain: 'ssc6',
        status: 'active',
        userCount: 1,
        tableCount: 4,
        createdAt: new Date().toISOString(),
        systemMode: 'nocodb',
        deploymentType: 'nocodb',
        nocodbBaseId: 'prxsww2l3z53hiw',
        nocodbUrl: 'https://app.nocodb.com',
        nocodbApiKey: 'WvgZorcSfG5-kS5z1yDZnNXsRNejxQBSOETUeBvo'
      }
    ]));
    return;
  }
  
  // Health check
  if (pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      status: 'NocoDB System - Running from GitHub!', 
      timestamp: new Date().toISOString(),
      source: 'https://github.com/venugis8/replit-nocodb-webgis-team1',
      type: 'pure-nocodb'
    }));
    return;
  }
  
  // Default response
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NocoDB GIS Platform</title>
  </head>
  <body>
    <div style="padding: 40px; text-align: center; font-family: Arial, sans-serif;">
      <h1>NocoDB GIS Platform</h1>
      <p>Pure NocoDB Integration - mapz.in:5001 equivalent</p>
      <p><strong>NocoDB Base ID:</strong> prxsww2l3z53hiw</p>
    </div>
  </body>
</html>`);
});

const port = process.env.PORT || 5000;
server.listen(port, '0.0.0.0', () => {
  console.log(`NocoDB System running on port ${port}`);
  console.log(`Pure NocoDB integration - mapz.in:5001 equivalent`);
  console.log(`Base ID: prxsww2l3z53hiw`);
});