#!/bin/bash
sshpass -p 'Mapz@2024' scp complete-server.mjs root@172.235.5.20:/root/
