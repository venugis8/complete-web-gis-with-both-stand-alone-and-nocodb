#!/bin/bash

# Complete SaaS WebGIS Deployment Script for Linode
# Run as root user

set -e

echo "=== Starting SaaS WebGIS Deployment ==="

# Step 1: System Update and Dependencies
echo "Installing system dependencies..."
apt update && apt upgrade -y
apt install -y curl wget git unzip nginx certbot python3-certbot-nginx

# Step 2: Install Node.js 20
echo "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# Step 3: Install PostgreSQL
echo "Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib
systemctl start postgresql
systemctl enable postgresql

# Step 4: Install PM2
echo "Installing PM2..."
npm install -g pm2

# Step 5: Create Database
echo "Setting up database..."
sudo -u postgres psql << 'EOSQL'
CREATE DATABASE saas_webgis;
CREATE USER webgis_user WITH PASSWORD 'WebGIS_Secure_2024!';
GRANT ALL PRIVILEGES ON DATABASE saas_webgis TO webgis_user;
ALTER USER webgis_user CREATEDB;
\q
EOSQL

# Step 6: Create Application Directory
echo "Creating application directory..."
mkdir -p /var/www/saas-webgis
cd /var/www/saas-webgis

# Step 7: Extract Application Code
echo "Upload your replit-saas-webgis-complete.tar.gz file to /var/www/saas-webgis/"
echo "Then run: tar -xzf replit-saas-webgis-complete.tar.gz"
echo "Press Enter after uploading and extracting the file..."
read -p "Continue after extracting tar file? (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Please upload and extract the tar file first"
    exit 1
fi

# Step 8: Install Node Dependencies
echo "Installing Node.js dependencies..."
npm install

# Step 9: Create Environment File
echo "Creating environment configuration..."
cat > .env << 'EOF'
NODE_ENV=production
DATABASE_URL=postgresql://webgis_user:WebGIS_Secure_2024!@localhost:5432/saas_webgis
PORT=3000
PGHOST=localhost
PGPORT=5432
PGUSER=webgis_user
PGPASSWORD=WebGIS_Secure_2024!
PGDATABASE=saas_webgis
EOF

# Step 10: Setup Database Schema
echo "Setting up database schema..."
npm run db:push

# Step 11: Build Application
echo "Building application..."
npm run build

# Step 12: Configure Nginx
echo "Configuring Nginx..."
cat > /etc/nginx/sites-available/saas-webgis << 'EOF'
server {
    listen 80;
    server_name mapz.in *.mapz.in;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Static file caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# Enable Nginx site
ln -sf /etc/nginx/sites-available/saas-webgis /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx
systemctl enable nginx

# Step 13: Create PM2 Ecosystem File
echo "Creating PM2 configuration..."
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'saas-webgis',
    script: 'tsx',
    args: 'server/index.ts',
    cwd: '/var/www/saas-webgis',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/saas-webgis-error.log',
    out_file: '/var/log/saas-webgis-out.log',
    log_file: '/var/log/saas-webgis-combined.log',
    time: true
  }]
};
EOF

# Step 14: Start Application with PM2
echo "Starting application..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd -u root --hp /root

# Step 15: Setup Firewall
echo "Configuring firewall..."
ufw allow ssh
ufw allow 'Nginx Full'
ufw --force enable

# Step 16: Create SSL Certificate
echo "Setting up SSL certificate..."
read -p "Enter your email for SSL certificate: " ssl_email
read -p "Enter your domain (e.g., mapz.in): " domain

if [ ! -z "$ssl_email" ] && [ ! -z "$domain" ]; then
    certbot --nginx -d $domain -d "*.$domain" --email $ssl_email --agree-tos --non-interactive
else
    echo "Skipping SSL setup. You can run this later:"
    echo "certbot --nginx -d your-domain.com -d *.your-domain.com"
fi

# Step 17: Create Log Rotation
echo "Setting up log rotation..."
cat > /etc/logrotate.d/saas-webgis << 'EOF'
/var/log/saas-webgis-*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 root root
    postrotate
        pm2 reloadLogs
    endscript
}
EOF

# Step 18: Create Backup Script
echo "Creating backup script..."
cat > /root/backup-saas-webgis.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/root/backups"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

echo "Creating database backup..."
sudo -u postgres pg_dump saas_webgis > $BACKUP_DIR/saas_webgis_db_$DATE.sql

echo "Creating application backup..."
tar -czf $BACKUP_DIR/saas_webgis_app_$DATE.tar.gz -C /var/www saas-webgis

echo "Cleaning old backups (keeping last 7 days)..."
find $BACKUP_DIR -name "saas_webgis_*" -mtime +7 -delete

echo "Backup completed: $BACKUP_DIR"
EOF

chmod +x /root/backup-saas-webgis.sh

# Step 19: Setup Cron Jobs
echo "Setting up cron jobs..."
(crontab -l 2>/dev/null; echo "0 2 * * * /root/backup-saas-webgis.sh >> /var/log/backup.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "0 0 * * 0 certbot renew --quiet") | crontab -

# Step 20: Set Permissions
echo "Setting correct permissions..."
chown -R root:root /var/www/saas-webgis
chmod -R 755 /var/www/saas-webgis

# Step 21: Final Status Check
echo "Checking deployment status..."
echo "================================"
echo "Node.js version: $(node --version)"
echo "NPM version: $(npm --version)"
echo "PM2 status:"
pm2 status
echo "================================"
echo "PostgreSQL status:"
systemctl status postgresql --no-pager -l
echo "================================"
echo "Nginx status:"
systemctl status nginx --no-pager -l
echo "================================"

# Step 22: Test Database Connection
echo "Testing database connection..."
sudo -u postgres psql -d saas_webgis -c "SELECT version();" || echo "Database connection failed!"

# Step 23: Display Final Information
echo ""
echo "=== DEPLOYMENT COMPLETED ==="
echo ""
echo "🔗 Application URL: http://$domain (or https:// if SSL was configured)"
echo "🔗 Super Admin: https://$domain"
echo "🔗 Sample Workspaces:"
echo "   - acme-corp.$domain/login"
echo "   - ssc5.$domain/login"
echo "   - ssc6.$domain/login"
echo ""
echo "📋 Important Commands:"
echo "   - View logs: pm2 logs saas-webgis"
echo "   - Restart app: pm2 restart saas-webgis"
echo "   - Database access: sudo -u postgres psql -d saas_webgis"
echo "   - Backup: /root/backup-saas-webgis.sh"
echo ""
echo "📁 Important Paths:"
echo "   - Application: /var/www/saas-webgis"
echo "   - Logs: /var/log/saas-webgis-*.log"
echo "   - Backups: /root/backups/"
echo "   - SSL Certs: /etc/letsencrypt/live/$domain/"
echo ""
echo "⚙️  Configuration Files:"
echo "   - Environment: /var/www/saas-webgis/.env"
echo "   - Nginx: /etc/nginx/sites-available/saas-webgis"
echo "   - PM2: /var/www/saas-webgis/ecosystem.config.js"
echo ""
echo "🔐 Database Credentials:"
echo "   - Database: saas_webgis"
echo "   - User: webgis_user"
echo "   - Password: WebGIS_Secure_2024!"
echo ""
echo "Deployment completed successfully!"
echo "Make sure to point your DNS A records to this server's IP address."