#!/bin/bash
# Direct deployment to 172.232.108.139

# Create the deployment payload
DEPLOY_PAYLOAD='#!/bin/bash
echo "Starting Team 2 GIS deployment fix..."

# Stop current process
pm2 stop team2-standalone-gis 2>/dev/null || true
pm2 delete team2-standalone-gis 2>/dev/null || true

# Create production server
cat > /opt/team2-gis/production_server.js << '"'"'PRODEOF'"'"'
const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 5000;
const HOST = "0.0.0.0";

console.log(`Starting on ${HOST}:${PORT}`);

app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

app.use(express.json());

const distPath = path.join(__dirname, "dist");
if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));
}

app.get("/api/health", (req, res) => {
    res.json({ 
        status: "ok", 
        service: "Team 2 GIS",
        host: HOST, 
        port: PORT,
        timestamp: new Date().toISOString()
    });
});

app.get("/api/super-admin/bases", (req, res) => {
    res.json([{
        "id": 1,
        "name": "Team 2 GIS Base",
        "subdomain": "team2",
        "status": "active"
    }]);
});

app.get("*", (req, res) => {
    const indexPath = path.join(distPath, "index.html");
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        res.status(200).send(`
            <h1>Team 2 Standalone GIS System</h1>
            <p>Server: ${HOST}:${PORT}</p>
            <p>Status: Active</p>
            <p>Time: ${new Date().toISOString()}</p>
            <p><a href="/api/health">Health Check</a></p>
        `);
    }
});

app.listen(PORT, HOST, () => {
    console.log(`Server running on http://${HOST}:${PORT}`);
});
PRODEOF

# Start with PM2
cd /opt/team2-gis
pm2 start production_server.js --name "team2-standalone-gis"
pm2 save

# Restart nginx
systemctl restart nginx

echo "Deployment complete - checking status..."
pm2 status
netstat -tlnp | grep :5000
'

# Execute via SSH with password
echo "$DEPLOY_PAYLOAD" | sshpass -p 'Geo@asset12!' ssh -o StrictHostKeyChecking=no root@172.232.108.139 'cat > /tmp/deploy.sh && chmod +x /tmp/deploy.sh && bash /tmp/deploy.sh'
